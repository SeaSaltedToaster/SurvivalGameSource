package net.integrated;

public class main {
	
	public static void main(String[] args) {
		Server.start(25325);
	}


}
