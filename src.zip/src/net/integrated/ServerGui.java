package net.integrated;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Window.Type;
import java.awt.Toolkit;

public class ServerGui {

	private JFrame frmToastarioServer;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerGui window = new ServerGui();
					window.frmToastarioServer.setVisible(true);
					Server.start(25325);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		Server.stop();
	}

	/**
	 * Create the application.
	 */
	public ServerGui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	static JPanel panel_3 = new JPanel();
	
	private void initialize() {
		frmToastarioServer = new JFrame();
		frmToastarioServer.setTitle("Toastario Server");
		frmToastarioServer.setBounds(100, 100, 450, 300);
		frmToastarioServer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmToastarioServer.getContentPane().setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setToolTipText("Players");
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setForeground(Color.DARK_GRAY);
		panel_1.setBounds(10, 5, 202, 125);
		frmToastarioServer.getContentPane().add(panel_1);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JPanel panel_2 = new JPanel();
		panel_2.setToolTipText("Performance");
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_2.setBounds(10, 132, 202, 129);
		frmToastarioServer.getContentPane().add(panel_2);
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_3.setToolTipText("Logger");
		panel_3.setBounds(222, 5, 212, 256);
		frmToastarioServer.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(0, 236, 212, 20);
		panel_3.add(textField);
		textField.setColumns(10);
	}
	
	private static int logs;
	
	public static void log(String logged){
		JLabel lblNewLabel = new JLabel(logged);
		logs++;
		lblNewLabel.setBounds(0, 0, 212, 14);
		panel_3.add(lblNewLabel);
	}
}
