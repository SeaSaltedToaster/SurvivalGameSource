package net.client;

import java.util.ArrayList;

public class NetPlayer {

	private String name;
	private float x;
	private float y;
	private float z;
	
	public static ArrayList<NetPlayer> multiplayers = new ArrayList<NetPlayer>();
	
	public NetPlayer(String name, float x, float y, float z) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getZ() {
		return z;
	}

	public void setZ(float z) {
		this.z = z;
	}
	
	public static void createMultiplayer(String name, float x, float y, float z) {
		NetPlayer multiplayer = new NetPlayer(name, x, y, z);
		multiplayers.add(multiplayer);
	}
	
}
