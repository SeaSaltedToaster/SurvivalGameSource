package net;

import java.util.ArrayList;

import client.Engine;
import client.entities.Entity;
import client.init.Textures;
import client.math.Vector3f;
import client.render.Loader;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import game.entities.EntityPlayer;
import game.main.Main;
import game.main.states.Game;
import game.save.SaveManager;
import net.client.Client;
import net.client.NetPlayer;

public class Network {
	
	public static String name = SaveManager.worldName;
	public static float x;
	public static float y;
	public static float z;
	public static int age;
	public static int health;
	public static boolean generate;

	public static ArrayList<EntityPlayer> players = new ArrayList<EntityPlayer>();

	public static void createPlayers() {

		if (generate == true) {

			for (int i = 0; i < NetPlayer.multiplayers.size(); i++) {

				String name = NetPlayer.multiplayers.get(i).getName();
				float x = NetPlayer.multiplayers.get(i).getX();
				float y = NetPlayer.multiplayers.get(i).getY();
				float z = NetPlayer.multiplayers.get(i).getZ();

				if (players.size() < NetPlayer.multiplayers.size()) {
					Loader loader = Engine.getLoader();

					RawModel playerModel = OBJLoader.loadObjModel("cube", loader);
					TexturedModel PlayerModel = new TexturedModel(playerModel, new ModelTexture(Textures.health));

					EntityPlayer player = new EntityPlayer(PlayerModel, new Vector3f(x, y, z), 0, 0, 0, 1, NetPlayer.multiplayers.get(i).getName());
					Game.getEntities().add(player);
					players.add(player);

					generate = false;
				}
			}
		}
	}

	public static void updateData() {

		for (int i = 0; i < NetPlayer.multiplayers.size(); i++) {

			NetPlayer multiplayer = NetPlayer.multiplayers.get(i);

			String data = Client.playerdata.get(multiplayer);

			if (data != null) {

				String name = multiplayer.getName();

				EntityPlayer player = players.get(i);

				if (player.getName().equals(name)) {

					String[] parts = data.split(":");

					float x = Float.parseFloat(parts[1]);
					float y = Float.parseFloat(parts[2]);
					float z = Float.parseFloat(parts[3]);

					player.setPosition(new Vector3f(x, y, z));

				}
			}
		}
	}

}
