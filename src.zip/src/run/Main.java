package run;

public class Main {

	public static void main(String[] args) {
		
		game.main.Main.main(args);
	}
	
}
