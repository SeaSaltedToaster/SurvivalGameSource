package client.constants;

public class Settings {

	public static final float RENDER_DISTANCE = 128;
	public static float CHUNK_DISTANCE = 16;
	
}
