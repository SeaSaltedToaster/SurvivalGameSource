package client.constants;

public class Constants {

	//Display
	public static final int DISPLAY_WIDTH = 1280;
	public static final int DISPLAY_HEIGHT = 720;
	
	//Background Color
	public static final float BACKGROUND_R = 0f;
	public static final float BACKGROUND_G = 0.7001067811865476f;
	public static final float BACKGROUND_B = 0.7071067811865476f;
	public static final float BACKGROUND_A = 0.2f;
	
	//Terrain
	public static final int TERRAIN_VERTEX_COUNT = 64;
	public static final float TERRAIN_SIZE = 64;
	
	//Projection Matrix
	public static final float FOV = 70;
	public static final float NEAR_PLANE = 0.5f;
	public static final float FAR_PLANE = 1000;
	
	//FPS/UPS
	public static final double NS = 1000000000/120.0;
	
	//Camera
	public static final float CAM_SPEED = 0.8f;
	public static final float CAM_X = 0;
	public static final float CAM_Y = 50;
	public static final float CAM_Z = 50;
	public static final float CAM_PITCH = 20;
	public static final float CAM_YAW = 10;
	public static final float CAM_ROLL = 0;
	
	public static final float CHUNK_SIZE = 24;
	
	//Light
	public static final float LIGHT_X = 20000;
	public static final float LIGHT_Y = 20000;
	public static final float LIGHT_Z = 2000;
	
	//Fog
	public static final float FOG_DENSITY= 0.001f;
	public static final float FOG_GRADIENT = 0.5f;
	
	//Player
	public static final float PLAYER_SPEED = 0.25f;
	public static final float PLAYER_TURN = 1;
	public static final float PLAYER_JUMP = 3;
	
	//Environment
	public static final float ENVIRONMENT_GRAVITY = -0.25f;
	public static final float ENVIRONMENT_HEIGHT = 0f;
	public static final float CAM_HEIGHT = 4.5f;
	
}
