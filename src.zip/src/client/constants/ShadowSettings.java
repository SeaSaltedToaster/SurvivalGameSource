package client.constants;

public enum ShadowSettings {

	low(1024),medium(2048),high(4096);
	
	public int size;
	
	private ShadowSettings(int size) {
		this.size = size;
	}
	
}
