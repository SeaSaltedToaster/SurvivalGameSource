package client.guis.core;

import client.guis.transitions.UiAnimator;

public class UiMeta {
	
	//Values
	private float alpha;
	
	private UiAnimator animator;
	
	public UiMeta() {
		this.alpha = 1;
		this.animator = new UiAnimator();
	}

	public float getAlpha() {
		return alpha;
	}

	public void setAlpha(float alpha) {
		this.alpha = alpha;
	}

	public UiAnimator getAnimator() {
		return animator;
	}

}
