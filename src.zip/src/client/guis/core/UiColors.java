package client.guis.core;

public enum UiColors {

	BLUE, GREEN,
	
}
