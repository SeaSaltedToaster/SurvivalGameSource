package client.guis.core.render;

import client.math.Matrix4f;
import client.shaders.GenericShader;

public class UiShader extends GenericShader{
	
	private static final String VERTEX_FILE = "/client/guis/core/render/uiVertexShader.txt";
	private static final String FRAGMENT_FILE = "/client/guis/core/render/uiFragmentShader.txt";
	
	private int location_transformationMatrix;
	private int location_alpha;


	public UiShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}
	
	public void loadTransformation(Matrix4f matrix){
		super.loadMatrix(location_transformationMatrix, matrix);
	}
	
	public void loadAlpha(float alpha) {
		super.loadFloat(location_alpha, alpha);
	}

	@Override
	protected void getAllUniformLocations() {
		location_transformationMatrix = super.getUniformLocation("transformationMatrix");
	}

	@Override
	protected void bindAttributes() {
		super.bindAttribute(0, "position");
	}
	
	
	

}
