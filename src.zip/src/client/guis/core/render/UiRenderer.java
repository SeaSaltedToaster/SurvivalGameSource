package client.guis.core.render;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import client.Engine;
import client.constants.Constants;
import client.engine.EngineVariables;
import client.guis.core.UiBlock;
import client.guis.resources.UiResources;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.math.Vector3f;
import client.render.Loader;
import client.render.MasterRenderer;
import client.render.model.RawModel;
import client.util.gl.OpenGL;

public class UiRenderer {

	private final RawModel quad;
	private UiShader shader;
	
	private List<UiBlock> uis;
	
	public UiRenderer(Loader loader) {
		float[] positions = {-1,1, -1, -1, 1, 1, 1, -1};
		quad = loader.loadToVAO(positions, 2); // 2d vertex positions
		shader = new UiShader();
		uis = new ArrayList<UiBlock>();
	}
	
	public void render(List<UiBlock> guis){
		shader.start();
		GL30.glBindVertexArray(quad.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		for(UiBlock gui : guis) {		
			shader.loadAlpha(gui.getAlpha());
			GL13.glActiveTexture(GL13.GL_TEXTURE0);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, gui.getTexture());
			Matrix4f matrix = MathUtils.createTransformationMatrix(gui.getPosition(), gui.getScale());
			shader.loadTransformation(matrix);
			GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
		}
		GL11.glEnable(GL11.GL_DEPTH_TEST);	
		GL11.glDisable(GL11.GL_BLEND);
		GL20.glDisableVertexAttribArray(0);
		GL30.glBindVertexArray(0);
		shader.stop();
	}
	
	public void prepare() {
		OpenGL.enableCull();
		OpenGL.refreshGL();
		OpenGL.clearColor(new Vector3f(1,1,1), Constants.BACKGROUND_A);
		OpenGL.activateTexture(5);
	}
	
	public void render(UiBlock[] guis){
		GL30.glBindVertexArray(quad.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		shader.start();
		for (UiBlock gui: guis){
			GL13.glActiveTexture(GL13.GL_TEXTURE0);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, gui.getTexture());
			Matrix4f matrix = MathUtils.createTransformationMatrix(gui.getPosition(), gui.getScale());
			shader.loadTransformation(matrix);
			GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, quad.getVertexCount());
		}
		shader.stop();
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_DEPTH_TEST);	
		GL20.glDisableVertexAttribArray(0);
		GL30.glBindVertexArray(0);
	}
	
	public void cleanUp(){
		shader.cleanUp();
	}

	public List<UiBlock> getUis() {
		return uis;
	}
	
}
