package client.guis.core;

import client.Engine;
import client.guis.transitions.UiAnimator;
import client.math.Vector2f;

public class UiBlock extends UiComponent {

	private int texture;
	private Vector2f position;
	private Vector2f scale;
	
	private UiMeta meta;
	
	public UiBlock(int texture, Vector2f position, Vector2f scale) {
		this.texture = texture;
		this.position = position;
		this.scale = scale;
		this.meta = new UiMeta();
	}
	
	public void show() {
		Engine.getTextures().add(this);
	}
	
	public void hide() {
		Engine.getTextures().remove(this);
	}
	
	public int getTexture() {
		return texture;
	}
	public Vector2f getPosition() {
		return position;
	}
	public Vector2f getScale() {
		return scale;
	}

	public void setPosition(Vector2f position) {
		this.position = position;
	}

	public void setScale(Vector2f scale) {
		this.scale = scale;
	}

	public void setTexture(int texture) {
		this.texture = texture;
	}

	public float getAlpha() {
		return meta.getAlpha();
	}

	public void setAlpha(float alpha) {
		this.meta.setAlpha(alpha);
	}
	
	public UiAnimator getAnimator() {
		return meta.getAnimator();
	}

	public void updateSelf() {
		
	}
	
}
