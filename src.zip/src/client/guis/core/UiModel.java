package client.guis.core;

public class UiModel {

}
