package client.guis.core;

import java.util.ArrayList;
import java.util.List;

import client.guis.GUIManager;
import client.guis.layout.AbsoluteLayout;
import client.guis.layout.UiLayout;
import client.util.ArrayUtils;
import game.main.Main;

public abstract class UiComponent {

	private List<UiComponent> children = new ArrayList<UiComponent>();
	private UiComponent parentComponent;
	
	private UiLayout layout;
	
	public UiComponent() {
		layout = new AbsoluteLayout();
	}
	
	public void add(UiComponent component) {
		children.add(component);
		component.setParentComponent(this);
	}
	
	public abstract void updateSelf();

	public void update() {
		layout.updateLayout(children, this);
	}

	public List<UiComponent> getChildren() {
		return children;
	}

	public UiComponent getParentComponent() {
		return parentComponent;
	}

	public UiLayout getLayout() {
		return layout;
	}

	public void setParentComponent(UiComponent parentComponent) {
		this.parentComponent = parentComponent;
	}

	public void setLayout(UiLayout layout) {
		this.layout = layout;
	}
	
}
