package client.guis.core;

public interface IGui {

	public void updateSelf();
	
}
