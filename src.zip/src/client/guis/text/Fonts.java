package client.guis.text;

import client.Engine;

public class Fonts {

	public static FontType CRAZY = new FontType(Engine.getLoader().loadTexture("crazyFont"), "crazyFont");
	public static FontType ARIAL = new FontType(Engine.getLoader().loadTexture("fonts/berlin"), "fonts/berlin");
//	public static FontType SURVIVAL = new FontType(Engine.getLoader().loadTexture("survival"), "survival");
	
}
