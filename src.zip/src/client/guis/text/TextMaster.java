package client.guis.text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import client.render.Loader;

public class TextMaster {
	
	private static Loader loader;
    private static Map<FontType, List<GUIText>> texts = new HashMap<FontType, List<GUIText>>();
    private static List<GUIText> textz = new ArrayList<GUIText>();
    private static FontRenderer renderer;
     
    public static void init(Loader theLoader){
        renderer = new FontRenderer();
        loader = theLoader;
    }
     
    public static void render(){
        renderer.render(texts);
    }
    
    public static void clear() {
    	texts.clear();
    	textz.clear();
    }
     
    public static void loadText(GUIText text){
        FontType font = text.getFont();
        TextMeshData data = font.loadText(text);
        int vao = loader.loadToVAO(data.getVertexPositions(), data.getTextureCoords());
        text.setMeshInfo(vao, data.getVertexCount());
        List<GUIText> textBatch = texts.get(font);
        if(textBatch == null){
            textBatch = new ArrayList<GUIText>();
            texts.put(font, textBatch);
        }
        textBatch.add(text);
        textz.add(text);
    }
     
    @SuppressWarnings("unlikely-arg-type")
	public static void removeText(GUIText text){
        List<GUIText> textBatch = texts.get(text.getFont());
        textBatch.remove(text);
        if(textBatch.isEmpty()){
            texts.remove(texts.get(text.getFont()));
        }
        textz.remove(text);
    }
     
    public static void cleanUp(){
        renderer.cleanUp();
    }

	public static Map<FontType, List<GUIText>> getTexts() {
		return texts;
	}

	public static List<GUIText> getTextz() {
		return textz;
	}
    
}
