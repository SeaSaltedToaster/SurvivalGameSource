package client.guis.text;

import client.math.Vector2f;
import client.math.Vector3f;

public class GUIText {
	private String textString;
    private float fontSize;
 
    private int textMeshVao;
    private int vertexCount;
    private Vector3f colour = new Vector3f(0f, 0f, 0f);
 
    private Vector2f position;
    private float lineMaxSize;
    private int numberOfLines;
 
    private FontType font;
 
    private boolean centerText = false;

    public GUIText(String text, float fontSize, FontType font, Vector2f position, float maxLineLength, boolean centered) {
        this.textString = text;
        this.fontSize = fontSize;
        this.font = font;
        this.position = position;
        this.lineMaxSize = maxLineLength;
        this.centerText = centered;
        TextMaster.loadText(this);
    }
    
    public GUIText(String text, float fontSize, FontType font, Vector2f position, float maxLineLength, boolean centered, int i) {
        this.textString = text;
        this.fontSize = fontSize;
        this.font = font;
        this.position = position;
        this.lineMaxSize = maxLineLength;
        this.centerText = centered;
    }


    public void remove() {
        TextMaster.removeText(this);
    }
    
    public void show() {
    	TextMaster.loadText(this);
    }
    
    public void reset() {
    	this.remove();
    	this.show();
    }

    public FontType getFont() {
        return font;
    }

    public void setColour(float r, float g, float b) {
        colour.x = r;
        colour.y = g;
        colour.z = b;
    }

    public Vector3f getColour() {
        return colour;
    }

    public int getNumberOfLines() {
        return numberOfLines;
    }

    public Vector2f getPosition() {
        return position;
    }
    
    public String getText() {
    	return textString;
    }

    public int getMesh() {
        return textMeshVao;
    }

    public void setMeshInfo(int vao, int verticesCount) {
        this.textMeshVao = vao;
        this.vertexCount = verticesCount;
    }
    
    public int getVertexCount() {
        return this.vertexCount;
    }

    public float getFontSize() {
        return fontSize;
    }

    protected void setNumberOfLines(int number) {
        this.numberOfLines = number;
    }

    protected boolean isCentered() {
        return centerText;
    }

    protected float getMaxLineSize() {
        return lineMaxSize;
    }
 
    protected String getTextString() {
        return textString;
    }

	public void setTextString(String textString) {
		TextMaster.removeText(this);
		this.textString = textString;
		TextMaster.loadText(this);
	}
	
	public void setTextStringWithoutAddition(String textString) {
		this.textString = textString;
	}

	public void setFontSize(float fontSize) {
		this.fontSize = fontSize;
	}

	public void setPosition(Vector2f position) {
		this.position = new Vector2f(position.x, position.y);
	}
	
	public void setPositionOld(Vector2f position) {
		this.setPosition(position);
	}
    
	public float getTextLength() {
		return textString.length();
	}

	public void setFont(FontType font) {
		this.font = font;
		this.show();
	}
	
}
