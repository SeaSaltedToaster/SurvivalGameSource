package client.guis;

import java.util.ArrayList;
import java.util.List;

import client.guis.core.UiComponent;

public class GUIManager {

	private static List<UiComponent> components = new ArrayList<UiComponent>();
	
	public static void update() {
		for(UiComponent component : components) {
			component.updateSelf();
			component.update();
		}
	}
	
	public static void add(UiComponent component) {
		components.add(component);
	}
	
}
