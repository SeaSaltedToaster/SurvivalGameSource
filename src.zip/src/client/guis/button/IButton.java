package client.guis.button;

import java.util.List;

import client.guis.core.UiBlock;

public interface IButton {

	void onClick();

    void whileHover();

    void startHover();

    void stopHover();

    void checkHover();

    void playHoverAnimation(float scaleFactor);

    void playerClickAnimation(float scaleFactor);

    void hide(List<UiBlock> guiTextures);

    void show(List<UiBlock> guiTextures);

    void reopen(List<UiBlock> guiTextures);
	
}
