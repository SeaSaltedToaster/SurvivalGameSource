package client.guis.button;

import java.util.List;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.core.UiComponent;
import client.math.Vector2f;
import client.math.Vector4f;
import client.render.Loader;
import client.render.Window;
import client.render.display.WindowManager;
import client.texture.Texture;
import client.util.input.CursorPositionCallback;
import game.main.Main;

public class UiButton extends UiComponent implements IButton{

	private Loader loader;
    private String texture;
    private Vector2f position, scale;
    private Vector4f color = new Vector4f(1, 1, 1, 1);
    private UiBlock guiTexture;
    private boolean isHidden = false;
    private boolean isHovering = false;
    
    public float delay = 0;
    public float current;

    public UiButton(Loader loader, String texture, Vector2f position, Vector2f scale) {
        this.loader = loader;
        this.texture = texture;
        this.position = position;
        this.scale = scale;
        this.guiTexture = new UiBlock(loader.loadTexture(texture), position, scale);
        this.current = 0;
    }
    
    public UiButton(Texture texture, Vector2f position, Vector2f scale) {
        this.position = position;
        this.scale = scale;
        this.guiTexture = new UiBlock(texture.getID(), position, scale);
        this.current = 0;
    }

    public UiButton(Loader loader, String texture, Vector2f position, Vector2f scale, Vector4f color) {
        this(loader, texture, position, scale);
        this.color = color;
//        this.guiTexture.setColor(color);
    }

    public void checkHover() {
        if (!isHidden) {
            Vector2f location = guiTexture.getPosition();
            Vector2f scale = guiTexture.getScale();
            double mouseCoordinatesX = getMouseCoordsX();
            double mouseCoordinatesY = getMouseCoordsY();
            if (location.y + scale.y > -mouseCoordinatesY && location.y - scale.y < -mouseCoordinatesY && location.x + scale.x > mouseCoordinatesX && location.x - scale.x < mouseCoordinatesX) {
                whileHover();
                if (!isHovering) {
                    isHovering = true;
                    startHover();
                }
                if (Engine.getCamera().getMouseButtonCallback().isLeftButtonDown()) {
                	onClick();
                }
            } else {
                if (isHovering) {
                    isHovering = false;
                    stopHover();
                }
                guiTexture.setScale(this.scale);
            }
            current += Window.getDelta();
        }
    }

    public void playHoverAnimation(float scaleFactor) {
        guiTexture.setScale(new Vector2f(scale.x + scaleFactor, scale.y + scaleFactor));
    }

    public void playerClickAnimation(float scaleFactor) {
        guiTexture.setScale(new Vector2f(scale.x - (scaleFactor * 2), scale.y - (scaleFactor * 2)));
    }

    private void startRender(List<UiBlock> guiTextureList) {
        guiTextureList.add(guiTexture);
    }

    private void stopRender(List<UiBlock> guiTextureList) {
        guiTextureList.remove(guiTexture);
    }


    public void hide(List<UiBlock> guiTextures) {
        stopRender(guiTextures);
        isHidden = true;
    }

    public void show(List<UiBlock> guiTextures) {
        startRender(guiTextures);
        isHidden = false;
    }
    
    public void hide() {
        stopRender(Engine.getTextures());
        isHidden = true;
    }

    public void show() {
    	stopRender(Engine.getTextures());
        isHidden = false;
    }

    public void reopen(List<UiBlock> guiTextures) {
        hide(guiTextures);
        show(guiTextures);
    }

    public boolean isHovering() {
        return isHovering;
    }

    public boolean isHidden() {
        return isHidden;
    }

    public UiBlock getGuiTexture() {
        return guiTexture;
    }

    public Vector4f getColor() {
        return color;
    }

    public Vector2f getScale() {
        return scale;
    }

    public Vector2f getPosition() {
        return position;
    }

    public String getTexture() {
        return texture;
    }

//    public void setColor(Vector4f color) {
//        guiTexture.setColor(color);
//    }

    public void setScale(Vector2f scale) {
        guiTexture.setScale(scale);
    }

    public void setPosition(Vector2f position) {
        guiTexture.setPosition(position);
    }
    
    
    public void setGuiTexture(UiBlock guiTexture) {
		this.guiTexture = guiTexture;
	}

	private double getMouseCoordsX() {
    	double x = -1.0 + 2.0 * WindowManager.getCursorPosX(Main.getWindow().getWindowID()) / WindowManager.getWindowSizeX(Main.getWindow().getWindowID());
		return x;
    }
    
    private double getMouseCoordsY() {
    	double y = 1.0 - 2.0 * WindowManager.getCursorPosY(Main.getWindow().getWindowID()) / WindowManager.getWindowSizeY(Main.getWindow().getWindowID());
		return -y;
    }

	@Override
	public void onClick() {
		
	}

	@Override
	public void whileHover() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startHover() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stopHover() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateSelf() {
		// TODO Auto-generated method stub
		
	}

}
