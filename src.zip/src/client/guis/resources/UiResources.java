package client.guis.resources;

import client.Engine;
import client.guis.core.UiBlock;
import client.init.Textures;
import client.math.Vector2f;
import game.main.Main;

public class UiResources {

	public static UiBlock INVENTORY = new UiBlock(Textures.Inventory, new Vector2f(0,0), new Vector2f(0.625f,0.625f));
	public static UiBlock ARMOR = new UiBlock(Textures.Inventory, new Vector2f(-0.8f,0), new Vector2f(0.18f,0.625f));
	public static UiBlock HOTBAR = new UiBlock(Textures.dirt, new Vector2f(0f,-0.8f), new Vector2f(0.625f,0.18f));
	
	public static UiBlock DEATH = new UiBlock(Engine.getLoader().loadTexture("health"), new Vector2f(0,0), new Vector2f(1,1));
	
	public static UiBlock MENU = new UiBlock(Engine.getLoader().loadTexture("background"), new Vector2f(0,0), new Vector2f(1,1));
	public static UiBlock SPLASH = new UiBlock(Engine.getLoader().loadTexture("splash"), new Vector2f(0,0), new Vector2f(1,1));
	public static UiBlock SELECTOR = new UiBlock(Engine.getLoader().loadTexture("selector"), new Vector2f(0,0), new Vector2f(0.35f,0.8f));
}
