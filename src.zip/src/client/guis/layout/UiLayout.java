package client.guis.layout;

import java.util.List;

import client.guis.core.UiComponent;

public class UiLayout {

	public void updateLayout(List<UiComponent> children, UiComponent parent) {
		
	}
	
}
