package client.guis.layout;

import java.util.List;

import client.guis.core.UiComponent;

public class AbsoluteLayout extends UiLayout {

	@Override
	public void updateLayout(List<UiComponent> children, UiComponent parent) {
		
	}
	
}
