package client.guis.transitions;

import java.util.ArrayList;
import java.util.List;

import client.render.Window;

public class Transition {

	private List<GuiDriver> drivers = new ArrayList<GuiDriver>();
	
	public Transition slideDriver(float start, float end, float time) {
		SlideDriver driver = new SlideDriver(start,end,time);
		drivers.add(driver);
		return this;
	}
	
	public void update() {
		for(GuiDriver driver : drivers) {
			driver.update(Window.getDelta());
		}
	}
	
}
