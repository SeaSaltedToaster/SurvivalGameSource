package client.guis.transitions;

import client.math.MathUtils;

public class SlideDriver extends GuiDriver {
	
	private float startValue;
	private float endValue;
	private float max = 0.0F;
	private boolean reachedTarget = false;
	  
	public SlideDriver(float start, float end, float length) {
		super(length);
		this.startValue = start;
		this.endValue = end;
	}

	protected float calculateValue(float time) {
		if (!this.reachedTarget && time >= this.max) {
			this.max = time;
				return MathUtils.cosInterpolate(this.startValue, this.endValue, time);
		} 
		this.reachedTarget = true;
			return this.endValue;
		}
	}
