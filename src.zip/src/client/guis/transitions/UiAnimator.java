package client.guis.transitions;

import java.util.ArrayList;
import java.util.List;

public class UiAnimator {

	private List<Transition> transitions = new ArrayList<Transition>();
	
	public void doAnimation(Transition transition) {
		transitions.add(transition);
	}
	
	public void update() {
		for(Transition transition : transitions) {
			transition.update();
		}
	}
	
}
