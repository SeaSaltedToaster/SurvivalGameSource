package client.particles;


public class Particle {


}
