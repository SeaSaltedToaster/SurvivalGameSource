package client;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import client.engine.EngineVariables;
import client.engine.Logger;
import client.entities.Camera;
import client.entities.Entity;
import client.guis.core.UiBlock;
import client.guis.core.render.UiRenderer;
import client.guis.resources.UiResources;
import client.render.Loader;
import client.render.MasterRenderer;
import client.render.Window;
import client.render.display.WindowManager;
import game.Game;
import game.main.Main;
import game.mods.ToastarioMod;

public class Engine {
	
	public static MasterRenderer renderer;
	public static Window window;
	public static Camera camera;
	public static Loader loader;
	public static UiRenderer guiRenderer;
	
	private static List<UiBlock> textures;
	private static List<Entity> entities;
	
	public static boolean inLoadingScreen = false;
	
	private static int loadingScreenStart;
	private static int splashTime = 3;
	
	public static void start() {
		Logger.log("Creating Client...", Engine.class);
		startWindow();
		createCapabilities();
		startLoadingScreen();
		makeLists();
		Game.createGame();
		while(GLFW.glfwGetTime() - loadingScreenStart < splashTime) {
			Thread.yield();
		}
		stopLoadingScreen();
	}

	private static void stopLoadingScreen() {
		inLoadingScreen = false;
		textures.clear();
	}

	private static void startLoadingScreen() {
		inLoadingScreen = true;
		textures = new ArrayList<UiBlock>();
		
		textures.add(UiResources.SPLASH);
		WindowManager.show();
		renderer.prepare();
		guiRenderer.render(textures);
		window.update();
		loadingScreenStart = (int) GLFW.glfwGetTime();
	}

	private static void makeLists() {
		entities = new ArrayList<Entity>();
		Main.mods = new ArrayList<ToastarioMod>();
	}

	private static void startWindow() {
		window = new Window(EngineVariables.gameName+ "" + EngineVariables.gameVersion);
	}

	private static void createCapabilities() {
		renderer = new MasterRenderer();
		camera = new Camera(getWindow().getWindowID(), null);
		loader = new Loader();
		guiRenderer = new UiRenderer(loader);
	}

	public static void shutdown() {
		renderer.cleanUp();
		loader.cleanUp();
	}

	public static MasterRenderer getRenderer() {
		return renderer;
	}

	public static Window getWindow() {
		return window;
	}

	public static Camera getCamera() {
		return camera;
	}

	public static Loader getLoader() {
		return loader;
	}

	public static UiRenderer getGuiRenderer() {
		return guiRenderer;
	}

	public static List<UiBlock> getTextures() {
		return textures;
	}

	public static List<Entity> getEntities() {
		return entities;
	}
	
}
