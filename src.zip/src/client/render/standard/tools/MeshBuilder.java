package client.render.standard.tools;

import java.util.List;

import client.Engine;
import client.collision.CollisionWorld;
import client.collision.mesh.CollisionMeshFactory;
import client.collision.mesh.CustomCollisionMesh;
import client.render.model.RawModel;
import client.render.standard.Triangle;
import client.render.standard.Vertex;
import game.world.render.ChunkVertex;

public class MeshBuilder {

	public static RawModel createTerrainModel(List<Vertex> vertices, List<Triangle> triangles) {
		float[] position = buildVertices(vertices);
		float[] normals = extractNormals(vertices);
		
		int[] indices = sortIndices(triangles);
		float[] colors = getColors(vertices);
		
		CustomCollisionMesh collisionObject = CollisionMeshFactory.buildCollisionMesh(position, indices);
//    	CollisionWorld.getDynamicsWorld().addRigidBody(collisionObject.getRigidBody());
		
		return Engine.getLoader().loadTerrainToVAO(position, colors, normals, indices);
	}
	
	public static int[] sortIndices(List<Triangle> triangles) {
		int[] indices = new int[triangles.size() * 3 + 1];
		int vertexPointer = 0;
		for(int i = 0; i < triangles.size(); i++, vertexPointer+=3) {
			Triangle triangle = triangles.get(i);
			indices[vertexPointer] = triangle.getV1(); 
			indices[vertexPointer+1] = triangle.getV2();
			indices[vertexPointer+2] = triangle.getV3();
		}
		return indices;
	}

	private static float[] extractNormals(List<Vertex> vertices) {
		float[] normals = new float[vertices.size() * 3 + 1];
		int vertexPointer = 0;
		for(int i = 0; i < vertices.size(); i++, vertexPointer+=3) {
			Vertex vertex = vertices.get(i);
			normals[vertexPointer] = vertex.getNormal().x; 
			normals[vertexPointer+1] = vertex.getNormal().y;
			normals[vertexPointer+2] = vertex.getNormal().z;
		}
		return normals;
	}

	public static float[] buildVertices(List<Vertex> vertices) {
		float[] positions = new float[vertices.size() * 3 + 1];
		int vertexPointer = 0;
		for(int i = 0; i < vertices.size(); i++, vertexPointer+=3) {
			Vertex vertex = vertices.get(i);
			positions[vertexPointer] = vertex.getPosition().x; 
			positions[vertexPointer+1] = vertex.getPosition().y;
			positions[vertexPointer+2] = vertex.getPosition().z;
		}
		return positions;
	}
	
	private static float[] getColors(List<Vertex> triangles) {
		float[] indices = new float[triangles.size() * 3 + 1];
		int vertexPointer = 0;
		for(int i = 0; i < triangles.size(); i++, vertexPointer+=3) {
			indices[vertexPointer] = 0;
			indices[vertexPointer+1] = 1;
			indices[vertexPointer+2] = 0;
		}
		return indices;
	}
	
}
