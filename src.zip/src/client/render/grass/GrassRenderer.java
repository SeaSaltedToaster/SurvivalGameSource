package client.render.grass;

import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

import client.entities.Entity;
import client.entities.Light;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.render.obj.matRender.OBJMaterialRenderer;
import client.shaders.StaticShader;
import client.util.DistanceUtils;
import client.util.gl.OpenGL;
import game.entities.components.ComponentType;
import game.entities.components.RenderDistanceComponent;

public class GrassRenderer {

	private GrassShader shader;
	
	public GrassRenderer(GrassShader shader, Matrix4f projectionMatrix) {
		this.shader = shader;
		shader.start();
		shader.loadProjectionMatrix(projectionMatrix);
		shader.stop();
	}
	
	public void renderEntities(Map<TexturedModel, List<Entity>> entities, Light light) {
		for(TexturedModel model : entities.keySet()) {
			prepareTexturedModel(model);
			List<Entity> batch = entities.get(model);
			for (int i = 0; i < batch.size(); i++) {
				prepareComponents(batch.get(i));
				if(verifyRender()) { cancel(); continue; }
				prepareInstance(batch.get(i));
				GL11.glDrawElements(GL11.GL_TRIANGLES, model.getModel().getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
			}
			unbindTexturedModel();
		}		
	}
	
	private void prepareComponents(Entity entity) {
		if(entity.hasComponent(ComponentType.Sway))
			shader.loadWindSway(true);
		if(entity.hasComponent(ComponentType.RenderDistance)) {
			RenderDistanceComponent distance = (RenderDistanceComponent) entity.getComponent(ComponentType.RenderDistance);
			if(DistanceUtils.isInDistanceFromCam(entity.getPosition(), distance.getDistance())) {
				cancelRender();
			}
		}
	}
	
	private void prepareTexturedModel(TexturedModel model) {
		RawModel rm = model.getModel();
		GL30.glBindVertexArray(rm.getVaoID());
		OpenGL.enableVertexAttribArrays(0,1,2);
		if (model.getTexture().isHasTransparency())
			OpenGL.disableCull();
		shader.loadSpecular(model.getTexture().getShineDamper(), model.getTexture().getReflectivity());
		shader.loadFakeLighting(model.getTexture().isFakeLighting());
		OpenGL.activateTexture(0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, model.getTexture().getID());
	}
	
	private void unbindTexturedModel() {
		OpenGL.disableVertexAttribArrays(0,1,2);
		GL30.glBindVertexArray(0);
	}
	
	private void prepareInstance(Entity entity) {
		shader.loadTransformationMatrix(MathUtils.createTransformationMatrix(entity.getPosition(), 
				entity.getRx(), entity.getRy(), entity.getRz(), entity.getScale()));
		
	}
	
	private boolean shouldCancelRender = false;
	
	private void cancelRender() {
		shouldCancelRender = true;
	}
	
	private boolean verifyRender() {
		return shouldCancelRender;
	}
	
	private void cancel() {
		shouldCancelRender = false;
	}
	
}
