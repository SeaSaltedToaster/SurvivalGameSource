package client.render.batch.staticBatch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import client.entities.Entity;
import client.render.model.TexturedModel;

public class EntityStaticBatch {

private Map<TexturedModel, List<Entity>> entities = new HashMap<TexturedModel, List<Entity>>();
	
	public EntityStaticBatch() {
		
	}

	public Map<TexturedModel, List<Entity>> getEntities() {
		return entities;
	}

	public void setEntities(Map<TexturedModel, List<Entity>> entities) {
		this.entities = entities;
	}
	
}
