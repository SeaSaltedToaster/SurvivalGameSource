package client.render.batch.dynamicBatch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import client.animation.model.AnimatedModel;
import client.entities.Entity;
import client.render.model.TexturedModel;

public class EntityAnimatedBatch {

	private Map<AnimatedModel, List<Entity>> entities = new HashMap<AnimatedModel, List<Entity>>();

	public Map<AnimatedModel, List<Entity>> getEntities() {
		return entities;
	}

	public void setEntities(Map<AnimatedModel, List<Entity>> entities) {
		this.entities = entities;
	}
	
}
