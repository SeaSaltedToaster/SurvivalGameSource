package client.render.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import client.entities.Entity;
import client.render.batch.dynamicBatch.EntityAnimatedBatch;
import client.render.batch.dynamicBatch.EntityDynamicBatch;
import client.render.batch.staticBatch.EntityStaticBatch;
import client.render.model.TexturedModel;
import game.entities.components.AnimationComponent;
import game.entities.components.ComponentType;

public class EntityBatcher {

	private EntityDynamicBatch dynamicBatch;
	private EntityStaticBatch staticBatch;
	
	private EntityAnimatedBatch animatedBatch;
	
	public EntityBatcher() {
		this.dynamicBatch = new EntityDynamicBatch();
		this.staticBatch = new EntityStaticBatch();
		
		this.animatedBatch = new EntityAnimatedBatch();
	}
	
	public void processDynamicEntity(Entity entity) {
		Map<TexturedModel, List<Entity>> entities = dynamicBatch.getEntities();
		
		if(entity.hasComponent(ComponentType.Animation)) {
			AnimationComponent animation = (AnimationComponent) entity.getComponent(ComponentType.Animation);
			List<Entity> anim = new ArrayList<Entity>();
			anim.add(entity);
			animatedBatch.getEntities().put(animation.getModel(), anim);
			return;
		}
		
		TexturedModel tm = entity.getTm();
		List<Entity> batch = entities.get(tm);
		if (batch != null) {
			batch.add(entity);
		} else {
			List<Entity> newBatch = new ArrayList<Entity>();
			newBatch.add(entity);
			entities.put(tm, newBatch);
		}
	}
	
	public void processStaticEntity(Entity entity) {
		Map<TexturedModel, List<Entity>> entities = staticBatch.getEntities();
		
		TexturedModel tm = entity.getTm();
		List<Entity> batch = entities.get(tm);
		if (batch != null) {
			batch.add(entity);
		} else {
			List<Entity> newBatch = new ArrayList<Entity>();
			newBatch.add(entity);
			entities.put(tm, newBatch);
		}
	}
	
	public void clear() {
		dynamicBatch.getEntities().clear();
		staticBatch.getEntities().clear();
	}

	public EntityDynamicBatch getDynamicBatch() {
		return dynamicBatch;
	}

	public void setDynamicBatch(EntityDynamicBatch dynamicBatch) {
		this.dynamicBatch = dynamicBatch;
	}

	public EntityStaticBatch getStaticBatch() {
		return staticBatch;
	}

	public void setStaticBatch(EntityStaticBatch staticBatch) {
		this.staticBatch = staticBatch;
	}

	public EntityAnimatedBatch getAnimatedBatch() {
		return animatedBatch;
	}

	public void setAnimatedBatch(EntityAnimatedBatch animatedBatch) {
		this.animatedBatch = animatedBatch;
	}
	
}
