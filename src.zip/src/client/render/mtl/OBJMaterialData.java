package client.render.mtl;

public class OBJMaterialData {

}
