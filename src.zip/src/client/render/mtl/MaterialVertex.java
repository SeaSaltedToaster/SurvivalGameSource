package client.render.mtl;

import client.math.Vector3f;
import client.render.standard.Vertex;

public class MaterialVertex extends Vertex {

	public Vector3f color;
	
	public MaterialVertex(Vector3f position, Vector3f normal, Vector3f color) {
		super(position, normal);
		this.color = color;
	}

	public Vector3f getColor() {
		return color;
	}

	public void setColor(Vector3f color) {
		this.color = color;
	}

}
