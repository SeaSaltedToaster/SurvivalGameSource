package client.render.model;

import client.util.Vao;

public class RawModel {
	
	private int vaoID;
	private int vertexCount;
	
	private Vao vao;
	
	private ModelType modelType;
	
	public RawModel(int vaoID, int vertexCount) {
		this.vaoID = vaoID;
		this.vertexCount = vertexCount;
		this.modelType = ModelType.obj;
	}
	
	public RawModel(Vao vao) {
		this.vao = vao;
		this.vaoID = vao.id;
		this.vertexCount = vao.getIndexCount();
		this.modelType = ModelType.collada;
	}
	
	public RawModel(int vaoID, int vertexCount, ModelType type) {
		this.vaoID = vaoID;
		this.vertexCount = vertexCount;
		this.modelType = type;
	}
	
	public int getVaoID() {
		return vaoID;
	}

	public int getVertexCount() {
		return vertexCount;
	}

	public ModelType getModelType() {
		return modelType;
	}

	public void setModelType(ModelType modelType) {
		this.modelType = modelType;
	}

	public Vao getVao() {
		return vao;
	}
	
}
