package client.render.model;

public enum ModelType {

	obj, collada, 
	
}
