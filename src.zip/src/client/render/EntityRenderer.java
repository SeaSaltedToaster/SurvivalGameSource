package client.render;

import static org.lwjgl.opengl.GL11.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import client.constants.Constants;
import client.entities.Camera;
import client.entities.Entity;
import client.entities.Light;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.render.frustumCulling.FrustumCuller;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.render.obj.matRender.OBJMaterialRenderer;
import client.shaders.StaticShader;
import client.util.DistanceUtils;
import client.util.gl.OpenGL;
import game.entities.components.ComponentType;
import game.entities.components.MaterialComponent;
import game.entities.components.RenderDistanceComponent;

public class EntityRenderer {
	
	private StaticShader shader;
	
	public OBJMaterialRenderer materialRenderer;
	
	public static FrustumCuller culler;
	
	public EntityRenderer(StaticShader shader, Matrix4f projectionMatrix) {
		this.shader = shader;
		this.materialRenderer = new OBJMaterialRenderer();
		shader.start();
		shader.loadProjectionMatrix(projectionMatrix);
		shader.stop();
	}
	
	public void renderEntities(Map<TexturedModel, List<Entity>> entities, Light light) {
		culler = new FrustumCuller();
		for(TexturedModel model : entities.keySet()) {
			prepareTexturedModel(model);
			List<Entity> batch = entities.get(model);
			for (Entity entity : batch) {
				if(!culler.isInFrustum(entity.getPosition(), 25)) {
//					continue;
				}
				prepareComponents(entity, light);
				if(verifyRender()) {
					cancel();
					continue;
				}
				prepareInstance(entity);
				GL11.glDrawElements(GL11.GL_TRIANGLES, model.getModel().getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
			}
			unbindTexturedModel();
		}
	}
	
	private void prepareComponents(Entity entity, Light light) {
		if(entity.hasComponent(ComponentType.Sway))
			shader.loadWindSway(true);
		if(entity.hasComponent(ComponentType.RenderDistance)) {
			RenderDistanceComponent distance = (RenderDistanceComponent) entity.getComponent(ComponentType.RenderDistance);
			if(DistanceUtils.isInDistanceFromCam(entity.getPosition(), distance.getDistance())) {
				cancelRender();
			}
		}
		if(entity.hasComponent(ComponentType.Material)) {
			MaterialComponent component = (MaterialComponent) entity.getComponent(ComponentType.Material);
			shader.stop();
			materialRenderer.render(entity, light);
			shader.start();
			cancelRender();
		}
	}
	
	private void prepareTexturedModel(TexturedModel model) {
		RawModel rm = model.getModel();
		if(model.getTexture() == null)
			return;
		GL30.glBindVertexArray(rm.getVaoID());
		OpenGL.enableVertexAttribArrays(0,1,2);
		if (model.getTexture().isHasTransparency())
			OpenGL.disableCull();
		shader.loadSpecular(model.getTexture().getShineDamper(), model.getTexture().getReflectivity());
		shader.loadFakeLighting(model.getTexture().isFakeLighting());
		OpenGL.activateTexture(0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, model.getTexture().getID());
	}
	
	private void unbindTexturedModel() {
		OpenGL.disableVertexAttribArrays(0,1,2);
		GL30.glBindVertexArray(0);
	}
	
	private void prepareInstance(Entity entity) {
		shader.loadTransformationMatrix(MathUtils.createTransformationMatrix(entity.getPosition(), 
				entity.getRx(), entity.getRy(), entity.getRz(), entity.getScale()));
		
	}
	
	private boolean shouldCancelRender = false;
	
	private void cancelRender() {
		shouldCancelRender = true;
	}
	
	private boolean verifyRender() {
		return shouldCancelRender;
	}
	
	private void cancel() {
		shouldCancelRender = false;
	}
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * 
	 * 
	public void render(Light light, Camera camera) {
		prepare();
		shader.start();
		shader.loadLight(light);
		shader.loadViewMatrix(camera);
		
		for (TexturedModel te : entities.keySet()) {
			
		}
		
		shader.stop();
		entities.clear();
		
	}
	
	public void renderEntity(Entity entity, StaticShader shader) {
		TexturedModel tm = entity.getTm();
		RawModel rm = tm.getModel();
		GL30.glBindVertexArray(rm.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL20.glEnableVertexAttribArray(1);
		GL20.glEnableVertexAttribArray(2);
		
		//GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, model.getVertexCount());
		shader.loadSpecular(tm.getTexture().getShineDamper(), tm.getTexture().getReflectivity());
		shader.loadTransformationMatrix(MathUtils.createTransformationMatrix(entity.getPosition(), 
				entity.getRx(), entity.getRy(), entity.getRz(), entity.getScale()));
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, entity.getTm().getTexture().getID());
		
		GL11.glDrawElements(GL11.GL_TRIANGLES, rm.getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
		GL20.glDisableVertexAttribArray(0);
		GL20.glDisableVertexAttribArray(1);
		GL20.glDisableVertexAttribArray(2);
		GL30.glBindVertexArray(0);
	}
	
	public void renderTexturedModel(TexturedModel model) {
		RawModel rm = model.getModel();
		GL30.glBindVertexArray(rm.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL20.glEnableVertexAttribArray(1);
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, model.getTexture().getID());
		//GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, model.getVertexCount());
		GL11.glDrawElements(GL11.GL_TRIANGLES, rm.getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
		GL20.glDisableVertexAttribArray(0);
		GL20.glDisableVertexAttribArray(1);
		GL30.glBindVertexArray(0);
	}
	
	public void renderRawModel(RawModel model) {
		GL30.glBindVertexArray(model.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		//GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, model.getVertexCount());
		GL11.glDrawElements(GL11.GL_TRIANGLES, model.getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
		GL20.glDisableVertexAttribArray(0);
		GL30.glBindVertexArray(0);
	}
	*/

	

}
