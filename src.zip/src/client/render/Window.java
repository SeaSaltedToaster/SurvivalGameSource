package client.render;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.*;

import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;
import client.constants.Constants;
import client.render.display.Callbacks;
import client.render.display.WindowManager;
import client.util.gl.GLFWUtils;
import client.util.time.TimeManager;

public class Window {
	
	private static int currentWidth = Constants.DISPLAY_WIDTH;
	private static int currentHeight = Constants.DISPLAY_HEIGHT;
	
	private static long windowID;
	
	public Window(String title) {
		windowID = createWindow(title);
		WindowManager.setWindowID(windowID);
		Callbacks.init();
	}
	
	private long createWindow(String title) {
		GLFWUtils.init();
		GLFWVidMode vidmode = glfwGetVideoMode(glfwGetPrimaryMonitor());
		
		long windowID = glfwCreateWindow(currentWidth, currentHeight, title, NULL, NULL);
		
		int x = (vidmode.width() - currentWidth);
		int y = (vidmode.height() - currentHeight);
		
		glfwSetWindowPos(windowID, x/2, y/2);	
		
		glfwMakeContextCurrent(windowID);
		GL.createCapabilities();
		
		glfwSetInputMode(windowID, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
		
		return windowID;
	}
	
	public void update() {
    	glfwSwapBuffers(windowID);
    	glfwPollEvents();
    	
    	TimeManager.updateTimer();
    	GLFWUtils.sync(512);
    	WindowManager.updateWindowSize();
	}
	
	public long getWindowID() {
		return windowID;
	}
	
	public static boolean shouldClose() {
		if (!glfwWindowShouldClose(windowID))
			return false;
		return true;
	}
	
	public void cleanUp() {
		glfwHideWindow(windowID);
		glfwDestroyWindow(windowID);
	}
	
	public void setTitle(String title) {
		glfwSetWindowTitle(windowID, title);
	}
	
    public static float getDelta() {
    	return (float) TimeManager.getDelta();
    }

	public int getFps() {
		return TimeManager.getFps();
	}

	public double getDeltaTime() {
		return getDelta();
	}
	
	public static float getAspectRatio() {
		return (float) (WindowManager.getWindowSizeX(windowID) / WindowManager.getWindowSizeY(windowID));
	}
	
}
