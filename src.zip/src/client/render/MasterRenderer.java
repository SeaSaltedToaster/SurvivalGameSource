package client.render;

import org.lwjgl.glfw.GLFW;
import client.Engine;
import client.animation.renderer.AnimatedModelRenderer;
import client.constants.Constants;
import client.engine.EngineVariables;
import client.entities.Camera;
import client.entities.Entity;
import client.entities.Light;
import client.init.EntityResources;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.math.Vector3f;
import client.render.batch.EntityBatcher;
import client.shaders.StaticShader;
import client.shaders.TemplateShader;
import client.shadows.ShadowMapRenderer;
import client.thread.GlRequestProcessor;
import client.util.ProjectionMatrixUtils;
import client.util.gl.OpenGL;
import game.main.states.Game;
import game.world.chunk.TerrainChunk;
import game.world.render.ChunkRenderer;

public class MasterRenderer {
	
	private StaticShader shader;
	private TemplateShader templateShader = new TemplateShader();
	
	private EntityRenderer renderer;
	private AnimatedModelRenderer animatedRenderer;
	private ChunkRenderer chunkRenderer;
	private ShadowMapRenderer shadowRenderer;
	
	private EntityBatcher batcher;
	
	public MasterRenderer() {
		init();
		GlRequestProcessor.init();
		shader = new StaticShader();
		renderer = new EntityRenderer(shader, ProjectionMatrixUtils.getProjectionMatrix());
		batcher = new EntityBatcher();
		animatedRenderer = new AnimatedModelRenderer();
		chunkRenderer = new ChunkRenderer();
		shadowRenderer = new ShadowMapRenderer();
	}
	
	private void init() {	
		ProjectionMatrixUtils.generateProjectionMatrix();
		OpenGL.setPolygonFill();
	}
	
	public void prepare() {
		OpenGL.enableCull();
		OpenGL.refreshGL();
		OpenGL.clearColor(EngineVariables.skyColor, Constants.BACKGROUND_A);
		OpenGL.activateTexture(5);
		OpenGL.setDepthTest(true);
	}
	
	public void render(Light light, Camera camera) {
		prepare();
		loadShaderVariables(light, camera);
		shadowRenderer.render(batcher.getDynamicBatch().getEntities(), light);
		renderer.renderEntities(batcher.getDynamicBatch().getEntities(), light);
		animatedRenderer.render(EntityResources.data, camera, new Vector3f(0,-1,0));
		for(Entity chunk : Game.chunks)
			chunkRenderer.renderEntities(chunk, light); //Move?
		finishRendering();
		
		GlRequestProcessor.dealWithTopRequests();
	}
	
	private void finishRendering() {
		OpenGL.disableCull();
		shader.stop();
		batcher.clear();
	}
	
	private void loadShaderVariables(Light light, Camera camera) {
		shader.start();
		shader.loadLight(light);
		shader.loadViewMatrix(camera);
		shader.loadFog(Constants.FOG_DENSITY, Constants.FOG_GRADIENT);
		shader.loadTime((float) GLFW.glfwGetTime());
	}
	
	public void cleanUp() {
		shader.cleanUp();
		templateShader.cleanUp();
		batcher.clear();
		GlRequestProcessor.end();
	}
	
	public void processEntity(Entity entity) {	
		batcher.processDynamicEntity(entity);
	}
	
}
