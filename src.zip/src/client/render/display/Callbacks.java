package client.render.display;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWScrollCallback;

import client.util.input.CursorPositionCallback;
import client.util.input.KeyCallback;
import client.util.input.MouseButtonCallback;
import client.util.input.ScrollCallback;

public class Callbacks {
	
	private static ScrollCallback callback;
	private static MouseButtonCallback mouseButtonCallback;
	private static GLFWCursorPosCallback cursorPositionCallback = new CursorPositionCallback();
	private static KeyCallback keyCallback;
	
	private static double scrollValue = 0;
	private static double scrollValueX = 0;
	private static int clickValue = -1;
	private static float lastValueY = 0;
	private static float lastValueX = 0;
	private static double mouseDx = 0;
	private static double mouseDy = 0;
	
	public static void init() {
		long windowID = WindowManager.getWindowID();
		
		keyCallback = new KeyCallback();
		mouseButtonCallback = new MouseButtonCallback();
		callback = new ScrollCallback();
		
		GLFW.glfwSetScrollCallback(windowID, callback);
		GLFW.glfwSetMouseButtonCallback(windowID, mouseButtonCallback);
		GLFW.glfwSetKeyCallback(windowID, keyCallback);
	}

	public static ScrollCallback getCallback() {
		return callback;
	}

	public static MouseButtonCallback getMouseButtonCallback() {
		return mouseButtonCallback;
	}

	public static GLFWCursorPosCallback getCursorPositionCallback() {
		return cursorPositionCallback;
	}

	public static KeyCallback getKeyCallback() {
		return keyCallback;
	}
	
	public static double getScrollValue() {
		return scrollValue;
	}

	public static double getScrollValueX() {
		return scrollValueX;
	}

	public static int getClickValue() {
		return clickValue;
	}

	public static float getLastValueY() {
		return lastValueY;
	}

	public static float getLastValueX() {
		return lastValueX;
	}

	public static double getMouseDx() {
		return mouseDx;
	}

	public static double getMouseDy() {
		return mouseDy;
	}
	
	public static void setScrollValue(double scrollValue) {
		Callbacks.scrollValue = scrollValue;
	}

	public static void setScrollValueX(double scrollValueX) {
		Callbacks.scrollValueX = scrollValueX;
	}

	public static void setClickValue(int clickValue) {
		Callbacks.clickValue = clickValue;
	}

	public static void setLastValueY(float lastValueY) {
		Callbacks.lastValueY = lastValueY;
	}

	public static void setLastValueX(float lastValueX) {
		Callbacks.lastValueX = lastValueX;
	}

	public static void setMouseDx(double mouseDx) {
		Callbacks.mouseDx = mouseDx;
	}

	public static void setMouseDy(double mouseDy) {
		Callbacks.mouseDy = mouseDy;
	}

	public void glfwScrollCallback(long windowID, double dx, double dy) {
		scrollValue = dy;
		scrollValueX = dx;
	}
	
	public void glfwMouseButtonCallback(long windowID, int button, int action, int mods) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && action == GLFW.GLFW_PRESS) {
			clickValue = 0;
		} else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && action == GLFW.GLFW_PRESS) {
			clickValue = 1;
		} else if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW.GLFW_PRESS) {
			clickValue = 2;
		} else {
			clickValue = -1;
		}
	}
	
	public void glfwCursorPos(long windowID, double dx, double dy) {
		mouseDx = dx;
		mouseDy = dy;
	}

}
