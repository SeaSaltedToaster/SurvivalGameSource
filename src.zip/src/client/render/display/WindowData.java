package client.render.display;

public class WindowData {

}
