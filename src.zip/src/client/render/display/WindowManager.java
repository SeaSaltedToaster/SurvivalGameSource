package client.render.display;

import static org.lwjgl.glfw.GLFW.glfwGetCursorPos;
import static org.lwjgl.glfw.GLFW.glfwGetWindowSize;
import static org.lwjgl.glfw.GLFW.glfwHideWindow;
import static org.lwjgl.glfw.GLFW.glfwShowWindow;

import java.nio.DoubleBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class WindowManager {
	
	private static long windowID;

	public static void hide() {
		glfwHideWindow(windowID);
	}
	
	public static void show() {
		glfwShowWindow(windowID);
	}
	
	public static double getTime() {
		return GLFW.glfwGetTime();
	}
	
	public static void updateWindowSize() {
	    IntBuffer widthBuffer = BufferUtils.createIntBuffer(1); IntBuffer heightBuffer = BufferUtils.createIntBuffer(1);
	    GLFW.glfwGetWindowSize(windowID, widthBuffer, heightBuffer);
	    	
	    int width = widthBuffer.get(0); int height = heightBuffer.get(0);
	    GL11.glViewport(0, 0, width, height);
	}
	    
	public static double getCursorPosX(long windowID) {
	    DoubleBuffer posX = BufferUtils.createDoubleBuffer(1);
	    glfwGetCursorPos(windowID, posX, null);
	    return posX.get(0);
	}
	    
	public static double getCursorPosY(long windowID) {
	    DoubleBuffer posY = BufferUtils.createDoubleBuffer(1);
	    glfwGetCursorPos(windowID, null, posY);
	    return posY.get(0);
	}
	    
	public static double getCursorPosX() {
	    DoubleBuffer posX = BufferUtils.createDoubleBuffer(1);
	    glfwGetCursorPos(windowID, posX, null);
	    return posX.get(0);
	}
	    
	public static double getCursorPosY() {
	    DoubleBuffer posY = BufferUtils.createDoubleBuffer(1);
	    glfwGetCursorPos(windowID, null, posY);
	    return posY.get(0);
	}
	    
	public static double getWindowSizeX(long windowID) {
	    IntBuffer posX = BufferUtils.createIntBuffer(1);
	    glfwGetWindowSize(windowID, posX, null);
	    return posX.get(0);
	}
	    
	public static double getWindowSizeY(long windowID) {
	    IntBuffer posY = BufferUtils.createIntBuffer(1);
	    glfwGetWindowSize(windowID, null, posY);
	    return posY.get(0);
	}

	public static long getWindowID() {
		return windowID;
	}

	public static void setWindowID(long windowID) {
		WindowManager.windowID = windowID;
	}
	
}
