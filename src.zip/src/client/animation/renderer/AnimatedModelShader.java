package client.animation.renderer;

import client.animation.uni.UniformMat4Array;
import client.animation.uni.UniformMatrix;
import client.animation.uni.UniformSampler;
import client.animation.uni.UniformVec3;
import client.util.xml.MyFile;

public class AnimatedModelShader extends AnimationShaderProgram {

	private static final int MAX_JOINTS = 50;// max number of joints in a skeleton
	private static final int DIFFUSE_TEX_UNIT = 1;

	private static final MyFile VERTEX_SHADER = new MyFile("client", "animation", "renderer", "animatedEntityVertex.glsl");
	private static final MyFile FRAGMENT_SHADER = new MyFile("client", "animation", "renderer", "animatedEntityFragment.glsl");

	protected UniformMatrix projectionViewMatrix = new UniformMatrix("projectionViewMatrix");
	protected UniformMatrix transformationMatrix = new UniformMatrix("transformationMatrix");
	protected UniformVec3 lightDirection = new UniformVec3("lightDirection");
	protected UniformMat4Array jointTransforms = new UniformMat4Array("jointTransforms", MAX_JOINTS);
	private UniformSampler diffuseMap = new UniformSampler("diffuseMap");

	/**
	 * Creates the shader program for the {@link AnimatedModelRenderer} by
	 * loading up the vertex and fragment shader code files. It also gets the
	 * location of all the specified uniform variables, and also indicates that
	 * the diffuse texture will be sampled from texture unit 0.
	 */
	public AnimatedModelShader() {
		super(VERTEX_SHADER, FRAGMENT_SHADER, "in_position", "in_textureCoords", "in_normal", "in_jointIndices",
				"in_weights");
		super.storeAllUniformLocations(projectionViewMatrix, diffuseMap, lightDirection, jointTransforms, transformationMatrix);
		connectTextureUnits();
	}

	protected void loadLightVariables() {
		for (int i = 0; i < 4; i++) {
			UniformVec3 lightColour = new UniformVec3("lightAttenuation");
			UniformVec3 lightAttenuation = new UniformVec3("lightDirection");
		}
	}
	
	/**
	 * Indicates which texture unit the diffuse texture should be sampled from.
	 */
	private void connectTextureUnits() {
		super.start();
		diffuseMap.loadTexUnit(DIFFUSE_TEX_UNIT);
		super.stop();
	}

}
