package client.animation.renderer;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import client.Engine;
import client.animation.model.AnimatedModel;
import client.entities.Camera;
import client.entities.Entity;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.math.Vector3f;
import client.util.ProjectionMatrixUtils;
import game.entities.components.AnimationComponent;
import game.entities.components.ComponentType;

public class AnimatedModelRenderer {

	private AnimatedModelShader shader;

	public AnimatedModelRenderer() {
		this.shader = new AnimatedModelShader();
	}

	public void render(AnimatedModel entity, Camera camera, Vector3f lightDir) {
		prepare(camera, lightDir, new Entity(null, new Vector3f(0,0,0),0,0,0,1));
		prepare();
		entity.getModel().bind(0, 1, 2, 3, 4);
		shader.jointTransforms.loadMatrixArray(entity.getJointTransforms());
		GL11.glDrawElements(GL11.GL_TRIANGLES, entity.getModel().getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
		entity.getModel().unbind(0, 1, 2, 3, 4);
		finish();
	}
	
	public void render(Entity entity, Camera camera, Vector3f lightDir) {
		prepare(camera, lightDir, entity);
		prepare();
		
		AnimationComponent animation = (AnimationComponent) entity.getComponent(ComponentType.Animation);
		
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, animation.getModel().getTexture().getID());
		
        animation.getModel().getModel().bind(0, 1, 2, 3, 4);
		shader.jointTransforms.loadMatrixArray(animation.getModel().getJointTransforms());
		GL11.glDrawElements(GL11.GL_TRIANGLES, animation.getModel().getModel().getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
		animation.getModel().getModel().unbind(0, 1, 2, 3, 4);
		finish();
	}
	
	public void prepare() {
//        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT|GL11.GL_DEPTH_BUFFER_BIT);
	}

	public void cleanUp() {
		shader.cleanUp();
	}

	private void prepare(Camera camera, Vector3f lightDir, Entity entity) {
		shader.start();
		shader.projectionViewMatrix.loadMatrix(ProjectionMatrixUtils.getProjectionMatrix());
		
		prepareInstance(entity);
	}
	
	private void prepareInstance(Entity entity) {
//		shader.transformationMatrix.loadMatrix(MathUtils.createTransformationMatrix(entity.getPosition(), 
//				entity.getRx(), entity.getRy(), entity.getRz(), entity.getScale()));
		shader.transformationMatrix.loadMatrix(MathUtils.createTransformationMatrix(new Vector3f(0,5,0), 
				0, 0, 0, 2));
		
	}

	private void finish() {
		shader.stop();
	}

}
