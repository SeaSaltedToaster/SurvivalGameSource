package client.animation.loaders;

import java.util.HashMap;
import java.util.Map;

import client.animation.Animation;
import client.animation.data.AnimatedModelData;
import client.animation.data.AnimationData;
import client.animation.data.JointData;
import client.animation.data.JointTransformData;
import client.animation.data.KeyFrameData;
import client.animation.data.MeshData;
import client.animation.data.SkeletonData;
import client.animation.model.AnimatedModel;
import client.animation.model.Joint;
import client.animation.model.JointTransform;
import client.animation.model.KeyFrame;
import client.math.Matrix4f;
import client.math.Quaternion;
import client.math.Vector3f;
import client.render.collada.ColladaLoader;
import client.render.model.RawModel;
import client.texture.Texture;
import client.util.Vao;
import client.util.xml.MyFile;

public class AnimatedModelLoader {

	public static Animation loadAnimation(MyFile colladaFile) {
		AnimationData animationData = ColladaLoader.loadColladaAnimation(colladaFile);
		KeyFrame[] frames = new KeyFrame[animationData.keyFrames.length];
		for (int i = 0; i < frames.length; i++) {
			frames[i] = createKeyFrame(animationData.keyFrames[i]);
		}
		return new Animation(animationData.lengthSeconds, frames);
	}
	
	public static AnimatedModel loadEntity(MyFile modelFile, Texture tex) {
		AnimatedModelData entityData = ColladaLoader.loadColladaModel(modelFile, 3);
		RawModel m = new RawModel(createVao(entityData.getMeshData()));
		SkeletonData skeletonData = entityData.getJointsData();
		Joint headJoint = createJoints(skeletonData.headJoint);
		return new AnimatedModel(m, tex, headJoint, skeletonData.jointCount);
	}
	
	private static Joint createJoints(JointData data) {
		Joint joint = new Joint(data.index, data.nameId, data.bindLocalTransform);
		for (JointData child : data.children) {
			joint.addChild(createJoints(child));
		}
		return joint;
	}

	private static KeyFrame createKeyFrame(KeyFrameData data) {
		Map<String, JointTransform> map = new HashMap<String, JointTransform>();
		for (JointTransformData jointData : data.jointTransforms) {
			JointTransform jointTransform = createTransform(jointData);
			map.put(jointData.jointNameId, jointTransform);
		}
		return new KeyFrame(data.time, map);
	}

	private static JointTransform createTransform(JointTransformData data) {
		Matrix4f mat = data.jointLocalTransform;
		Vector3f translation = new Vector3f(mat.m30, mat.m31, mat.m32);
		Quaternion rotation = Quaternion.fromMatrix(mat);
		return new JointTransform(translation, rotation);
	}
	
	private static Vao createVao(MeshData data) {
		Vao vao = Vao.create();
		vao.bind();
		vao.createIndexBuffer(data.getIndices());
		vao.createAttribute(0, data.getVertices(), 3);
		vao.createAttribute(1, data.getTextureCoords(), 2);
		vao.createAttribute(2, data.getNormals(), 3);
		vao.createIntAttribute(3, data.getJointIds(), 3);
		vao.createAttribute(4, data.getVertexWeights(), 3);
		vao.unbind();
		return vao;
	}
	
}
