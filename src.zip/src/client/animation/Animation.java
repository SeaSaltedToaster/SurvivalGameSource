package client.animation;

import client.animation.model.KeyFrame;

public class Animation {
	
	private final float length;//in seconds
	private final KeyFrame[] keyFrames;

	public Animation(float lengthInSeconds, KeyFrame[] frames) {
		this.keyFrames = frames;
		this.length = lengthInSeconds;
	}

	/**
	 * @return The length of the animation in seconds.
	 */
	public float getLength() {
		return length;
	}

	public KeyFrame[] getKeyFrames() {
		return keyFrames;
	}

}
