 package client.engine;

import client.Engine;
import client.constants.Constants;
import client.math.Vector3f;

public class EngineVariables {
	
	public static String gameVersion = " (PreAlpha 1.6)";
	public static String gameName = "Survival Game";
	
	public static Vector3f skyColor = new Vector3f(Constants.BACKGROUND_R, Constants.BACKGROUND_G, Constants.BACKGROUND_B);
	
	public static void setSkyColor(Vector3f color) {
		skyColor = color;
	}

}
