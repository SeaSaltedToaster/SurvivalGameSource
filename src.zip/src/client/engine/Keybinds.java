package client.engine;

import org.lwjgl.glfw.GLFW;

public class Keybinds {

	public static final int Interact = GLFW.GLFW_KEY_E;
	public static final int CloseMenu = GLFW.GLFW_KEY_ESCAPE;
	
	public static final int LMB = GLFW.GLFW_KEY_T;
	
	public static final int FORWARD = GLFW.GLFW_KEY_W;
	public static final int BACKWARD = GLFW.GLFW_KEY_S;
	public static final int LEFT = GLFW.GLFW_KEY_A;
	public static final int RIGHT = GLFW.GLFW_KEY_D;
	
}
