package client.engine.camera;

import client.engine.Keybinds;
import client.math.Vector3f;
import client.util.input.Input;

public class FirstPersonCamera extends Camera {

	private float speed, verticalSpeed;
	
	public FirstPersonCamera() {
		this.setPosition(new Vector3f(0,0,0));
		
		this.setYaw(0);
		this.setRoll(0);
		this.setPitch(90);
	}
	
	@Override
	public void updateCamera() {
		checkInput();
	}
	
	private void checkInput() {
		speed = 0;
		if(Input.isKeyPressed(Keybinds.FORWARD))
			speed = 10;
		if(Input.isKeyPressed(Keybinds.BACKWARD))
			speed = -10;
		
		verticalSpeed = 0;
	}
	
}
