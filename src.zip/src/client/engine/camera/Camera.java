package client.engine.camera;

import client.math.MathUtils;
import client.math.Matrix4f;
import client.math.Vector3f;
import client.util.ProjectionMatrixUtils;

public class Camera implements ICamera {

	private Vector3f position;
	private float yaw, pitch, roll;
	
	@Override
	public Matrix4f getViewMatrix() {
		return MathUtils.createViewMatrix(this);
	}

	@Override
	public Matrix4f getProjectionMatrix() {
		return ProjectionMatrixUtils.getProjectionMatrix();
	}

	@Override
	public Matrix4f getProjectionViewMatrix() {
		return null;
	}

	@Override
	public void updateCamera() {
		//Update in child class
	}

	public Vector3f getPosition() {
		return position;
	}

	public float getYaw() {
		return yaw;
	}

	public float getPitch() {
		return pitch;
	}

	public float getRoll() {
		return roll;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public void setYaw(float yaw) {
		this.yaw = yaw;
	}

	public void setPitch(float pitch) {
		this.pitch = pitch;
	}

	public void setRoll(float roll) {
		this.roll = roll;
	}

}
