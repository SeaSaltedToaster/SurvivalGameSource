package client.engine;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {

	public static void log(String message) {
		SimpleDateFormat formatter= new SimpleDateFormat("HH:mm:ss");
		Date date = new Date(System.currentTimeMillis());
		
		System.out.println(message + "["+formatter.format(date)+"]");
	}
	
	public static void log(String message, Class from) {
		SimpleDateFormat formatter= new SimpleDateFormat("HH:mm:ss");
		Date date = new Date(System.currentTimeMillis());
		
		System.out.println(from.getSimpleName()+": "+message + " ["+formatter.format(date)+"]");
	}
	
}
