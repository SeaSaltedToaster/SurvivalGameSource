package client.shadows;

import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MathUtil;

import client.Engine;
import client.entities.Entity;
import client.entities.Light;
import client.math.MathUtils;
import client.math.Matrix4f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.shaders.shadow.ShadowShader;
import client.util.ProjectionMatrixUtils;
import client.util.gl.OpenGL;

public class ShadowMapRenderer {

	private Matrix4f projectionViewMatrix;
	private ShadowShader shader;

	public ShadowMapRenderer() {
		this.shader = new ShadowShader();
		this.projectionViewMatrix = null;
	}

	public void render(Map<TexturedModel, List<Entity>> entities, Light light) {
		prepare(light);
		for (TexturedModel model : entities.keySet()) {
			RawModel rawModel = model.getModel();
			prepareTexturedModel(rawModel);
			for (Entity entity : entities.get(model)) {
				prepareInstance(entity);
				GL11.glDrawElements(GL11.GL_TRIANGLES, rawModel.getVertexCount(),
						GL11.GL_UNSIGNED_INT, 0);
			}
			unbindTexturedModel();
		}
		finish(light);
	}
	
	private void unbindTexturedModel() {
		OpenGL.disableVertexAttribArrays(0,1,2);
		GL30.glBindVertexArray(0);
	}
	
	private void prepare(Light light) {
		projectionViewMatrix = ProjectionMatrixUtils.getProjectionMatrix().multiply(MathUtils.createViewMatrix(Engine.getCamera()));
		
		light.getLightShadowMap().prepare();
		light.getLightShadowMap().bindFrameBuffer();
		
//		shader.start();
//		shader.loadMvpMatrix(projectionViewMatrix);
	}
	
	private void finish(Light light) {
		light.getLightShadowMap().unbindFrameBuffer();
//		shader.stop();
	}

	private void prepareTexturedModel(RawModel model) {
		GL30.glBindVertexArray(model.getVaoID());
		OpenGL.enableVertexAttribArrays(0,1,2);
	}

	private void prepareInstance(Entity entity) {
		Matrix4f modelMatrix = MathUtils.createTransformationMatrix(entity.getPosition(),
				entity.getRx(), entity.getRy(), entity.getRz(), entity.getScale());
		Matrix4f mvpMatrix = Matrix4f.mul(projectionViewMatrix, modelMatrix, null);
		shader.loadMvpMatrix(mvpMatrix);
	}
	
}
