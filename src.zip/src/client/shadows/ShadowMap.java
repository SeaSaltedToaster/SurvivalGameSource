package client.shadows;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import client.Engine;
import client.entities.Camera;
import client.render.display.WindowManager;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL30.*;

import org.lwjgl.glfw.GLFW;

public class ShadowMap {

	protected int depthFBO;
	protected int depthTexture;
	
	private static int SHADOW_WIDTH = 1024;
	private static int SHADOW_HEIGHT = 1024;
	
	private Camera camera;
	
	public ShadowMap() {
		camera = Engine.getCamera();
		
		generateDepthMap();
	}
	
	public void prepare() {
		glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
		glBindFramebuffer(GL_FRAMEBUFFER, depthFBO);
	}
	
	public void bindFrameBuffer() {
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, depthFBO);
		GL11.glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
	}
	
	public void unbindFrameBuffer() {
		GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
		GL11.glViewport(0, 0, (int) WindowManager.getWindowSizeX(Engine.getWindow().getWindowID()), (int) WindowManager.getWindowSizeY(Engine.getWindow().getWindowID()));
	}
	
	public void unbind() {
		glBindFramebuffer(GL_FRAMEBUFFER, 0);
	}
	
	public void generateDepthMap() {
		//Create Texture
		depthTexture = glGenTextures();
		glBindTexture(GL_TEXTURE_2D, depthFBO);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, SHADOW_WIDTH, SHADOW_HEIGHT, 0, GL_DEPTH_COMPONENT, GL_FLOAT, MemoryUtil.NULL); //NULL Type
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); 
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); 
		
		//Create FBO
		depthFBO = GL30.glGenFramebuffers();
		
		//Attach FBO to Textures
		glBindFramebuffer(GL_FRAMEBUFFER, depthFBO);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depthTexture, 0);
		glDrawBuffer(GL_NONE);
		glReadBuffer(GL_NONE);
		glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0); 
	}
	
	public void delete() {
		
	}
	
}
