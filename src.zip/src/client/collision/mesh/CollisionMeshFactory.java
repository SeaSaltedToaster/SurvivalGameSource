package client.collision.mesh;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.bulletphysics.collision.shapes.BvhTriangleMeshShape;
import com.bulletphysics.collision.shapes.IndexedMesh;
import com.bulletphysics.collision.shapes.TriangleIndexVertexArray;

import client.math.Vector3f;

public class CollisionMeshFactory {

	public static CustomCollisionMesh buildCollisionMesh(float[] coords, int[] indices) {
		IndexedMesh indexedMesh = getIndexedMesh(coords, indices);
        BvhTriangleMeshShape meshShape = getMeshShape(indexedMesh);
        
        return new CustomCollisionMesh(meshShape, new Vector3f(0,0,0));
	}
	
	private static IndexedMesh getIndexedMesh(float[] coords, int[] indices) {
		IndexedMesh indexedMesh = new IndexedMesh();
        indexedMesh.numTriangles = indices.length / 3;
        indexedMesh.triangleIndexBase = ByteBuffer.allocateDirect(indices.length*Integer.BYTES).order(ByteOrder.nativeOrder());
        indexedMesh.triangleIndexBase.rewind();
        indexedMesh.triangleIndexBase.asIntBuffer().put(indices);
        indexedMesh.triangleIndexStride = 3 * Integer.BYTES;
        indexedMesh.numVertices = coords.length / 3;
        indexedMesh.vertexBase = ByteBuffer.allocateDirect(coords.length*Float.BYTES).order(ByteOrder.nativeOrder());
        indexedMesh.vertexBase.rewind();
        indexedMesh.vertexBase.asFloatBuffer().put(coords);
        indexedMesh.vertexStride = 3 * Float.BYTES;
        return indexedMesh;
	}
	
	private static BvhTriangleMeshShape getMeshShape(IndexedMesh indexedMesh) {
		TriangleIndexVertexArray vertArray = new TriangleIndexVertexArray();
        vertArray.addIndexedMesh(indexedMesh);

        boolean useQuantizedAabbCompression = false;
        BvhTriangleMeshShape meshShape = new BvhTriangleMeshShape(vertArray, useQuantizedAabbCompression);
        meshShape.setLocalScaling(new javax.vecmath.Vector3f(0.5f, 0.5f, 0.5f));
        return meshShape;
	}
	
}
