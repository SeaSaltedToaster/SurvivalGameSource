package client.collision;

import javax.vecmath.Matrix4f;
import javax.vecmath.Quat4f;
import javax.vecmath.Vector3f;

import com.bulletphysics.collision.broadphase.BroadphaseInterface;
import com.bulletphysics.collision.broadphase.DbvtBroadphase;
import com.bulletphysics.collision.dispatch.CollisionDispatcher;
import com.bulletphysics.collision.dispatch.DefaultCollisionConfiguration;
import com.bulletphysics.collision.shapes.CollisionShape;
import com.bulletphysics.collision.shapes.SphereShape;
import com.bulletphysics.dynamics.DiscreteDynamicsWorld;
import com.bulletphysics.dynamics.RigidBody;
import com.bulletphysics.dynamics.RigidBodyConstructionInfo;
import com.bulletphysics.dynamics.constraintsolver.SequentialImpulseConstraintSolver;
import com.bulletphysics.linearmath.DefaultMotionState;
import com.bulletphysics.linearmath.Transform;

import client.Engine;
import client.collision.objects.CollisionPlane;
import client.collision.objects.CollisionSphere;
import client.engine.Logger;

public class CollisionWorld {

	private BroadphaseInterface broadphase = new DbvtBroadphase();
    private DefaultCollisionConfiguration collisionConfiguration = new DefaultCollisionConfiguration();
    private CollisionDispatcher dispatcher = new CollisionDispatcher(collisionConfiguration);
    private SequentialImpulseConstraintSolver solver = new SequentialImpulseConstraintSolver();

    public static DiscreteDynamicsWorld dynamicsWorld;
    
    CollisionShape fallShape = new SphereShape(1);
    RigidBody fallRigidBody;
    
    public CollisionWorld() {
    	dynamicsWorld = new DiscreteDynamicsWorld(dispatcher, broadphase, solver, collisionConfiguration);
    	dynamicsWorld.setGravity(new javax.vecmath.Vector3f(0, -10, 0));
    	
//    	sphere = new CollisionSphere(new client.math.Vector3f(100,25,100), 1,2);
//    	sphere.enable(dynamicsWorld);
    	
    	DefaultMotionState fallMotionState = new DefaultMotionState(new Transform(new Matrix4f(new Quat4f(0, 0, 0, 1), new javax.vecmath.Vector3f(50, 50, 50), 1.0f)));

    	//This we're going to give mass so it responds to gravity 
    	int mass = 1;

    	Vector3f fallInertia = new Vector3f(0,0,0); 
    	fallShape.calculateLocalInertia(mass,fallInertia); 

    	RigidBodyConstructionInfo fallRigidBodyCI = new RigidBodyConstructionInfo(mass,fallMotionState,fallShape,fallInertia); 
    	fallRigidBody = new RigidBody(fallRigidBodyCI); 
    	dynamicsWorld.addRigidBody(fallRigidBody); 
    }
    
    public void updateTest() {
    	dynamicsWorld.stepSimulation(1/60.f, 10); 

    	Transform trans = new Transform();
        fallRigidBody.getMotionState().getWorldTransform(trans); 
        
        Engine.getEntities().get(0).setPosition(new client.math.Vector3f(0,trans.origin.y,0));
    }

	public static DiscreteDynamicsWorld getDynamicsWorld() {
		return dynamicsWorld;
	}

}
