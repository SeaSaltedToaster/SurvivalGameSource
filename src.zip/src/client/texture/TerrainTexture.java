package client.texture;

public class TerrainTexture {

	private int textureID;
	
	public TerrainTexture(int textureID) {
		this.textureID = textureID;
	}

	public int getTextureID() {
		return textureID;
	}

	
}
