package client.init;

public enum ResourceTypes {
	
	ENTITY, TEXTURE, JSON,
	
}
