package client.init;

public class ResourceLocation {

	private String id = "null";
	private ResourceTypes type = null;
	
	private boolean hasType = false;
	
	public ResourceLocation(String id) {
		this.id = id;
	}
	
	public ResourceLocation(String id, ResourceTypes type) {
		this.id = id;
		this.type = type;
		this.hasType = true;
	}
	
	public String getFileLocation(String id) {
		if(hasType)
			getFileFromType(id);
		return null;
	}
	
	public String getFileFromType(String id) {
		return id;
	}
	
}