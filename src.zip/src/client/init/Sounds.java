package client.init;

import client.audio.management.AudioMaster;

public class Sounds {
	
	public static int click = AudioMaster.loadSound("click");
	public static int LPD = AudioMaster.loadSound("LPD");

}
