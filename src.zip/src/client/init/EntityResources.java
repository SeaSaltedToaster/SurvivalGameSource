package client.init;

import client.Engine;
import client.animation.data.AnimatedModelData;
import client.animation.loaders.AnimatedModelLoader;
import client.animation.loaders.ColladaLoader;
import client.animation.model.AnimatedModel;
import client.engine.Logger;
import client.render.model.TexturedModel;
import client.render.model.testing.Cube;
import client.render.mtl.MaterialLoader;
import client.render.obj.OBJLoader;
import client.render.obj.OBJMaterialLoader;
import client.render.obj.matRender.OBJMaterialModel;
import client.texture.ModelTexture;
import client.texture.Texture;
import client.util.xml.MyFile;
import game.Game;
import game.main.Main;

public class EntityResources {

	public static TexturedModel model;

	public static TexturedModel PIG;
	public static TexturedModel COPPER_BAR;
	public static TexturedModel BERRIES;
	
	public static TexturedModel EMERALD;
	
	public static TexturedModel TREE1;
	public static TexturedModel GRASS1;
	public static TexturedModel GRASS2;
	public static TexturedModel ROCK1;
	
	public static TexturedModel LOG;
	public static TexturedModel COPPER_PANTS;

	
	public static TexturedModel STONE_PICKAXE;
	
	public static AnimatedModel data;
	
	public static OBJMaterialModel materialModel;
	
	public static void load() {
		STONE_PICKAXE = new TexturedModel(OBJLoader.loadObjModel("items/Stone Pickaxe/model", Engine.getLoader()), new ModelTexture(Textures.stone_pickaxe));
		Logger.log("Loaded Asset: STONE_PICKAXE", EntityResources.class);
		COPPER_PANTS = new TexturedModel(OBJLoader.loadObjModel("items/Copper Pants/model", Engine.getLoader()), new ModelTexture(Textures.copper_pants));
		Logger.log("Loaded Asset: COPPER_PANTS", EntityResources.class);
		LOG = new TexturedModel(OBJLoader.loadObjModel("items/Log/model", Engine.getLoader()), new ModelTexture(Textures.log));
		Logger.log("Loaded Asset: LOG", EntityResources.class);
		TREE1 = new TexturedModel(OBJLoader.loadObjModel("tree", Engine.getLoader()), new ModelTexture(Engine.getLoader().loadTexture("tree")));
		Logger.log("Loaded Asset: TREE1", EntityResources.class);
		GRASS1 = new TexturedModel(OBJLoader.loadObjModel("grass", Engine.getLoader()), new ModelTexture(Engine.getLoader().loadTexture("grass")));
		Logger.log("Loaded Asset: GRASS1", EntityResources.class);
		GRASS2 = new TexturedModel(OBJLoader.loadObjModel("grass", Engine.getLoader()), new ModelTexture(Engine.getLoader().loadTexture("snowyGrass")));
		Logger.log("Loaded Asset: GRASS2", EntityResources.class);
		ROCK1 = new TexturedModel(OBJLoader.loadObjModel("rock", Engine.getLoader()), new ModelTexture(Textures.stoneBricks));
		Logger.log("Loaded Asset: ROCK1", EntityResources.class);
		EMERALD = new TexturedModel(OBJLoader.loadObjModel("items/Emerald/model", Engine.getLoader()), new ModelTexture(Textures.emerald));
		Logger.log("Loaded Asset: EMERALD", EntityResources.class);
		BERRIES = new TexturedModel(OBJLoader.loadObjModel("items/Berries/model", Engine.getLoader()), new ModelTexture(Textures.berries));
		Logger.log("Loaded Asset: BERRIES", EntityResources.class);
		COPPER_BAR = new TexturedModel(OBJLoader.loadObjModel("items/Copper Bar/model", Engine.getLoader()), new ModelTexture(Textures.copper_bar));
		Logger.log("Loaded Asset: COPPER_BAR", EntityResources.class);
		PIG = new TexturedModel(OBJLoader.loadObjModel("pig", Engine.getLoader()), new ModelTexture(Textures.berries));
		Logger.log("Loaded Asset: PIG", EntityResources.class);
		model = new TexturedModel(Cube.getMesh(), new ModelTexture(Textures.hunger));
		Logger.log("Loaded Asset: model", EntityResources.class);
		
		data = AnimatedModelLoader.loadEntity(new MyFile("res/model.dae"), new Texture(1));
		
//		materialModel = OBJMaterialLoader.loadObjModel("candle", Engine.getLoader());
		materialModel = OBJMaterialLoader.loadObjModel("WoodenWall", Engine.getLoader());
	}
}
