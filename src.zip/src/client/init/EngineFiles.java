package client.init;

public class EngineFiles {

	public static final String RESOURCE_FOLDER = "/res/";
	public static final String ENTITY_FOLDER = "/res/entities/";
	public static final String TEXTURES_FOLDER = "/res/textures/";
	public static final String ITEMS_FOLDER = "/res/items/";
	public static final String UIS_FOLDER = "uis/";
	
}
