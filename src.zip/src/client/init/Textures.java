package client.init;

import client.Engine;
import game.main.Main;

public class Textures {

	public static int grassy = Engine.getLoader().loadTexture("grassy");
	public static int ground = Engine.getLoader().loadTexture("ground");
	public static int dirt = Engine.getLoader().loadTexture("dirt");
	public static int Inventory = Engine.getLoader().loadTexture("inventory");
	public static int health = Engine.getLoader().loadTexture("health");
	public static int hunger = Engine.getLoader().loadTexture("hunger");
	public static int stone = Engine.getLoader().loadTexture("structures/dungeon/stone");
	public static int stoneBricks = Engine.getLoader().loadTexture("gray");
	public static int pickaxe = Engine.getLoader().loadTexture("pickaxe");
	public static int stone_pickaxe = Engine.getLoader().loadTexture("items/Stone Pickaxe/texture");
	public static int candle = Engine.getLoader().loadTexture("items/Candle/texture");
	
	
	public static int black = Engine.getLoader().loadTexture("black");
	public static int durability = Engine.getLoader().loadTexture("durability");
	
	public static int arrow = Engine.getLoader().loadTexture("items/Arrow/texture");
	public static int arrow_icon = Engine.getLoader().loadTexture("items/Arrow/test");
	
	public static int back = Engine.getLoader().loadTexture("back");
	
	public static int copper_bar = Engine.getLoader().loadTexture("items/Copper Bar/texture");
	public static int iron__bar_icon = Engine.getLoader().loadTexture("items/Copper Bar/test");
	
	public static int log = Engine.getLoader().loadTexture("items/Log/texture");
	public static int logIcon = Engine.getLoader().loadTexture("items/Log/icon");
	
	public static int copper_pants = Engine.getLoader().loadTexture("items/Copper Pants/texture");
	public static int copper_pants_icon = Engine.getLoader().loadTexture("items/Copper Pants/icon");
	
	public static int emerald = Engine.getLoader().loadTexture("items/Emerald/texture");
	public static int emerald_icon = Engine.getLoader().loadTexture("items/Emerald/icon");
	
	public static int berries = Engine.getLoader().loadTexture("items/Berries/texture");
	public static int berries_icon = Engine.getLoader().loadTexture("items/Berries/icon");
	
	public static int helmet = Engine.getLoader().loadTexture("inventory");
	public static int chestplate = Engine.getLoader().loadTexture("inventory");
	public static int pants = Engine.getLoader().loadTexture("inventory");
	public static int boots = Engine.getLoader().loadTexture("inventory");
	
	public static int selector = Engine.getLoader().loadTexture("selector");
}
