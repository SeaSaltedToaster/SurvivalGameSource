package client.util;

import java.util.List;

import client.guis.core.UiBlock;
import client.math.Vector2f;
import client.math.Vector3f;

public class ArrayUtils {

	public static UiBlock[] combineGuiArrays(UiBlock[] toAdd, UiBlock[] target) { 
		int fal = toAdd.length;
		int sal = target.length;
		UiBlock[] result = new UiBlock[fal + sal]; 
		System.arraycopy(toAdd, 0, result, 0, fal);  
		System.arraycopy(target, 0, result, fal, sal);
		return result;  
	}
	
	public static Object[] combineArrays(Object[] toAdd, Object[] target) { 
		int fal = toAdd.length;
		int sal = target.length;
		Object[] result = new UiBlock[fal + sal]; 
		System.arraycopy(toAdd, 0, result, 0, fal);  
		System.arraycopy(target, 0, result, fal, sal);
		return result;  
	}
	
	public static Object[] combineArrays(float[] toAdd, float[] target) { 
		int fal = toAdd.length;
		int sal = target.length;
		Object[] result = new UiBlock[fal + sal]; 
		System.arraycopy(toAdd, 0, result, 0, fal);   
		System.arraycopy(target, 0, result, fal, sal);
		return result;  
	}
	
	public static int[] toIntArray(List<Integer> list){
		  int[] ret = new int[list.size()];
		  for(int i = 0;i < ret.length;i++)
				 ret[i] = list.get(i);
		  return ret;
		}
	
	public static float[] toFloatArray(List<Float> list){
		  float[] ret = new float[list.size()];
		  for(int i = 0;i < ret.length;i++)
		    ret[i] = list.get(i);
		  return ret;
		}
	
	public static float[] toFloatArray(Vector3f[] list){
		  float[] ret = new float[list.length * 3];
		  int v = 0;
		  for(int i = 0;i < ret.length;i+=3, v++) {
				  ret[i] = list[v].x;
				  ret[i+1] = list[v].y;
				  ret[i+2] = list[v].z;
		  }
		  return ret;
		}
	
	public static float[] toFloatArray(Vector2f[] list){
		  float[] ret = new float[list.length * 2];
		  int v = 0;
		  for(int i = 0;i < ret.length;i+=2, v++) {
				  ret[i] = list[v].x;
				  ret[i+1] = list[v].y;
		  }
		  return ret;
		}
	
}
