package client.util;

import client.Engine;
import client.math.Vector3f;

public class DistanceUtils {

	public static boolean isInDistanceFromCam(Vector3f pos2, float distance) {
		return isInDistance(Engine.getCamera().getPosition(), pos2, distance);
	}
	
	public static boolean isInDistance(Vector3f pos1, Vector3f pos2, float distance) {
		Vector3f distanceVec = pos2.subtract(pos1);
		if(distanceVec.length() > distance) {
			return true;
		}
		return false;
	}
	
}
