package client.util;

import java.nio.ByteBuffer;

import client.math.Vector3f;

public class ByteUtils {

	public static float convertToFloat(byte[] array) {
	    ByteBuffer buffer = ByteBuffer.wrap(array);
	    return buffer.getFloat();
	  }
	
	public static Vector3f ByteArrayToVec3(byte[] array) {
		float x = ByteUtils.convertToFloat(new byte[] { array[0] });
		float y = ByteUtils.convertToFloat(new byte[] { array[1] });
		float z = ByteUtils.convertToFloat(new byte[] { array[2] });
		return new Vector3f(x,y,z);
	}
	
}
