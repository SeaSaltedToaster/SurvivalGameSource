package client.util;

public class Timer {

	public Timer(float time) {
		
	}
	
}
