package client.util.time;

import static org.lwjgl.glfw.GLFW.glfwPollEvents;

import client.constants.Constants;
import client.guis.text.TextMaster;
import client.render.display.WindowManager;
import game.main.Main;

public class TimeManager {

	private static long lostTime = System.nanoTime();
	private static long currTime = lostTime;
	private static long timer = System.currentTimeMillis();
	private static double delta = 0.0;
	private static int fps = 0;
	
	public static void updateTimer() {    	
		currTime = System.nanoTime();
		delta += (currTime - lostTime) / Constants.NS;
		lostTime = currTime;	
		while (delta >= 1.0) {
			glfwPollEvents();
			delta--;
		}
		fps++;		
		if (System.currentTimeMillis() > timer + 1000) {
			if(TextMaster.getTextz().contains(Main.getFpsCounter())) {
				Main.getFpsCounter().setTextString("FPS: "+fps);
			}
			fps = 0;
			timer += 1000;
		}
		
		updateDelta();
	}
	
	public static double deltaTime = 0.0;
	private static double oldTime = 0.0;
	
	private static void updateDelta() {
		double current = WindowManager.getTime();
		deltaTime = current - oldTime;
		oldTime = current;
	}

	public static long getLostTime() {
		return lostTime;
	}

	public static long getCurrTime() {
		return currTime;
	}

	public static long getTimer() {
		return timer;
	}

	public static double getDelta() {
		return delta;
	}

	public static int getFps() {
		return fps;
	}
	
}
