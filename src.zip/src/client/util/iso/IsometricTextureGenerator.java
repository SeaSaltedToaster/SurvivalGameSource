package client.util.iso;

public class IsometricTextureGenerator {

}
