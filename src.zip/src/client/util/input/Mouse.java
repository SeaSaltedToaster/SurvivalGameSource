package client.util.input;

import static org.lwjgl.glfw.GLFW.GLFW_CURSOR;
import static org.lwjgl.glfw.GLFW.GLFW_CURSOR_DISABLED;
import static org.lwjgl.glfw.GLFW.GLFW_CURSOR_NORMAL;
import static org.lwjgl.glfw.GLFW.glfwSetInputMode;

import client.render.Window;
import client.render.display.WindowManager;
import game.main.Main;

public class Mouse {
	
	private static boolean mouseLocked = true;
	
	public static double getMouseCoordsX() {
		double x = -1.0 + 2.0 * WindowManager.getCursorPosX(Main.getWindow().getWindowID()) / WindowManager.getWindowSizeX(Main.getWindow().getWindowID());
		return x;
	}
	    
	public static double getMouseCoordsY() {
	    double y = 1.0 - 2.0 * WindowManager.getCursorPosY(Main.getWindow().getWindowID()) / WindowManager.getWindowSizeY(Main.getWindow().getWindowID());
	    return -y;
	}
	    
	public static void setMouseVisible(boolean lock) {
	    if(lock) {
	    	glfwSetInputMode(WindowManager.getWindowID(), GLFW_CURSOR, GLFW_CURSOR_NORMAL); mouseLocked = false;
	    } else {
	    	glfwSetInputMode(WindowManager.getWindowID(), GLFW_CURSOR, GLFW_CURSOR_DISABLED); mouseLocked = true;
	    }
	}
	
	public static boolean isMouseLocked() {
		return mouseLocked;
	}	
	
}
