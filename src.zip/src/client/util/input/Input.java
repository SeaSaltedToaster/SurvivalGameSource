package client.util.input;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import game.main.Main;

public class Input {

	public static boolean isKeyPressed(int key)
	{
		 return (GLFW.glfwGetKey(Main.getWindow().getWindowID(), key) == GLFW.GLFW_PRESS);
	}
	
	public static boolean isKeyReleased(int key)
	{
	    return (GLFW.glfwGetKey(Main.getWindow().getWindowID(), key) == GLFW.GLFW_RELEASE);
	}
	
}
