package client.util.input;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWKeyCallback;

public class KeyCallback extends GLFWKeyCallback {

	String current = "";
	boolean isTyping = false;
	
	public void reset() {
		current = "";
	}
	
	public void start() {
		isTyping = true;
	}
	
	public void end() {
		isTyping = false;
	}
	
	@Override
	public void invoke(long arg0, int arg1, int arg2, int arg3, int arg4) {
		if(arg3 == GLFW.GLFW_PRESS && arg1 == GLFW.GLFW_MOUSE_BUTTON_1) {
			System.out.println("beep");
		}
		
		if(isTyping && arg3 == GLFW.GLFW_PRESS) {
			if(GLFW.glfwGetKeyName(arg1, 0) != null && arg1 != GLFW.GLFW_KEY_SPACE) {
				current = current + GLFW.glfwGetKeyName(arg1, 0);
			} if(arg1 == GLFW.GLFW_KEY_BACKSPACE) {
				if(current.length() != 0)
					current = current.substring(0, current.length()-1);
			}
			//SPACEBAR?
		}
	}

	public String getCurrent() {
		return current;
	}

	public boolean isTyping() {
		return isTyping;
	}

}
