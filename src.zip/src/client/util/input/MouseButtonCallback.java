package client.util.input;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWMouseButtonCallback;

import client.Engine;

public class MouseButtonCallback extends GLFWMouseButtonCallback {

	private long windowID;
	private int button;
	private int action;
	private int mods;
	
	public void invoke(long windowID, int arg1, int arg2, int arg3) {
		this.windowID = windowID;
		this.button = arg1;
		this.action = arg2;
		this.mods = arg3;
	}
	
//	public boolean isLeftButtonDown() {
//		if (GLFW.glfwGetMouseButton(Engine.getWindow().getWindowID(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) {
//			return true;
//		}
//		return false;
//	}
	
	static int oldState = GLFW.GLFW_RELEASE;
	
	public boolean isLeftButtonDown() {
		int newState = GLFW.glfwGetMouseButton(Engine.getWindow().getWindowID(), GLFW.GLFW_MOUSE_BUTTON_LEFT);
		if (newState ==GLFW.GLFW_PRESS && oldState == GLFW.GLFW_RELEASE) {
			oldState = newState;
		   return true;
		}
		oldState = newState;

		return false;
	}
	
	public boolean isRightButtonDown() {
		if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && action == GLFW.GLFW_PRESS) {
			return true;
		}
		return false;
	}
	
	public boolean isMiddleButtonDown() {
		if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW.GLFW_PRESS) {
			return true;
		}
		return false;
	}

	public int getButton() {
		return button;
	}

	public int getAction() {
		return action;
	}

	public int getMods() {
		return mods;
	}

}
