package client.util;

import client.constants.Constants;
import client.math.MathUtils;
import client.math.Matrix4f;

public class ProjectionMatrixUtils {

	public static Matrix4f projectionMatrix;
	
	public static void generateProjectionMatrix() {
		projectionMatrix = MathUtils.createProjectionMatrix(Constants.FOV, Constants.NEAR_PLANE, Constants.FAR_PLANE);
	}

	public static Matrix4f getProjectionMatrix() {
		return projectionMatrix;
	}

	public static void setProjectionMatrix(Matrix4f projectionMatrix) {
		ProjectionMatrixUtils.projectionMatrix = projectionMatrix;
	}
	
}
