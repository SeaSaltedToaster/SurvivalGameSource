package client.util;

import java.io.File;

public class DirectoryBuilder {

	public static File mods;
	public static File screenshots;
	
	public static void buildDirectory() {
		File main = new File(getWindowsCurrentUserAppDataPath()+"/Toastario");
		main.mkdir();
		
		mods = new File(getWindowsCurrentUserAppDataPath()+"/Toastario/mods");
		if(!mods.exists()) {
			mods.mkdir();
			System.out.println("Creating mods folder....");
		}
		screenshots = new File(getWindowsCurrentUserAppDataPath()+"/Toastario/screenshots");
		if(!screenshots.exists()) {
			screenshots.mkdir();
			System.out.println("Creating screenshots folder....");
		}
		
		File saves = new File(getWindowsCurrentUserAppDataPath()+"/Toastario/saves");
		saves.mkdir();
		File assetPacks = new File(getWindowsCurrentUserAppDataPath()+"/Toastario/assetPacks");
		assetPacks.mkdir();
	}
	 
	public static String getWindowsCurrentUserAppDataPath() {
        return System.getenv("userprofile") + "/AppData/Roaming" ;
    }
	
}
