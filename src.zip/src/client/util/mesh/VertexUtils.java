package client.util.mesh;

import java.util.List;

import client.render.standard.Vertex;

public class VertexUtils {

	public static float[] getPositions(List<Vertex> vertices) {
		float[] positions = new float[(vertices.size()*3)+1];
		for(int i = 0; i < vertices.size() * 3; i+=3) {
			positions[i] = vertices.get(i).position.x;
			positions[i+1] = vertices.get(i).position.y;
			positions[i+2] = vertices.get(i).position.z;
		}
		return positions;
	}
	
}
