package client.util;

import client.math.Vector3f;

public class Ray {

	private Vector3f position;
	private Vector3f direction;
	
	private Vector3f previous;
	private Vector3f end;
	
	public Ray(Vector3f position, Vector3f direction) {
		this.position = position;
		this.direction = direction;
		this.end = position;
		this.previous = direction;
	}
	
	public void step() {
		previous = end;
		end.add(direction);
	}

	public Vector3f getPosition() {
		return position;
	}

	public Vector3f getDirection() {
		return direction;
	}

	public Vector3f getPrevious() {
		return previous;
	}

	public Vector3f getEnd() {
		return end;
	}

	
}
