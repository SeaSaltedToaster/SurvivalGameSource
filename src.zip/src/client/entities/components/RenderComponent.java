package client.entities.components;

public class RenderComponent {

}
