package client.entities;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.constants.Constants;
import client.math.Vector3f;
import client.render.Window;
import client.render.model.TexturedModel;
import client.util.input.Input;
import game.guis.DeathMenu;
import game.guis.bars.HealthBar;
import game.guis.bars.HungerBar;
import game.inventory.container.Container;
import game.inventory.crafting.CraftingPanel;
import game.main.Main;
import game.main.states.Game;

public class Player extends Entity {
	
	public static Container player = new Container(7,4,0.08f,-0.35f,0.05f,"Player",true);
	
	private HealthBar hbar;
	private HungerBar fbar;
	
	public boolean openedHotbar = false;
	
	public Player(TexturedModel tm, Vector3f position, float rx, float ry, float rz, float scale) {
		super(tm, position, rx, ry, rz, scale);
		hbar = new HealthBar();
		fbar = new HungerBar();
		
		CraftingPanel.init();
	}
	
	@Override
	public void update() {
		fbar.subtract(0.0005f); // 10 per minute 0.0005f
		if(fbar.getCurrentFill() > 90 && hbar.getCurrentFill() < 100) {
			hbar.add(0.001f);
		}
		
		if(hbar.currentFill <= 0 && hbar.currentFill > -32767) {
			DeathMenu.show();
			hbar.currentFill = -32767;
		}
		
		if(Input.isKeyPressed(GLFW.GLFW_KEY_E) && !player.isActive()) { //Not in final phase, just for testing
			player.open();
			CraftingPanel.show();
			hbar.hide();
			fbar.hide();
		}
		
		if(player.isActive())
			CraftingPanel.update();
		
		if(Input.isKeyPressed(GLFW.GLFW_KEY_ESCAPE) && player.isActive()) { //Not in final phase, just for testing
			player.close();
			CraftingPanel.hide();
			hbar.show();
			fbar.show();
		}
		
		if(!openedHotbar && !player.isActive()) {
			openedHotbar = true;
			Engine.getTextures().addAll(Game.hotbar.getSlots());
			Engine.getTextures().addAll(Game.hotbar.getSlotUis());
		} else if(openedHotbar && player.isActive()) {
			openedHotbar = false;
			Engine.getTextures().removeAll(Game.hotbar.getSlots());
			Engine.getTextures().removeAll(Game.hotbar.getSlotUis());
		}
		
		DeathMenu.update();
	}

	public static Container getPlayer() {
		return player;
	}

	public HealthBar getHbar() {
		return hbar;
	}

	public HungerBar getFbar() {
		return fbar;
	}
	
}
