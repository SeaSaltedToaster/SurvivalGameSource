package client.entities;

import static org.lwjgl.opengl.GL11.GL_FILL;
import static org.lwjgl.opengl.GL11.GL_FRONT_AND_BACK;
import static org.lwjgl.opengl.GL11.GL_LINE;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWKeyCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallbackI;
import org.lwjgl.glfw.GLFWScrollCallback;
import org.lwjgl.opengl.GL11;

import client.constants.Constants;
import client.math.Vector3f;
import client.render.Window;
import client.render.display.Callbacks;
import client.util.gl.OpenGL;
import client.util.input.CursorPositionCallback;
import client.util.input.Input;
import client.util.input.KeyCallback;
import client.util.input.Mouse;
import client.util.input.MouseButtonCallback;
import client.util.input.ScrollCallback;
import client.util.time.TimeManager;
import game.gamemodes.Gamemode;
import game.guis.DebugMenu;
import game.inventory.InventoryHotbar;
import game.items.Items;
import game.main.Main;
import game.main.states.Game;

public class Camera {
	//private Vector3f position = new Vector3f(Constants.CAM_X, Constants.CAM_Y, Constants.CAM_Z);
	private Vector3f position = new Vector3f(1, 5, 1);
	
	private float distanceFromPlayer = 0;
//	private float angleAroundPlayer = 0;
	
	private float pitch = 0;
	private float yaw = 0;
	private float roll = 0;
	private long windowID;
	
	public static double scrollValue = 0;
	public static double scroll = 0;
	
	private double scrollValueX = 0;
	private int clickValue = -1;
	private float lastValueY = 0;
	private float lastValueX = 0;
	private double mouseDx = 0;
	private double mouseDy = 0;
	
	private boolean inWire = false;
	private boolean inDebug = false;
	private boolean beingPressed = false;
	
	private float currentSpeed = 0;
	private float currentJump = 0;
	private Window window;
	
	private boolean isInAir = false;
	private float airTime = 0;
	
	private Player player;
	
	public Vector3f previousMove;
	
	private boolean colliding = false;
	
	private GLFWScrollCallback scrollCallback;
	private MouseButtonCallback mouseButtonCallback;
	private GLFWCursorPosCallback cursorPositionCallback = new CursorPositionCallback();
	private GLFWScrollCallback mouseScrollCallback;
	private KeyCallback keyCallback;
	
	public void glfwScrollCallback(long windowID, double dx, double dy) {
		scrollValue = dy;
		scrollValueX = dx;
	}
	
	public void glfwMouseButtonCallback(long windowID, int button, int action, int mods) {
		if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && action == GLFW.GLFW_PRESS) {
			clickValue = 0;
		} else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && action == GLFW.GLFW_PRESS) {
			clickValue = 1;
		} else if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW.GLFW_PRESS) {
			clickValue = 2;
		} else {
			clickValue = -1;
		}
	}
	
	public void glfwCursorPos(long windowID, double dx, double dy) {
		mouseDx = dx;
		mouseDy = dy;
	}
	
	public Camera(long windowID, Player player) {
		this.windowID = windowID;
		this.player = player;
		this.keyCallback = new KeyCallback();
		this.mouseButtonCallback = new MouseButtonCallback();
		GLFW.glfwSetScrollCallback(windowID, scrollCallback = GLFWScrollCallback.create(this::glfwScrollCallback));
		GLFW.glfwSetMouseButtonCallback(windowID, GLFWMouseButtonCallback.create(mouseButtonCallback));
		GLFW.glfwSetCursorPosCallback(windowID, cursorPositionCallback = GLFWCursorPosCallback.create(this::glfwCursorPos));
		GLFW.glfwSetScrollCallback(windowID, mouseScrollCallback = GLFWScrollCallback.create(this::glfwScrollCallback));
		GLFW.glfwSetKeyCallback(windowID, keyCallback);
	}
	
	public Camera(long windowID) {
		this.windowID = windowID;
		
		GLFW.glfwSetScrollCallback(windowID, GLFWScrollCallback.create(this::glfwScrollCallback));
		GLFW.glfwSetMouseButtonCallback(windowID, GLFWMouseButtonCallback.create(this::glfwMouseButtonCallback));
		GLFW.glfwSetKeyCallback(windowID, keyCallback = new KeyCallback());
		GLFW.glfwSetCursorPosCallback(windowID, cursorPositionCallback = new CursorPositionCallback());
	}
	
	private void calculateCameraPosition(float horizontalDistance, float verticalDistance) {
		
	}

	public void move() {
		calculatePitch();
		calculateAngleAroundPlayer();
		float horizontalDistance = calculateHorizontalDistance();
		float verticalDistance = calculateVerticalDistance();
		calculateCameraPosition(horizontalDistance, verticalDistance);
		if(Mouse.isMouseLocked()) {
			checkInputs();
			float distance = (float) Math.sin(currentSpeed) * (float) (TimeManager.deltaTime * 100);
			float dx = -(float)(distance * Math.sin(Math.toRadians(-yaw)));
			float dz = -(float)(distance * Math.cos(Math.toRadians(-yaw)));
			float dy = (float)(currentJump * Window.getDelta());
			increasePosition(dx, currentJump, dz);
			previousMove = new Vector3f(dx,currentJump,dz).subtract(getPosition());
		} else if (colliding) {
		}
		
		
	}
	
	public Vector3f getPosition() {
		return position;
	}

	public float getPitch() {
		return pitch;
	}

	public float getYaw() {
		return yaw;
	}

	public float getRoll() {
		return roll;
	}
	
	private float calculateHorizontalDistance() {
		return (float) (distanceFromPlayer * Math.cos(Math.toRadians(pitch)));
	}
	
	private float calculateVerticalDistance() {
		return (float) (distanceFromPlayer * Math.sin(Math.toRadians(pitch)));
	}
	
	public void setPosition(Vector3f position) {
		this.position = position;
	}

	private void calculateZoom() {
		
		float zoomLevel =  (float)(scrollValue); // * 0.1f
		distanceFromPlayer -= zoomLevel;
		scrollValue = 0;
	}
	
	private void calculatePitch() {
		float pitchChange = 0;
		if(Mouse.isMouseLocked()) {
			pitchChange = (float) mouseDy - lastValueY;
		}
		pitch += pitchChange / 10;
		
		if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_F3) == 1 && !inDebug) {
			DebugMenu.show();
			inDebug = true;
			beingPressed = true;
		} else if (GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_F3) == 1 && inDebug) {
			DebugMenu.hide();
			beingPressed = true;
			inDebug = false;
		}
		
    	if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_P) == 1 && !inWire) {
			OpenGL.setPolygonWire();
			
			beingPressed = true;
		} else if (GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_P) == 1 && inWire) {
			GL11.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			beingPressed = true;
		}
		lastValueY = (float) mouseDy;
	}
	
	private void calculateAngleAroundPlayer() {
		float angleChange = 0;
		if(Mouse.isMouseLocked()) {
			angleChange = (float) mouseDx - lastValueX;
		}
		yaw += angleChange / 10;
		
		lastValueX = (float) mouseDx;
	}
	
	private void jump(float jump) {
		this.currentJump = jump;
	}

	private void checkInputs() {
		
		if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_W) == 1 || GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_UP) == 1) {
			this.currentSpeed = Constants.PLAYER_SPEED;
		} else if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_S) == 1 || GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_DOWN) == 1) {
			this.currentSpeed = -Constants.PLAYER_SPEED;
		} else {
			this.currentSpeed = 0;
		}
		
		if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_SPACE) == 1) {
			jump(0.1f);
			isInAir = true;
		} else if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_LEFT_SHIFT) == 1) {
			jump(-0.1f);
		} else {
			jump(0);
		}
		
		/*
		if(GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_Q) == 1) {
			this.currentJump = Constants.PLAYER_SPEED;
		} else if (GLFW.glfwGetKey(windowID, GLFW.GLFW_KEY_E) == 1) {
			this.currentJump = -Constants.PLAYER_SPEED;
		} else {
			this.currentJump = 0;
		}*/

	}
	
	public Vector3f getLookVec() {
		Vector3f vector = new Vector3f(10,1,10);
		vector.x = (float) 10;
		vector.y = (float) -pitch/4;
		vector.z = (float) 10;
		return vector;
	}
	
	public void increasePosition(float dx, float dy, float dz) {
		this.position.x += dx;
		this.position.y += dy;
		this.position.z += dz;
	}
	
	public float getScale() {
		return 3f;
	}
 	
	public boolean CheckCollision(Entity entity, Camera player) {
		  	if ( 
		        ( player.getPosition().x <= entity.getScale() + entity.getPosition().x && player.getScale() + player.getPosition().x >= entity.getPosition().x ) &&
		        ( player.getPosition().y-Constants.CAM_HEIGHT <= entity.getScale() + entity.getPosition().y && player.getScale() + player.getPosition().y-Constants.CAM_HEIGHT >= entity.getPosition().y ) &&
		       ( player.getPosition().z <= entity.getScale() + entity.getPosition().z && player.getScale() + player.getPosition().z >= entity.getPosition().z ) 
		  			) 
		  	{
		  		return true;
		  	} 
		  	return false;
	}
	
	public boolean CheckCollision(Entity entity, Vector3f player, int playerScale) {
	  	if ( 
	        ( player.x <= entity.getScale() + entity.getPosition().x && playerScale + player.x >= entity.getPosition().x ) &&
	        ( player.y-Constants.CAM_HEIGHT <= entity.getScale() + entity.getPosition().y && playerScale + player.y-Constants.CAM_HEIGHT >= entity.getPosition().y ) &&
	       ( player.z <= entity.getScale() + entity.getPosition().z && playerScale + player.z >= entity.getPosition().z ) 
	  			) 
	  	{
	  		return true;
	  	} 
	  	return false;
}

	public float getScrollValue() {
		float value = (float) scrollValue;
		scrollValue = 0.0f;
		InventoryHotbar.scroll = (int) value;
		scroll = value;
        return value;
	}

	public KeyCallback getKeyCallback() {
		return Callbacks.getKeyCallback();
	}

	public MouseButtonCallback getMouseButtonCallback() {
		return Callbacks.getMouseButtonCallback();
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}
	
	
	
}
