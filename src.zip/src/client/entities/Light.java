package client.entities;

import client.math.Vector3f;
import client.shadows.ShadowMap;

public class Light {
	
	private Vector3f pos;
	private Vector3f color;
	private Vector3f attenuation;
	
	private ShadowMap lightShadowMap;
	
	public Light(Vector3f pos, Vector3f color) {
		super();
		this.pos = pos;
		this.color = color;
		
		this.lightShadowMap = new ShadowMap();
	}
	
	public Light(Vector3f pos, Vector3f color, Vector3f attenuation) {
		super();
		this.pos = pos;
		this.color = color;
		this.attenuation = attenuation;
	}
	
	public Vector3f getPos() {
		return pos;
	}

	public void setPos(Vector3f pos) {
		this.pos = pos;
	}

	public Vector3f getColor() {
		return color;
	}

	public void setColor(Vector3f color) {
		this.color = color;
	}

	public Vector3f getAttenuation() {
		return attenuation;
	}

	public void setAttenuation(Vector3f attenuation) {
		this.attenuation = attenuation;
	}

	public ShadowMap getLightShadowMap() {
		return lightShadowMap;
	}
	
}
