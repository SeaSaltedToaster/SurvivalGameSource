package game.items.armor;

import client.render.model.TexturedModel;
import client.texture.Texture;
import game.items.Item;

public class ItemArmor extends Item {

	public ItemArmor(int stackSize, Texture tex, int id, String name) {
		super(stackSize, tex, id, name);
	}
	
	public ItemArmor(int stackSize, Texture tex, int id, String name, TexturedModel model) {
		super(stackSize, tex, id, name, model);
	}

	@Override
	public void onRightClick() {
		//Equip armor item on right click
	}

	@Override
	public void onLeftClick() {
		//Default punch
	}

	@Override
	public void update() {
		//Unused
	}

	@Override
	public void onWield() {
		// TODO Auto-generated method stub
		
	}

}
