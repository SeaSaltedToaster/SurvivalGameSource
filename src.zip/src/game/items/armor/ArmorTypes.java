package game.items.armor;

public enum ArmorTypes {

	helmet, chestplate, pants, boots,
	
}
