package game.items.armor.pants;

import client.texture.Texture;
import game.guis.ItemTextures;
import game.items.armor.ItemArmor;
import game.main.Main;

public class ItemVikingPants extends ItemArmor {

	public ItemVikingPants() {
		super(1, ItemTextures.VIKING_PANTS, 4, "Viking Pants");
	}

}
