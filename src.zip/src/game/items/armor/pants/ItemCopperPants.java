package game.items.armor.pants;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.items.Item;
import game.items.armor.ItemArmor;

public class ItemCopperPants extends ItemArmor {

	public ItemCopperPants() {
		super(1, new Texture(Textures.copper_pants_icon), 50, "Copper Pants", EntityResources.COPPER_PANTS);
	}

	@Override
	public void onRightClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onLeftClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onWield() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

}
