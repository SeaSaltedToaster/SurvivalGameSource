package game.items.utility;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.items.Item;

public class ItemNull extends Item {

	public ItemNull() {
		super(999, new Texture(Textures.black), -1, "");
	}

	@Override
	public void onRightClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onLeftClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onWield() {
		// TODO Auto-generated method stub

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

}
