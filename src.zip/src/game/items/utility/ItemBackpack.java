package game.items.utility;

import org.lwjgl.glfw.GLFW;

import client.render.Window;
import client.texture.Texture;
import client.util.input.Input;
import client.util.input.Mouse;
import game.guis.ItemTextures;
import game.items.Item;
import game.main.Main;
import game.main.states.Game;

public class ItemBackpack extends Item {

	public boolean isOpen = false;
	
	public ItemBackpack() {
		super(1, ItemTextures.BACKPACK, 20, "Backpack");
//		BackpackUI.init();
	}

	@Override
	public void onRightClick() {
		openBackpack();
	}

	@Override
	public void onLeftClick() {
		
	}

	@Override
	public void update() {
//		if(Game.getInventory().isOpen() && isOpen || Input.isKeyPressed(GLFW.GLFW_KEY_ESCAPE) && isOpen) {
//			closeBackpack();
//		}
//		
//		if(isOpen) { BackpackUI.Update(); }
	}
	
	public void openBackpack() {
		openGUIs();
	}
	
	public void openGUIs() {
//		BackpackUI.Show();
		setOpen(true);
		
		Mouse.setMouseVisible(true);
	}

	public void closeBackpack() {
		closeGUIs();
	}
	
	public void closeGUIs() {
//		BackpackUI.Remove();
		setOpen(false);
		
//		if(!Game.getInventory().isOpen()) {Mouse.setMouseVisible(false);};
	}

	public boolean isOpen() {
		return isOpen;
	}

	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
	}

	@Override
	public void onWield() {
		// TODO Auto-generated method stub
		
	}
	
}
