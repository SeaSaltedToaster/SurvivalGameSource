package game.items;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import client.util.input.Input;
import game.inventory.InventoryHotbar;
import game.items.armor.pants.ItemCopperPants;
import game.items.armor.pants.ItemVikingPants;
import game.items.decorations.ItemCandle;
import game.items.food.ItemBerries;
import game.items.food.ItemCarrot;
import game.items.food.ItemPork;
import game.items.misc.ItemLog;
import game.items.misc.ItemStone;
import game.items.swords.ItemVikingSword;
import game.items.tools.ItemArrow;
import game.items.tools.ItemIronPickaxe;
import game.items.tools.ItemStonePickaxe;
import game.items.treasure.ItemCopperBar;
import game.items.treasure.ItemEmerald;
import game.items.utility.ItemBackpack;
import game.items.utility.ItemNull;
import game.loader.ItemLoader;
import game.main.states.Game;

public class Items {

	//File items (Items initialized in an outside folder) 
	public static Item HORNED_HELMET = ItemLoader.loadItem("Horned Helmet", 1);
	public static Item VIKING_CHESTPLATE = ItemLoader.loadItem("Viking Chestplate", 1);
	public static Item VIKING_BOOTS = ItemLoader.loadItem("Viking Boots", 1);
	public static Item STONE_SHOVEL = ItemLoader.loadItem("Stone Shovel", 1);
	public static Item STONE_AXE = ItemLoader.loadItem("Stone Axe", 1);
	public static Item STONE_SWORD = ItemLoader.loadItem("Stone Sword", 1);
	public static Item STONE_SCYTHE = ItemLoader.loadItem("Stone Scythe", 1);
	public static Item COPPER_BAR = new ItemCopperBar();
	public static Item BERRIES = new ItemBerries();
	public static Item BOW = ItemLoader.loadItem("Bow", 1);
	public static Item ARROW = new ItemArrow();
	public static Item NULL = ItemLoader.loadItem("null", 99);
	public static Item FLAMING_ARROW = ItemLoader.loadItem("Flaming Arrow", 99);
	public static Item ICE_ARROW = ItemLoader.loadItem("Ice Arrow", 99);
	public static Item DIRT = ItemLoader.loadItem("Dirt", 99);
	public static Item HOE = ItemLoader.loadItem("Hoe", 1);
	public static Item CARROT = new ItemCarrot();
	public static Item CORN = ItemLoader.loadItem("Corn", 99);
	public static Item DYNAMITE = ItemLoader.loadItem("Dynamite", 99);
	public static Item IRON_ORE = ItemLoader.loadItem("Iron Ore", 99);
	
	//Customs Items (Items the have their own java class for more complex features)
	public static Item VIKING_SWORD = new ItemVikingSword();
	public static Item VIKING_PANTS = new ItemVikingPants();
	public static Item CANDLE = new ItemCandle();
	public static Item BACKPACK = new ItemBackpack();
	public static Item IRON_PICKAXE = new ItemIronPickaxe();
	public static Item STONE_PICKAXE = new ItemStonePickaxe();
	public static Item LOG = new ItemLog();
	public static Item EMERALD = new ItemEmerald();
	public static Item COOKED_PORK = new ItemPork();
	public static Item STONE = new ItemStone();
	
	public static Item COPPER_PANTS = new ItemCopperPants();
	
	public static List<Item> gameItems = new ArrayList<Item>();
	
	public static Item getItemFromString(String name) {
		for(Item item : gameItems) {
			if(item.getName().equalsIgnoreCase(name)) {
				System.out.println("Gave 1 "+name+" to Player");
				return item;
			}
			if(item.getStringId().equalsIgnoreCase(name)) {
				System.out.println("Gave 1 "+item.getName()+" to Player");
				return item;
			}
		}
		System.out.println("Invalid Item");
		return Items.NULL;
	}
	
	public static Item findItemFromString(String name) {
		for(Item item : gameItems) {
			if(item.getName().equalsIgnoreCase(name)) {
				return item;
			}
			if(item.getStringId().equalsIgnoreCase(name)) {
				return item;
			}
		}
		System.out.println("Invalid Item");
		return Items.NULL;
	}
	
	public static void updateItems() {
		for(Item item : gameItems) {
			item.update();
//			if(Input.isKeyPressed(GLFW.GLFW_MOUSE_BUTTON_LEFT) && Game.getInventory().getItems().get(InventoryHotbar.selectedItemIndex).getItem() == item) {
//				item.onLeftClick();
//			} else if(Input.isKeyPressed(GLFW.GLFW_MOUSE_BUTTON_RIGHT) && Game.getInventory().getItems().get(InventoryHotbar.selectedItemIndex).getItem() == item) {
//				item.onRightClick();
//				System.out.println("eee");
//			}
		}
	}
	
	public static void init() {
		gameItems.add(COOKED_PORK);
		gameItems.add(COPPER_PANTS);
		gameItems.add(EMERALD);
		gameItems.add(LOG);
		gameItems.add(STONE);
		gameItems.add(HORNED_HELMET);
		gameItems.add(VIKING_CHESTPLATE);
		gameItems.add(VIKING_PANTS);
		gameItems.add(VIKING_BOOTS);
		gameItems.add(DYNAMITE);
		gameItems.add(STONE_PICKAXE);
		gameItems.add(STONE_SHOVEL);
		gameItems.add(STONE_SWORD);
		gameItems.add(STONE_SCYTHE);
		gameItems.add(STONE_AXE);
		gameItems.add(COPPER_BAR);
		gameItems.add(BERRIES);
		NULL.setCustomName("");
		gameItems.add(IRON_ORE);
		gameItems.add(FLAMING_ARROW);
		gameItems.add(ICE_ARROW);
		gameItems.add(CANDLE);
		gameItems.add(DIRT);
		gameItems.add(HOE);
		gameItems.add(CORN);
		gameItems.add(CARROT);
		gameItems.add(ARROW);
		gameItems.add(BOW);
		gameItems.add(VIKING_SWORD);
		gameItems.add(IRON_PICKAXE);
		gameItems.add(BACKPACK);
	}
	
}
