package game.items.rng;

import java.util.List;

import game.items.ItemStack;

public class ItemPool {

	public List<ItemStack> pool;
	public List<Integer> rarity;
	
	public ItemPool(ItemStack... items) {
		for(ItemStack item : items) {
			pool.add(item);
		}
		setDefaultChances();
	}
	
	public void setDefaultChances() {
		int size = pool.size();
		for(int i = 0; i < size; i++) {
			rarity.add(100/size);
		}
	}
	
	public void setChances(int... chances) {
		for(Integer chance : chances) {
			rarity.add(chance);
		}
	}

	public List<ItemStack> getPool() {
		return pool;
	}

	public void setPool(List<ItemStack> pool) {
		this.pool = pool;
	}

	public List<Integer> getRarity() {
		return rarity;
	}

	public void setRarity(List<Integer> rarity) {
		this.rarity = rarity;
	}
	
}
