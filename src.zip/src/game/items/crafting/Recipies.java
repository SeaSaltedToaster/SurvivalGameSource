package game.items.crafting;

import java.util.ArrayList;
import java.util.List;

import game.items.Items;

public class Recipies {
	
	public static List<CraftingRecipie> recipies = new ArrayList<CraftingRecipie>();
	
	public static CraftingRecipie LOG = new CraftingRecipie(Items.LOG, 2, Items.LOG, 8);
	public static CraftingRecipie BERRIES = new CraftingRecipie(Items.COPPER_BAR, 1, Items.BERRIES, 10);
	public static CraftingRecipie ARROW = new CraftingRecipie(Items.LOG, 8, Items.ARROW, 2);
	public static CraftingRecipie WOODEN_PICKAXE = new CraftingRecipie(Items.LOG, 24, Items.STONE_PICKAXE, 1);
	public static CraftingRecipie COPPPER_PANTS = new CraftingRecipie(Items.COPPER_BAR, 20, Items.COPPER_PANTS, 1);
	
	public static void init() {
		recipies.add(LOG);
		recipies.add(BERRIES);
		recipies.add(ARROW);
		recipies.add(WOODEN_PICKAXE);
		recipies.add(COPPPER_PANTS);
	}
	
}
