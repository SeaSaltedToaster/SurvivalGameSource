package game.items.crafting;

import game.items.Item;

public class CraftingRecipie {
	
	private Item required;
	private int amount;
	
	private Item give;
	private int giveAmount;
	
	public CraftingRecipie(Item required, int amount, Item give, int giveAmount) {
		this.required = required;
		this.amount = amount;
		
		this.give = give;
		this.giveAmount = giveAmount;
	}

	public Item getRequired() {
		return required;
	}

	public int getAmount() {
		return amount;
	}

	public Item getGive() {
		return give;
	}

	public int getGiveAmount() {
		return giveAmount;
	}

}
