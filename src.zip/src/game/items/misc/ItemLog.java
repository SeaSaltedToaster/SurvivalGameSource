package game.items.misc;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.building.BuildingManager;
import game.inventory.InventoryHotbar;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemLog extends Item {

	public ItemLog() {
		super(99, new Texture(Textures.logIcon), 35, "Log", EntityResources.LOG);
	}

	@Override
	public void onRightClick() {
		
	}

	@Override
	public void onLeftClick() {
//		Game.getInventory().removeItem(Items.COPPER_BAR);
	}

	@Override
	public void onWield() {
		BuildingManager.setBuilding(true);
	}

	@Override
	public void update() {
//		if(Game.getInventory().getItems().get(InventoryHotbar.selectedItemIndex).getItem() == this) {
//			BuildingManager.setBuilding(true);
//		}
	}
	
}
