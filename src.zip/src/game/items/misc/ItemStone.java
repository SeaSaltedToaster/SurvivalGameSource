package game.items.misc;

import client.Engine;
import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.building.BuildingManager;
import game.inventory.InventoryHotbar;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemStone extends Item {

	public ItemStone() {
		super(99, new Texture(Engine.getLoader().loadTexture("items/Stone/icon")), 7, "Stone", EntityResources.ROCK1);
	}

	@Override
	public void onRightClick() {
		
	}

	@Override
	public void onLeftClick() {
		
	}

	@Override
	public void onWield() {
		
	}

	@Override
	public void update() {
		
	}
	
}
