package game.items.swords;

import java.util.Random;

import client.texture.Texture;
import game.guis.ItemTextures;
import game.items.Item;
import game.items.components.ItemDamage;
import game.items.components.ItemReforge;
import game.items.swords.SwordReforgeType;
import game.main.Main;

public class ItemVikingSword extends Item {
	
	private ItemDamage damage = new ItemDamage(this);
	private ItemReforge reforge = new ItemReforge(this);
	
	public ItemVikingSword() {
		super(1, ItemTextures.VIKING_SWORD, 1, "Viking Sword");
		
		this.components.add(damage);
		this.components.add(reforge);
		this.damage.setDamage(damage.getDamage() + (reforge.getReforge().getDamageModifier() * damage.getDamage()));
		
		this.getLoreTags().add("+"+damage.getDamage() +" Damage");
	}

	@Override
	public void update() {
		ItemReforge.generate();
	}

	@Override
	public void onRightClick() {
		System.out.println("Blocked with the Sword");
	}

	@Override
	public void onLeftClick() {
		System.out.println("Swung the Sword, dealing "+damage.getDamage()+" damage");
	}

	@Override
	public void onWield() {
		
	}

}
