package game.items.swords;

public enum SwordReforgeType {
	
	Regular(0), 
	Magical(0.15), 
	Mystic(0.3), 
	Sharp(0.6), 
	Deadly(0.65), 
	Zealous(0.1), 
	Weak(-0.2), 
	Damaged(-0.1), 
	Superior(0.75),
	Rare(0.25),
	Insane(0.9), 
	Strong(0.7), 
	Godly(1);
	
	private double damageModifier;
	
    private SwordReforgeType(double damageModifier) {
		this.damageModifier = damageModifier;
	}

	public double getDamageModifier() {
		return damageModifier;
	}

	public void setDamageModifier(double damageModifier) {
		this.damageModifier = damageModifier;
	}

}
