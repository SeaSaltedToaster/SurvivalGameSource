package game.items.treasure;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.items.Item;

public class ItemEmerald extends Item {

	public ItemEmerald() {
		super(99, new Texture(Textures.emerald_icon), 47, "Emerald", EntityResources.EMERALD);
	}

	@Override
	public void onRightClick() {
		
	}

	@Override
	public void onLeftClick() {
		
	}

	@Override
	public void onWield() {
		
	}

	@Override
	public void update() {
		
	}
	
}
