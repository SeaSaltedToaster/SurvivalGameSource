package game.items.tools;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemArrow extends Item {
	
	public ItemArrow() {
		super(999, new Texture(Textures.arrow_icon), 23, "Arrow", EntityResources.PIG);
	}

	@Override
	public void onRightClick() {
		
	}

	@Override
	public void onLeftClick() {
		//Punch
	}

	@Override
	public void onWield() {
		
	}

	@Override
	public void update() {
		//Update eating cycle
	}

}
