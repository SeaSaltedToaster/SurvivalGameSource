package game.items.tools;

import client.Engine;
import client.init.Textures;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import game.guis.ItemTextures;
import game.inventory.InventoryHotbar;
import game.items.Item;
import game.items.components.ItemDurability;
import game.main.Main;
import game.main.states.Game;

public class ItemIronPickaxe extends Item {

	ItemDurability durability; //= new ItemDurability(this,150);
	
	public ItemIronPickaxe() {
		super(1, ItemTextures.IRON_PICKAXE, 27, "Iron Pickaxe", new TexturedModel(OBJLoader.loadObjModel("items/Iron Pickaxe/model", Engine.getLoader()),new ModelTexture(Textures.pickaxe)));
	}

	@Override
	public void onRightClick() {
		//Regenerate Durability (Debug)
//		durability.add();
	}

	@Override
	public void onLeftClick() {
//		durability.takeDamage();
	}

	@Override
	public void update() {
//		durability.update();
//		if(Game.getInventory().getItems().get(InventoryHotbar.selectedItemIndex).getItem() != this) {
//			durability.getBar().hide();
//		}
	}

	@Override
	public void onWield() {
		
	}

	public ItemDurability getDurability() {
		return durability;
	}

}
