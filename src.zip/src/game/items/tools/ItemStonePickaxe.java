package game.items.tools;

import client.Engine;
import client.init.EntityResources;
import client.init.Textures;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import game.guis.ItemTextures;
import game.items.Item;
import game.items.components.ItemDurability;
import game.main.Main;
import game.main.states.Game;

public class ItemStonePickaxe extends Item {
	
	ItemDurability durability; //= new ItemDurability(this,75);
	
	public ItemStonePickaxe() {
		super(1, ItemTextures.STONE_PICKAXE, 27, "Stone Pickaxe", EntityResources.STONE_PICKAXE);
	}

	@Override
	public void onRightClick() {
		//Regenerate Durability (Debug)
//		durability.add();
	}

	@Override
	public void onLeftClick() {
//		durability.takeDamage();
	}

	@Override
	public void update() {
//		durability.update();
	}

	@Override
	public void onWield() {
		
	}

}
