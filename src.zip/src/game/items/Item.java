package game.items;

import java.util.ArrayList;
import java.util.List;

import client.init.EntityResources;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.texture.Texture;
import game.items.components.ItemComponent;
import game.items.components.ItemDamage;

public abstract class Item {

	private int stackSize;
	private Texture icon;
	private String name;
	private int id;
	
	private ItemStack stack;
	
	private TexturedModel model;
	
	private List<String> loreTags = new ArrayList<String>();
	private String customName;
		
	protected List<ItemComponent> components = new ArrayList<ItemComponent>();
	
	public Item(int stackSize, Texture tex, int id, String name) {
		this.stackSize = stackSize;
		this.icon = tex;
		this.name = name;
		this.id = id;
		this.customName = name;
	}
	
	public Item(int stackSize, Texture tex, int id, String name, TexturedModel model) {
		this.stackSize = stackSize;
		this.icon = tex;
		this.name = name;
		this.id = id;
		this.customName = name;
		this.model = model;
	}
	
	public abstract void onRightClick();
	public abstract void onLeftClick();
	public abstract void onWield();
	
	public abstract void update();

	public String getCustomName() {
		return customName;
	}

	public void setCustomName(String customName) {
		this.customName = customName;
	}

	public int getStackSize() {
		return stackSize;
	}

	public Texture getIcon() {
		return icon;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}
	
	public String getStringId() {
		return ""+id;
	}

	public void setStackSize(int stackSize) {
		this.stackSize = stackSize;
	}

	public void setIcon(Texture icon) {
		this.icon = icon;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<String> getLoreTags() {
		return loreTags;
	}

	public TexturedModel getModel() {
		if(model == null) {
			return EntityResources.model;
		}
		return model;
	}

	public ItemStack getStack() {
		return stack;
	}

	public void setStack(ItemStack stack) {
		this.stack = stack;
	}
	
}
