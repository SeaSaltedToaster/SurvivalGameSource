package game.items.food;

import game.guis.ItemTextures;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemCarrot extends Item {

	public ItemCarrot() {
		super(99, ItemTextures.CARROT, 23, "Carrot");
	}

	@Override
	public void onRightClick() {
		Game.player.getFbar().add(10); //Eat Food
//		Game.getInventory().removeItem(Items.CARROT);
	}

	@Override
	public void onLeftClick() {
		//Punch
	}

	@Override
	public void onWield() {
		System.out.println("Holding Carrot!");
	}

	@Override
	public void update() {
		//Update eating cycle
	}

}
