package game.items.food;

import client.init.EntityResources;
import client.init.Textures;
import client.render.model.TexturedModel;
import client.texture.Texture;
import game.guis.ItemTextures;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemBerries extends Item {
	
	public ItemBerries() {
		super(99, new Texture(Textures.berries_icon), 54, "Berries", EntityResources.BERRIES);
	}

	@Override
	public void onRightClick() {
		Game.player.getFbar().add(5);
		Game.player.getHbar().add(5);
//		Game.getInventory().removeItem(Items.BERRIES);
	}

	@Override
	public void onLeftClick() {
		//Punch
	}

	@Override
	public void onWield() {
		System.out.println("cronch time");
	}

	@Override
	public void update() {
		//Update eating cycle
	}

}
