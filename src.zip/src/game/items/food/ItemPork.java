package game.items.food;

import client.init.EntityResources;
import client.init.Textures;
import client.texture.Texture;
import game.items.Item;
import game.items.Items;
import game.main.states.Game;

public class ItemPork extends Item {

	public ItemPork() {
		super(99, new Texture(Textures.copper_bar), 53, "Cooked Pork");
	}

	@Override
	public void onRightClick() {
		Game.player.getFbar().add(25);
//		Game.getInventory().removeItem(Items.BERRIES);
	}

	@Override
	public void onLeftClick() {
		//Punch
	}

	@Override
	public void onWield() {
		
	}

	@Override
	public void update() {
		//Update eating cycle
	}
	
}
