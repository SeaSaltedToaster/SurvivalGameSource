package game.items.components;

import java.util.Random;

import game.items.Item;
import game.items.swords.SwordReforgeType;

public class ItemReforge extends ItemComponent {

	protected static SwordReforgeType reforge;
	
	public ItemReforge(Item item) {
		super(item);
		reforge = randomMaterial();
		item.setCustomName(createName());
	}
	
	public static SwordReforgeType randomMaterial() {
	    int pick = new Random().nextInt(SwordReforgeType.values().length);
	    return SwordReforgeType.values()[pick];
	}
	
	public static void generate() {
	    int pick = new Random().nextInt(SwordReforgeType.values().length);
	    reforge = SwordReforgeType.values()[pick];
	}
	
	private String createName() {
		String name = reforge.name() +" "+item.getName();
		return name;
	}

	public SwordReforgeType getReforge() {
		return reforge;
	}

	@Override
	public ItemComponents getType() {
		return ItemComponents.Reforge;
	}

}
