package game.items.components;

public enum ItemComponents {

	Damage, Durability, Reforge,
	
}
