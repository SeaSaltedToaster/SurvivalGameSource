package game.items.components;

import game.items.Item;

public abstract class ItemComponent {

	protected Item item;
	
	public ItemComponent(Item item) {
		this.item = item;
	}
	
	public abstract ItemComponents getType();
	
}