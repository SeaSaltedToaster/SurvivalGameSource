package game.items.components;

import client.init.Textures;
import game.guis.bars.GuiBar;
import game.items.Item;
import game.main.states.Game;

public class ItemDurability extends ItemComponent{
	
	public int maxDurability;
	public int currentDurability;
	
	public boolean isBroken;
	
	private GuiBar bar;

	public ItemDurability(Item item, int maxDurability) {
		super(item);
		this.maxDurability = maxDurability;
		this.currentDurability = maxDurability;
		
		this.bar = new GuiBar(maxDurability, maxDurability, -0.2125f,-0.5f,0.3125f,0.1f, Textures.durability);
	}
	
	public ItemDurability(Item item, int maxDurability, int currentDurability) {
		super(item);
		this.maxDurability = maxDurability;
		this.currentDurability = currentDurability;
		
		this.bar = new GuiBar(maxDurability, maxDurability, -0.2125f,-0.5f,0.3125f,0.1f, Textures.durability);
	}
	
	public void update() {
		if(!Game.getTextures().contains(this.bar.getBackgroundUi())) {
			Game.getTextures().add(this.bar.backgroundUi);
		}
		if(!Game.getTextures().contains(this.bar.getFillUi())) {
			Game.getTextures().add(this.bar.fillUi);
		}
	}
	
	public void takeDamage() {
		this.currentDurability -= 1;
		if(currentDurability <= 0) {
			isBroken = true;
		}
		bar.subtract();
	}
	
	public void add() {
		this.currentDurability += 1;
		if(currentDurability >= maxDurability) {
			currentDurability = maxDurability;
			return;
		}
		bar.add();
	}
	
	public void add(float x) {
		this.currentDurability += x;
		if(currentDurability >= maxDurability) {
			currentDurability = maxDurability;
			return;
		}
		bar.add(x);
	}

	public int getMaxDurability() {
		return maxDurability;
	}

	public void setMaxDurability(int maxDurability) {
		this.maxDurability = maxDurability;
	}

	public int getCurrentDurability() {
		return currentDurability;
	}

	public void setCurrentDurability(int currentDurability) {
		this.currentDurability = currentDurability;
	}

	@Override
	public ItemComponents getType() {
		return ItemComponents.Durability;
	}

	public GuiBar getBar() {
		return bar;
	}

}
