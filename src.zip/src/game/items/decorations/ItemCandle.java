package game.items.decorations;

import client.Engine;
import client.init.Textures;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import client.texture.Texture;
import game.guis.ItemTextures;
import game.items.Item;
import game.items.components.ItemDamage;
import game.main.Main;

public class ItemCandle extends Item {

	public ItemCandle() {
		super(99, ItemTextures.CANDLE, 6, "Candle", new TexturedModel(OBJLoader.loadObjModel("items/Candle/model", Engine.getLoader()), new ModelTexture(Textures.candle)));
	}

	@Override
	public void onRightClick() {
		
	}

	@Override
	public void onLeftClick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onWield() {
		// TODO Auto-generated method stub
		
	}

}
