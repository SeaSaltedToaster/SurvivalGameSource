package game.entities.id;

import client.entities.Entity;

public class EntityID {

	public EntityID(int id, Entity entity) {
		
	}
	
}
