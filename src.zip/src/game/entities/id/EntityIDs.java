package game.entities.id;

public class EntityIDs {

	public static int TREE = 1;
	public static int GRASS = 2;
	public static int CHEST = 3;
	public static int PIG = 4;
	
}
