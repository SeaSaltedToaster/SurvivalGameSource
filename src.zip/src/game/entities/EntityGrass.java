package game.entities;

import client.entities.Entity;
import client.init.EntityResources;
import client.math.Vector3f;
import game.entities.components.DestructableComponent;
import game.entities.components.RenderDistanceComponent;
import game.entities.components.SwayComponent;
import game.items.Items;
import game.worldOld.biomes.trees.FoliageGenerator;

public class EntityGrass extends Entity {

	private DestructableComponent destructible;
	
	public EntityGrass(Vector3f position) {
		super(EntityResources.GRASS1, position, 0, FoliageGenerator.random.nextInt(), 0, 2);
		
		this.destructible = new DestructableComponent(this, 1, Items.NULL);
		
		this.addComponent(new SwayComponent());
		this.addComponent(new RenderDistanceComponent(75));
	}
	
	@Override
	public void update() {
		this.destructible.update();
	}

}
