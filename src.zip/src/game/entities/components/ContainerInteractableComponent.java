package game.entities.components;

import client.engine.Keybinds;
import client.entities.Entity;
import client.util.input.Input;

public class ContainerInteractableComponent extends InteractableComponent {

	public ContainerInteractableComponent(Entity entity) {
		super(entity);
	}
	
	@Override
	public void onInteract() {
		if(entity.hasComponent(ComponentType.Container) && Input.isKeyPressed(Keybinds.Interact)) { //Temporary for testing
			ContainerComponent comp = (ContainerComponent) entity.getComponent(ComponentType.Container);
			comp.open();
		}
	}

}
