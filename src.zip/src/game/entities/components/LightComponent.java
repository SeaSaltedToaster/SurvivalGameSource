package game.entities.components;

import client.entities.Light;
import client.math.Vector3f;

public class LightComponent extends Component{

	Light light = new Light(new Vector3f(0, 25, 10), new Vector3f(1, 1, 0));
	
	public LightComponent(float x, float y, float z) {
		light.setPos(new Vector3f(x,y,z));
	}
	
	@Override
	public void update() {
		
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Light;
	}

}
