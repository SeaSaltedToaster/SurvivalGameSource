package game.entities.components;

public enum ComponentType {
	
	NULL, Light, Container, Pickup, Interactable, Animation, Sway, Material, Audio, RenderDistance

}
