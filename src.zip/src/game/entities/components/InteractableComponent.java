package game.entities.components;

import client.Engine;
import client.entities.Entity;
import client.math.Vector3f;
import game.main.states.Game;

public class InteractableComponent extends Component {
	
	protected Entity entity;
	
	public InteractableComponent(Entity entity) {
		this.entity = entity;
	}
	
	@Override
	public void update() {
		for(int i = 0; i < 10; i++) {
			Vector3f position = Game.getPicker().getCurrentIntRay(Engine.getCamera().getPosition(), i);
			if(Engine.getCamera().CheckCollision(entity, position, (int) Engine.getCamera().getScale()))
				onInteract();
		}
	}
	
	public void onInteract() {
		//Any action
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Interactable;
	}

}
