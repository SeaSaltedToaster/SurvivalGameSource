package game.entities.components;

public class AudioComponent extends Component {

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public ComponentType getType() {
		return ComponentType.Audio;
	}

}
