package game.entities.components;

import client.entities.Entity;
import client.init.Textures;
import client.render.model.TexturedModel;
import client.render.obj.matRender.OBJMaterialModel;
import client.texture.ModelTexture;
import client.texture.Texture;

public class MaterialComponent extends Component {
	
	public OBJMaterialModel model;
	private Entity attach;
	
	public MaterialComponent(OBJMaterialModel model, Entity attach) {
		this.model = model;
		this.attach = attach;
		this.attach.setTm(new TexturedModel(model.getModel(), new ModelTexture(Textures.arrow_icon)));
	}
	
	public OBJMaterialModel getModel() {
		return model;
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Material;
	}

	@Override
	public void update() {
		//Nothing to do here
	}

}
