package game.entities.components;

public class SwayComponent extends Component {

	private int entitySwayID;
	
	public SwayComponent() {
		this.entitySwayID = 1;
	}
	
	@Override
	public void update() {
		
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Sway;
	}

	public int getEntitySwayID() {
		return entitySwayID;
	}

	public void setEntitySwayID(int entitySwayID) {
		this.entitySwayID = entitySwayID;
	}

}
