package game.entities.components;

import client.animation.Animation;
import client.animation.model.AnimatedModel;
import client.entities.Entity;

public class AnimationComponent extends Component {

	protected Entity entity;
	private Animation animation;
	private AnimatedModel model;
	
	public AnimationComponent(Entity entity, Animation animation, AnimatedModel model) {
		this.entity = entity;
		this.animation = animation;
		this.model = model;
		
//		model.doAnimation(animation);
	}

	@Override
	public void update() {
		
	}

	public Entity getEntity() {
		return entity;
	}

	public Animation getAnimation() {
		return animation;
	}

	public AnimatedModel getModel() {
		return model;
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Animation;
	}

}
