package game.entities.components;

import java.util.Random;

import client.Engine;
import client.audio.AudioSource;
import client.entities.Entity;
import client.entities.Player;
import client.init.Sounds;
import client.math.Vector3f;
import game.entities.EntityItem;
import game.entities.SpawnPosition;
import game.inventory.InventoryHotbar;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;
import game.main.states.Game;

public class DestructableComponent extends InteractableComponent {

	private int health;
	private Random random;
	private Item drop;
	
	private AudioSource source;
	private Item breakingItem;
	
	public DestructableComponent(Entity entity, int health, Item drop) {
		super(entity);
		
		this.health = health;
		this.drop = drop;
		
		this.random = new Random();
		this.source = new AudioSource();
	}
	
	public DestructableComponent(Entity entity, int health, Item drop, Item breakingItem) {
		super(entity);
		
		this.health = health;
		this.drop = drop;
		this.breakingItem = breakingItem;
		
		this.random = new Random();
		this.source = new AudioSource();
	}
	
	@Override
	public void onInteract() {
		if(Engine.getCamera().getMouseButtonCallback().isLeftButtonDown()){
			if(breakingItem != null && Player.getPlayer().getContained().get(InventoryHotbar.selectedItemIndex).getItem() != breakingItem)
				return;
			
			breakObject();
			dropItems();
		}
	}
	
	private void breakObject() {
		this.health -= 10;
		if(health <= 0)
			Game.getEntitiesToRemove().add(entity);
		source.Play(Sounds.click);
	}
	
	private void dropItems() {
		Vector3f position = new Vector3f(random.nextInt(5),1f,random.nextInt(5)).add(entity.getPosition());
		EntityItem item = new EntityItem(new SpawnPosition(position.x,position.y,position.z), new ItemStack(drop,5));
		
		if(drop != Items.NULL)
			Game.getEntitiesToAdd().add(item);
	}
 
}
