package game.entities.components;

public abstract class Component {

	public abstract void update();
	
	public abstract ComponentType getType();
	
}
