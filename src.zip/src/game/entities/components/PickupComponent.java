package game.entities.components;

import client.entities.Entity;
import client.entities.Player;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;
import game.main.states.Game;

public class PickupComponent extends Component {

	public ItemStack stack;
	public Entity base;
	
	public PickupComponent(Item item, Entity base) {
		stack = new ItemStack(item,1);
		this.base = base;
	}
	
	public void pickup() {
		if(stack.getItem() != Items.NULL) {
			Player.player.addItem(stack);
			Game.getEntitiesToRemove().add(base);
		}
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Pickup;
	}

	@Override
	public void update() {
		
	}

}
