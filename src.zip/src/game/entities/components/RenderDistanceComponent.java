package game.entities.components;

public class RenderDistanceComponent extends Component {

	private float distance;
	
	public RenderDistanceComponent(float distance) {
		this.distance = distance;
	}

	@Override
	public ComponentType getType() {
		return ComponentType.RenderDistance;
	}

	public float getDistance() {
		return distance;
	}

	public void setDistance(float distance) {
		this.distance = distance;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
	}

}
