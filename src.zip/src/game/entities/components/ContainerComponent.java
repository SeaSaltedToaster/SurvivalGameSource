package game.entities.components;

import client.entities.Player;
import game.inventory.container.Container;

public class ContainerComponent extends Component {

	protected Container container;
	
	public ContainerComponent(int rows, int collumns, float slotSize, float x, float y, String title) {
		this.container = new Container(rows, collumns, slotSize, x ,y, title,false);
	}
	
	public ContainerComponent(int rows, int collumns, float slotSize, float x, float y, String title, boolean centered) {
		this.container = new Container(rows, collumns, slotSize, x ,y, title,centered);
	}

	public Container getContainer() {
		return container;
	}

	@Override
	public void update() {
		
	}
	
	public void open() {
		Player.player.open();
		container.open();
	}

	@Override
	public ComponentType getType() {
		return ComponentType.Container;
	}
	
}
