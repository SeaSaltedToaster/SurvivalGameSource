package game.entities.animals;

import client.entities.Entity;
import client.init.EntityResources;
import client.math.MathUtils;
import client.math.Vector3f;
import game.ai.RandomMoveAI;
import game.entities.SpawnPosition;
import game.entities.components.DestructableComponent;
import game.items.Items;

public class EntityPig extends Entity {

	private DestructableComponent destructible;
	protected RandomMoveAI entityAi;
	
	public EntityPig(SpawnPosition position) {
		super(EntityResources.PIG, new Vector3f(position.getX(),position.getY(), position.getZ()), 0, 0, 0, 2);
		
		this.destructible = new DestructableComponent(this, 10, Items.COOKED_PORK);
		
		this.entityAi = new RandomMoveAI(this);
		this.entityAi.start();
	}
	
	@Override
	public void update() {
		if(!entityAi.reachedTarget()) {
			entityAi.moveToTarget();
			setRy(MathUtils.calculateVectorRotationY(entityAi.getNextPos().toVector2f()));
    	} else {
    		Vector3f target = entityAi.getNextMovePosition(getPosition(), 5);
    		entityAi.setNextPos(target);
        	setRy(MathUtils.calculateVectorRotationY(target.toVector2f()));
    	}

		this.destructible.update();
	}

}
