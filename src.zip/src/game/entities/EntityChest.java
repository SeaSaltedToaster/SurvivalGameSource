package game.entities;

import client.entities.Entity;
import client.init.EntityResources;
import client.math.Vector3f;
import game.entities.components.ContainerComponent;
import game.entities.components.ContainerInteractableComponent;

public class EntityChest extends Entity {

	private ContainerInteractableComponent interact;
	private ContainerComponent container;
	
	public EntityChest(Vector3f position) {
		super(EntityResources.model, position, 0, 0, 0, 2);
		
		this.interact = new ContainerInteractableComponent(this);
		this.container = new ContainerComponent(1,5,0.08f,-0.75f,-0.1f,"Game",false);
		
		this.addComponent(interact);
		this.addComponent(container);
	}
	
	@Override
	public void update() {
		this.interact.update();
	}
}
