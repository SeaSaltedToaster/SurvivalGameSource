package game.entities;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.entities.Entity;
import client.math.Vector3f;
import game.entities.components.InteractableComponent;
import game.entities.components.PickupComponent;
import game.items.ItemStack;
import game.items.Items;

public class EntityItem extends Entity {

	private PickupComponent pickup;
	private InteractableComponent interact;
	
	public EntityItem(SpawnPosition position, ItemStack stack) {
		super(stack.getItem().getModel(), new Vector3f(position.getX(),position.getY(), position.getZ()),0,0,0, 0.25f);
		
		this.pickup = new PickupComponent(stack.getItem(), this);
		this.interact = new InteractableComponent(this);
		
		this.addComponent(pickup);
		this.addComponent(interact);
		
	}
	
	@Override
	public void update() {
		if(Engine.getCamera().CheckCollision(this, Engine.getCamera()) && pickup.stack.getItem() != Items.NULL)
			this.pickup.pickup();
		
		this.interact.update();
		
		this.getPosition().y = (float) Math.max((Math.sin(GLFW.glfwGetTime()))/2+1,0); //Add terrain height
		this.increaseRotation(0, 0.05f, 0);
	}

}
