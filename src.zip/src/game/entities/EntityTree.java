package game.entities;

import client.entities.Entity;
import client.init.EntityResources;
import client.math.Vector3f;
import game.entities.components.DestructableComponent;
import game.entities.components.RenderDistanceComponent;
import game.entities.components.SwayComponent;
import game.items.Items;
import game.worldOld.biomes.trees.FoliageGenerator;

public class EntityTree extends Entity {
	
	private DestructableComponent destructible;
	
	public EntityTree(Vector3f position) {
		super(EntityResources.TREE1, position, 0, FoliageGenerator.random.nextInt(360), 0, 2);
		
		this.destructible = new DestructableComponent(this, 25, Items.LOG);
		
		this.addComponent(new SwayComponent());
		this.addComponent(new RenderDistanceComponent(250));
		
		if(position == null)
			this.setPosition(new Vector3f(0,0,0));
	}
	
	@Override
	public void update() {
		this.destructible.update();
	}
	
}
