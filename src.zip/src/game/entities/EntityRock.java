package game.entities;

import client.entities.Entity;
import client.init.EntityResources;
import client.math.Vector3f;
import game.entities.components.DestructableComponent;
import game.items.Items;
import game.worldOld.biomes.trees.FoliageGenerator;

public class EntityRock extends Entity {

private DestructableComponent destructible;
	
	public EntityRock(Vector3f position) {
		super(EntityResources.ROCK1, position, 0, FoliageGenerator.random.nextInt(360), 0, 2);
		
		this.destructible = new DestructableComponent(this, 100, Items.STONE, Items.STONE_PICKAXE);
		
		if(position == null)
			this.setPosition(new Vector3f(0,0,0));
	}
	
	@Override
	public void update() {
		this.destructible.update();
	}
	
}
