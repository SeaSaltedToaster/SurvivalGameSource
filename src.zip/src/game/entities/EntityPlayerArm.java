package game.entities;

import client.entities.Entity;
import client.math.Vector3f;
import client.render.model.TexturedModel;

public class EntityPlayerArm extends Entity {

	public EntityPlayerArm(TexturedModel tm, Vector3f position, float rx, float ry, float rz, float scale) {
		super(tm, position, rx, ry, rz, scale);
	}

}
