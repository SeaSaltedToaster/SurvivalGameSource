package game.entities;

import client.init.EntityResources;
import client.math.Vector3f;

public class EntitySnowGrass extends EntityGrass {

	public EntitySnowGrass(Vector3f position) {
		super(position);
		this.setTm(EntityResources.GRASS2);
	}

}
