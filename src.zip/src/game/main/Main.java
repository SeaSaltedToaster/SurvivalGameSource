package game.main;

import java.util.List;
import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.engine.Logger;
import client.entities.Camera;
import client.entities.Entity;
import client.guis.GUIManager;
import client.guis.core.render.UiRenderer;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.render.Window;
import client.util.ScreenshotUtils;
import client.util.input.Input;
import game.guis.DebugMenu;
import game.main.menu.MainMenu;
import game.main.state.GameState;
import game.mods.ToastarioMod;

public class Main {	
	
	public static List<ToastarioMod> mods;
	
	public static GameState game;
	
	public static boolean shouldQuit = false;
	
	public static void main(String[] args) {
		
		Engine.start();
		
		game = new MainMenu();
		game.init();
		
		Logger.log("Starting Menu...", Main.class);
		
		//Main Game Loop
		while(!Window.shouldClose()) {
			
			if(shouldQuit)
				break;
			
			Engine.getCamera().move();
			
			for(ToastarioMod mod : mods)
				mod.update();
			
			game.update();
			
			if(Input.isKeyPressed(GLFW.GLFW_KEY_F2)) 
				ScreenshotUtils.screenshot();
			
			GUIManager.update();
			
			Engine.guiRenderer.render(Engine.getTextures());
			
			TextMaster.render();
			
			getWindow().update();		
		}
		Logger.log("Closing Game...", Main.class);
		getWindow().cleanUp();
		game.close();
		Engine.shutdown();
		Logger.log("Closed Game", Main.class);
	}
	
	public static void loadNewGameState(GameState state) {
		game.close();
		state.init();
		game = state;
	}

	public static Window getWindow() {
		return Engine.window;
	}

	public static UiRenderer getGuiRenderer() {
		return Engine.guiRenderer;
	}

	public static GUIText getFpsCounter() {
		return DebugMenu.fps;
	}

	public static List<ToastarioMod> getMods() {
		return mods;
	}

	public static Camera getCamera() {
		return Engine.camera;
	}

	public static List<Entity> getEntities() {
		return Engine.getEntities();
	}
	
}
