package game.main.states;

import java.util.ArrayList;
import java.util.List;
import client.Engine;
import client.audio.AudioSource;
import client.audio.management.AudioMaster;
import client.collision.CollisionWorld;
import client.engine.Logger;
import client.entities.Camera;
import client.entities.Entity;
import client.entities.Light;
import client.entities.Player;
import client.guis.core.UiBlock;
import client.guis.core.render.UiRenderer;
import client.init.EntityResources;
import client.math.Vector3f;
import client.util.MousePicker;
import client.util.ProjectionMatrixUtils;
import client.util.input.Mouse;
import game.building.BuildingManager;
import game.entities.components.AnimationComponent;
import game.entities.components.MaterialComponent;
import game.gamemodes.Gamemode;
import game.guis.notifications.NotificationGuiBuilder;
import game.inventory.InventoryHotbar;
import game.inventory.container.ContainerManager;
import game.items.Items;
import game.main.Main;
import game.main.state.GameState;
import game.save.SaveManager;
import game.structures.dungeon.DungeonBaseGenerator;
import game.worldOld.chunk.ChunkLoader;
import game.worldOld.chunk.thread.ChunkThread;
import game.worldOld.test.render.ChunkRenderer;
import net.Network;

public class Game extends GameState {

	private static ChunkLoader cl;
	
	private static Camera cam;
	private static Light light;
	
	private static List<Entity> entitiesToRemove;
	private static List<Entity> entitiesToAdd;
	
	private static UiRenderer guiRenderer;
	
	private static MousePicker picker;
	
	public static List<Entity> chunks;
	
	public static ChunkThread cthread;
	
	public static Player player;
	
	static ChunkRenderer renderer;
	
	static AudioSource source;
	
	public static InventoryHotbar hotbar;
	
	public static Entity mat = new Entity(null, new Vector3f(0,0,0), 0,0,0,1);
	
	public static CollisionWorld collision = new CollisionWorld();
	
	@Override
	public void init() {
		Logger.log("Initializing Game...", this.getClass());
		Mouse.setMouseVisible(false);
		entitiesToAdd = new ArrayList<Entity>();
		entitiesToRemove = new ArrayList<Entity>();
		chunks = new ArrayList<Entity>();
		light = new Light(new Vector3f(20, 150, 20), new Vector3f(1, 1, 1));
		guiRenderer = new UiRenderer(Engine.getLoader());
		player = new Player(null, new Vector3f(0,0, 0), 0, 0, 0, 1);
		cam = Main.getCamera();
		cam.setPlayer(player);
		Logger.log("Loading Terrain...", this.getClass());
		cthread = new ChunkThread();
		cl = new ChunkLoader(cam.getPosition());
		renderer = new ChunkRenderer();
		picker = new MousePicker(cam, ProjectionMatrixUtils.getProjectionMatrix());
		
		Logger.log("Building Structures...", this.getClass());
		DungeonBaseGenerator.gen(-50, -50);
		
		Logger.log("Starting Game...", this.getClass());
		
		source = new AudioSource();
		hotbar = new InventoryHotbar();
		
		mat.addComponent(new MaterialComponent(EntityResources.materialModel, mat));
		getEntities().add(mat);
		
		Entity entity = new Entity(null, new Vector3f(0,0,0),0,0,0,1);
		entity.addComponent(new AnimationComponent(entity, null, EntityResources.data));
		getEntities().add(entity);
		
	}
	
	@Override
	public void update() {
		cl.updateChunks(cam.getPosition());
		
		light.setPos(cam.getPosition());
		
		collision.updateTest();
		BuildingManager.update();
		player.update();
		
		ContainerManager.updateAll();
		hotbar.update();
		NotificationGuiBuilder.updateCurrent();
		picker.update();
		
		Items.updateItems();
		
		for(Entity block : Engine.getEntities()) {
			Engine.getRenderer().processEntity(block);
			block.update();
		}
		
		Engine.getEntities().addAll(entitiesToAdd);
		entitiesToAdd.clear();
		Engine.getEntities().removeAll(entitiesToRemove);
		entitiesToRemove.clear();
		
		Engine.getRenderer().render(light, cam);
		
		for(Entity block : chunks) {
//			block.setPosition(cam.getPosition());
			renderer.renderEntities(block, light);
		}
	}
	
	public static void updatePlayerData() {
		Network.name = SaveManager.worldName;
		Network.x = cam.getPosition().x;
		Network.y = cam.getPosition().y;
		Network.z = cam.getPosition().z;
		
	}

	@Override
	public void close() {
		cleanUp();
		Logger.log("Saving Game...", this.getClass());
		SaveManager.init();
		SaveManager.saveInventory();
		SaveManager.saveWorldData();
		SaveManager.end();
		
	}
	
	@Override
	public void cleanUp() {
		Engine.shutdown();
		guiRenderer.cleanUp();
		source.delete();
		AudioMaster.cleanUp();
		cthread.kill();
	}

	public static List<Entity> getEntities() {
		return Engine.getEntities();
	}

	public static List<Entity> getEntitiesToRemove() {
		return entitiesToRemove;
	}

	public static UiRenderer getGuiRenderer() {
		return guiRenderer;
	}

	public static ChunkLoader getCl() {
		return cl;
	}

	public static List<UiBlock> getTextures() {
		return Engine.getTextures();
	}
	
	public Gamemode getMode() {
		return Gamemode.Creative;
	}
	
	public static MousePicker getPicker() {
		return picker;
	}
	
	public static List<Entity> getEntitiesToAdd() {
		return entitiesToAdd;
	}

	static {
//		time += GLFW.glfwGetTime() / dayLength;
//		sunIntensity = (float) ((float) (Math.sin(Math.toRadians(time/timeDelay))+1.0)/2.0);
//		light.setColor(new Vector3f(sunIntensity, sunIntensity, sunIntensity));
//		EngineVariables.setSkyColor(new Vector3f(sunIntensity+0.25f, sunIntensity+0.25f, sunIntensity+0.25f));
	}

}
