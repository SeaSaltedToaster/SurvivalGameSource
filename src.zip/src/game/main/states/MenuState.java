package game.main.states;

public enum MenuState {

	MAIN, SELECTOR, MULTIPLAYER, CREATE
	
}
