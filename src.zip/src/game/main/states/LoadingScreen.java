package game.main.states;

import java.util.ArrayList;
import java.util.List;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.core.render.UiRenderer;
import client.guis.resources.UiResources;
import game.main.Main;
import game.main.state.GameState;

public class LoadingScreen extends GameState {

	private static UiRenderer guiRenderer;
	private static List<UiBlock> tex;
	
	private int i = 0;
	
	@Override
	public void init() {
		guiRenderer = new UiRenderer(Engine.getLoader());
		tex = new ArrayList<UiBlock>();
		tex.add(UiResources.MENU);
	}

	@Override
	public void update() {
		guiRenderer.render(tex);
		if(i > 10) {
			Main.loadNewGameState(new Game());
		}
		i++;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cleanUp() {
		// TODO Auto-generated method stub

	}

}
