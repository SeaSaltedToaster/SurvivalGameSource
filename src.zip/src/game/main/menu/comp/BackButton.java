package game.main.menu.comp;

import client.Engine;
import client.guis.button.UiButton;
import client.math.Vector2f;
import client.render.Loader;
import game.main.menu.MainMenu;

public class BackButton extends UiButton {

	public BackButton(Vector2f position) {
		super(Engine.getLoader(), "back", position, new Vector2f(0.06f, 0.08f));
	}
	
	@Override
	public void onClick() {
		MainMenu.openMainPage();
	}

}
