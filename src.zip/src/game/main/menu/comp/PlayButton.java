package game.main.menu.comp;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.math.Vector2f;
import game.guis.buttons.TextButton;
import game.main.Main;
import game.main.menu.MainMenu;
import game.main.states.Game;
import game.resources.UIs;

public class PlayButton extends TextButton {

	public UiBlock arrow = new UiBlock(UIs.mainUnselected, new Vector2f(0,0), new Vector2f(0.1f,0.15f));
	
	public PlayButton(Vector2f position) {
		super("Play", "inventory", position, new Vector2f(0.25f, 0.075f));
		
		this.getText().setColour(0.2f, 0.2f, 0.2f);
		this.setTextSize(1.5f);
		this.getText().remove();
		this.getText().setFont(Fonts.ARIAL);
		this.getText().reset();
	}
	
	@Override
	public void show() {
		
	}
	
	@Override
	public void startHover() {
		arrow.setTexture(UIs.mainSelected);
	}
	
	@Override
	public void stopHover() {
		arrow.setTexture(UIs.mainUnselected);
	}
	
	@Override
	public void onClick() {
		MainMenu.openWorldSelector();
	}

}
