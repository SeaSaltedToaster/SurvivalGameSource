package game.main.menu.comp;

import client.guis.text.Fonts;
import client.math.Vector2f;
import game.guis.buttons.TextButton;
import game.main.Main;
import game.main.menu.MainMenu;
import game.main.states.Game;

public class QuitButton extends TextButton {

	public QuitButton(Vector2f position) {
		super("Quit", "inventory", position, new Vector2f(0.25f, 0.075f));
		
		this.getText().setColour(0.2f, 0.2f, 0.2f);
		this.setTextSize(1.5f);
		this.getText().remove();
		this.getText().setFont(Fonts.ARIAL);
		this.getText().reset();
	}
	
	@Override
	public void onClick() {
		Main.shouldQuit = true;
	}
	
}
