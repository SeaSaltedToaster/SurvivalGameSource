package game.main.menu.comp;

import client.math.Vector2f;
import game.guis.buttons.TextButton;
import game.main.menu.MainMenu;

public class SettingsButton extends TextButton {

	public SettingsButton(Vector2f position) {
		super("Settings", "inventory", position, new Vector2f(0.25f, 0.075f));
		
		this.getText().setColour(0.2f, 0.2f, 0.2f);
		this.setTextSize(1.5f);
		this.getText().reset();
	}
	
	@Override
	public void onClick() {
		MainMenu.openSettings();
	}
	
}
