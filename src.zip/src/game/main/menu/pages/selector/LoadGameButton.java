package game.main.menu.pages.selector;

import client.math.Vector2f;
import game.guis.buttons.TextButton;
import game.main.Main;
import game.main.states.Game;

public class LoadGameButton extends TextButton {

	public LoadGameButton(Vector2f position) {
		super("Load", "selector", position, new Vector2f(0.075f, 0.06f));
	}
	
	@Override
	public void onClick() {
		if(WorldSelectorPage.selected > -1) {
			Main.loadNewGameState(new Game());
		}
	}
	
}
