package game.main.menu.pages.selector;

import java.util.concurrent.TimeUnit;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Loader;
import game.main.Main;
import game.main.states.Game;
import game.save.SaveFile;
import game.save.loading.SaveLoader;

public class SaveFileButton extends UiButton {

	public SaveFile file;
	
	public GUIText name;
	public GUIText size;
	public GUIText modded;
	
	public float meta;
	
	public SaveFileButton(Vector2f position, SaveFile file, int meta) {
		super(Engine.getLoader(), "inventory", position, new Vector2f(0.25f, 0.085f));
		this.file = file;
		this.name = new GUIText("Name: "+file.getName(), 1f, Fonts.ARIAL, position, 1f, false);
		this.size = new GUIText("Last Played: "+file.getLastPlayed(), 1f, Fonts.ARIAL, position, 1f, false);
		this.meta = meta;
		this.getGuiTexture().setAlpha(0.85f);
	}
	
	@Override
	public void onClick() {
		SaveLoader.loadGame(file);
		WorldSelectorPage.selected = meta;
		getGuiTexture().setTexture(Textures.selector);
	}
	
	@Override
	public void updateSelf() {
		if(WorldSelectorPage.selected != meta) 
			getGuiTexture().setTexture(Textures.Inventory);
	}
	
	@Override
	public void setPosition(Vector2f position) {
		getGuiTexture().setPosition(position);
		name.setPosition(position.subtract(new Vector2f(-0.755f,0.91f)));
		size.setPosition(position.subtract(new Vector2f(-0.755f,0.955f)));
    }

}
