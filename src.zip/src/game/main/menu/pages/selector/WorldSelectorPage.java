package game.main.menu.pages.selector;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import client.Engine;
import client.engine.Logger;
import client.entities.Camera;
import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.transitions.SlideDriver;
import client.guis.transitions.Transition;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Window;
import game.main.menu.pages.MainMenuPage;
import game.save.SaveFile;
import game.save.SaveManager;
import game.save.loading.SaveLoader;

public class WorldSelectorPage extends MainMenuPage {

	public static List<SaveFileButton> buttons = new ArrayList<SaveFileButton>();
	public static List<SlideDriver> drivers = new ArrayList<SlideDriver>();
	
	public static UiBlock topPanel = new UiBlock(Textures.Inventory, new Vector2f(0,0.925f), new Vector2f(0.5f,0.075f));
	public static UiBlock bottomPanel = new UiBlock(Textures.Inventory, new Vector2f(0,-0.925f), new Vector2f(0.5f,0.075f));
	
	public static SlideDriver driver = new SlideDriver(1.1f, 0.925f, 100);
	public static SlideDriver driver2 = new SlideDriver(-1.1f, -0.925f, 100);
	
	public static Transition appear = new Transition().slideDriver(1.1f, 0.925f, 100);
	
	public static LoadGameButton loadGame = new LoadGameButton(new Vector2f(-10,0));
	
	public static float addition = 0;
	public static float selected = -1;
	public static boolean isClosing = false;
	
	@Override
	public void init() {
		int meta = 0;
		for(File file : SaveManager.getAllSaves()) {
			buttons.add(getButtonFromFile(file, meta));
			buttons.get(meta).show(Engine.getTextures());
			drivers.add(getDriver(meta));
			meta++;
		}
		Engine.getTextures().add(topPanel);
		Engine.getTextures().add(bottomPanel);
		Engine.getTextures().add(loadGame.getGuiTexture());
		
		topPanel.setAlpha(0.95f);
		bottomPanel.setAlpha(0.95f);
	}

	@Override
	public void update() {
		if(isClosing) {
			for(SaveFileButton button : buttons) {
				int meta = buttons.indexOf(button);
				button.getGuiTexture().setPosition(new Vector2f(0,drivers.get(meta).reverse(Window.getDelta()) + addition));
				button.setPosition(new Vector2f(0,drivers.get(meta).reverse(Window.getDelta()) + addition));
			}
			topPanel.setPosition(new Vector2f(0,driver.reverse(Window.getDelta())));
			bottomPanel.setPosition(new Vector2f(0,driver2.reverse(Window.getDelta())));
			loadGame.setPosition(new Vector2f(0,driver2.reverse(Window.getDelta())));
		} else {
			if(Engine.getCamera().getScrollValue() > 0) 
				addition-= 0.05f;
			if(Engine.getCamera().getScrollValue() < 0) 
				addition+= 0.05f;
			
			for(SaveFileButton button : buttons) {
				int meta = buttons.indexOf(button);
				button.getGuiTexture().setPosition(new Vector2f(0,drivers.get(meta).update(Window.getDelta()) + addition));
				button.setPosition(new Vector2f(0,drivers.get(meta).update(Window.getDelta()) + addition));
				button.checkHover();
			}
			topPanel.setPosition(new Vector2f(0,driver.update(Window.getDelta())));
			bottomPanel.setPosition(new Vector2f(0,driver2.update(Window.getDelta())));
			loadGame.setPosition(new Vector2f(0,driver2.update(Window.getDelta())));
			loadGame.checkHover();
		}
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		isClosing = true;
	}

	@Override
	public String getName() {
		return "World Selector";
	}
	
	private SlideDriver getDriver(int meta) {
		SlideDriver driver = new SlideDriver(-1 - (meta*2), 0.7f - (0.25f * meta), 200);
		return driver;
	}
	
	private SaveFileButton getButtonFromFile(File file, int meta) {
		SaveFile save = SaveLoader.loadLocation(file.toString());
		SaveFileButton saveButton = new SaveFileButton(new Vector2f(0,0.7f - (0.25f * meta)), save, meta);
		return saveButton;
	}

}
