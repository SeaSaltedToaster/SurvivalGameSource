package game.main.menu.pages.settings;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.constants.Settings;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.transitions.SlideDriver;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Window;
import client.util.input.Input;
import game.guis.SliderUi;
import game.main.menu.comp.BackButton;
import game.main.menu.pages.MainMenuPage;

public class SettingsMenu extends MainMenuPage {
	
	private BackButton back = new BackButton(new Vector2f(-1.9f, -0.9f));
	
	private SliderUi slider = new SliderUi(16, new Vector2f(-0.25f,0));
	private GUIText renderDistance = new GUIText("BANA", 1f, Fonts.ARIAL, new Vector2f(0,0), 1f, true);
	
	private SlideDriver appear = new SlideDriver(-1.9f, -0.65f, 100);
	private SlideDriver disappear = new SlideDriver(-0.65f, -1.9f, 100);
	private boolean isClosing = false;
	
	@Override
	public void show() {
		back.getGuiTexture().show();
		slider.show();
		renderDistance.show();
		renderDistance.setColour(0.2f, 0.2f, 0.2f);
	}

	@Override
	public void init() {
		
	}

	@Override
	public void hide() {
		isClosing = true;
	}

	@Override
	public String getName() {
		return "Settings";
	}

	@Override
	public void update() {
		
		if(!isClosing) {
			float x = appear.update(Window.getDelta());
			back.setPosition(new Vector2f(x, -0.9f));
			slider.setPosition(new Vector2f(x+0.4f, 0));
			renderDistance.setPosition(new Vector2f(x, -0.975f));
			renderDistance.setTextString("Render Distance : "+ (int) slider.getCount());
			Settings.CHUNK_DISTANCE = (int) slider.getCount();
			back.checkHover();
		} else {
			float x = disappear.update(Window.getDelta());
			back.setPosition(new Vector2f(x, -0.9f));
			slider.setPosition(new Vector2f(x+0.4f, 0));
			renderDistance.setPosition(new Vector2f(x, -0.975f));
		}
	}

}
