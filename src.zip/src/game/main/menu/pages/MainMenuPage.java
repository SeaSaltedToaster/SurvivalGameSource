package game.main.menu.pages;

public abstract class MainMenuPage {

	public abstract void init();
	public abstract void update();
	public abstract void show();
	public abstract void hide();

	public abstract String getName();
}
