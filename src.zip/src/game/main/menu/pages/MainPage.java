package game.main.menu.pages;

import client.Engine;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.transitions.SlideDriver;
import client.math.Vector2f;
import client.render.Window;
import game.main.menu.comp.PlayButton;
import game.main.menu.comp.QuitButton;
import game.main.menu.comp.SettingsButton;

public class MainPage extends MainMenuPage {

	private static PlayButton play;
	private static SettingsButton settings;
	private static QuitButton quit;
	
	private static GUIText text;
	
	private boolean isClosing = false;
	
	public SlideDriver slide = new SlideDriver(-0.7f, -5f, 100);
	public SlideDriver show = new SlideDriver(-2f, -0.7f, 100);
	
	public void init() {
		play = new PlayButton(new Vector2f(-0.7f, 0.2f));
		settings = new SettingsButton(new Vector2f(-0.7f, -0.1f));
		quit = new QuitButton(new Vector2f(-0.7f, -0.4f));
		text = new GUIText("Game", 3f, Fonts.ARIAL, new Vector2f(-0.7f, 0.7f-1f), 1f, true);
		
		play.getGuiTexture().setAlpha(0.8f);
		settings.getGuiTexture().setAlpha(0.8f);
		quit.getGuiTexture().setAlpha(0.8f);
	}
	
	public void show() {
		play.show(Engine.getTextures());
		settings.show(Engine.getTextures());
		quit.show(Engine.getTextures());
	}
	
	public void hide() {
		isClosing = true;
	}

	public String getName() {
		return "Main";
	}

	@Override
	public void update() {
		if(!isClosing) {
			play.checkHover();
			settings.checkHover();
			quit.checkHover();
			
			float time = show.update(Window.getDelta());
			play.getGuiTexture().setPosition(new Vector2f(time, 0.2f));
			settings.getGuiTexture().setPosition(new Vector2f(time, -0.1f));
			quit.getGuiTexture().setPosition(new Vector2f(time, -0.4f));
			text.setPosition(new Vector2f(time, 0.7f-1));
		} else {
			float time = slide.update(Window.getDelta());
			play.getGuiTexture().setPosition(new Vector2f(time, 0.2f));
			settings.getGuiTexture().setPosition(new Vector2f(time, -0.1f));
			quit.getGuiTexture().setPosition(new Vector2f(time, -0.4f));
			text.setPosition(new Vector2f(time, 0.7f-1));
		}
	}
	
}
