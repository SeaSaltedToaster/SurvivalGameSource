package game.main.menu;

import client.Engine;
import client.audio.AudioSource;
import client.guis.GUIManager;
import client.guis.core.UiBlock;
import client.guis.resources.UiResources;
import client.guis.text.TextMaster;
import client.init.Sounds;
import client.util.input.Mouse;
import game.main.Main;
import game.main.menu.comp.PlayButton;
import game.main.menu.pages.MainMenuPage;
import game.main.menu.pages.MainPage;
import game.main.menu.pages.selector.WorldSelectorPage;
import game.main.menu.pages.settings.SettingsMenu;
import game.main.state.GameState;
import game.main.states.Game;

public class MainMenu extends GameState {
	
	private static MainMenuPage currentPage;
	private static MainMenuPage lastPage;
	
	private static UiBlock block = UiResources.MENU;
	
	static AudioSource source;
	
	@Override
	public void init() {
		source = new AudioSource();
//		source.Play(Sounds.LPD);
		
		initUis();
		Mouse.setMouseVisible(true);
	}
	
	private void initUis() {
		Engine.getTextures().add(block);
		currentPage = new MainPage();
		currentPage.init();
		currentPage.show();
	}
	
	public static void openWorldSelector() {
		currentPage.hide();
		lastPage = currentPage;
		currentPage = new WorldSelectorPage();
		currentPage.init();
		currentPage.show();
	}
	
	public static void openMainPage() {
		currentPage.hide();
		lastPage = currentPage;
		currentPage = new MainPage();
		currentPage.init();
		currentPage.show();
	}
	
	public static void openSettings() {
		currentPage.hide();
		lastPage = currentPage;
		currentPage = new SettingsMenu();
		currentPage.init();
		currentPage.show();
	}

	@Override
	public void update() {
		Engine.getGuiRenderer().prepare();
		currentPage.update();
		if(lastPage != null) 
			lastPage.update();
	}

	@Override
	public void close() {
		cleanUp();
		TextMaster.clear();
	}

	@Override
	public void cleanUp() {
		Engine.getTextures().clear();
	}

}
