package game.guis;

import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;

public class DebugMenu {
	
	public static GUIText text;
	public static GUIText modt;
	public static GUIText fps;
	
	public static void init() {
		fps = new GUIText("FPS: "+0, 1f, Fonts.ARIAL, new Vector2f(-0.9f, -0.05f), 1f, true, 1);
		modt = new GUIText("Mods loaded: "+0, 1f, Fonts.ARIAL, new Vector2f(-0.9f, -0.1f), 1f, true, 1); //Mod Manager
		text = new GUIText("Survival Game", 1f, Fonts.ARIAL, new Vector2f(-0.875f, 0f), 1f, true, 1);
	}
	
	public static void show() {
		TextMaster.loadText(fps);
		TextMaster.loadText(modt);
		TextMaster.loadText(text);
	}
	
	public static void hide() {
		TextMaster.removeText(fps);
		TextMaster.removeText(modt);
		TextMaster.removeText(text);
	}

}
