package game.guis.bars;

import client.init.Textures;

public class HealthBar extends GuiBar {

	public HealthBar() {
		super(100,0,-0.2f,-0.75f,0.15f,0.025f, Textures.health);
	}

}
