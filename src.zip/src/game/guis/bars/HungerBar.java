package game.guis.bars;

import client.init.Textures;

public class HungerBar extends GuiBar {

	public HungerBar() {
		super(100,0,0.2f,-0.75f,0.15f,0.025f, Textures.hunger);
	}

}
