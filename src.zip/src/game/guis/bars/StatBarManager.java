package game.guis.bars;

public class StatBarManager {

}
