package game.guis.bars;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.core.UiComponent;
import client.init.Textures;
import client.math.Vector2f;
import game.main.states.Game;

public class GuiBar extends UiComponent {
	
	public float maxFill = 100;
	public float currentFill = maxFill;
	
	public UiBlock backgroundUi;
	public UiBlock fillUi;
	
	private UiBlock[] uis = new UiBlock[2];
	
	float ammount;
	
	public GuiBar(int max, int fill, float x, float y, float dx, float dy, int texture) {
		maxFill = max;
		currentFill = maxFill;
		
		backgroundUi = new UiBlock(Textures.black, new Vector2f(x,y), new Vector2f(dx,dy)); backgroundUi.setAlpha(0.9f);
		fillUi = new UiBlock(texture, new Vector2f(x,y), new Vector2f(dx/1.05f,dy/1.1f)); fillUi.setAlpha(0.9f);
		
		Game.getTextures().add(backgroundUi); Game.getTextures().add(fillUi);
		
		ammount = dx / maxFill;
	}
	
	public void subtract() {
		fillUi.setPosition(new Vector2f(fillUi.getPosition().x-ammount,fillUi.getPosition().y));
		fillUi.setScale(new Vector2f(fillUi.getScale().x-ammount,fillUi.getScale().y));
		currentFill -= 1;
	}
	
	public void subtract(float x) {
		fillUi.setPosition(new Vector2f(fillUi.getPosition().x-(ammount*x),fillUi.getPosition().y));
		fillUi.setScale(new Vector2f(fillUi.getScale().x-(ammount*x),fillUi.getScale().y));
		currentFill -= x;
	}
	
	public void add() {
		if((currentFill+1) > maxFill) {
			ammount = maxFill - currentFill - 1;
		}
		fillUi.setPosition(new Vector2f(fillUi.getPosition().x+ammount,fillUi.getPosition().y));
		fillUi.setScale(new Vector2f(fillUi.getScale().x+ammount,fillUi.getScale().y));
		currentFill += 1;
	}
	
	public void add(float x) {
		if((currentFill+x) >= maxFill) {
			x = maxFill - currentFill - 1;
		}
		fillUi.setPosition(new Vector2f(fillUi.getPosition().x+(ammount*x),fillUi.getPosition().y));
		fillUi.setScale(new Vector2f(fillUi.getScale().x+(ammount*x),fillUi.getScale().y));
		currentFill += x;
	}
	
	public void show() {
		Engine.getTextures().add(backgroundUi);
		Engine.getTextures().add(fillUi);
	}
	
	public void hide() {
		Engine.getTextures().remove(backgroundUi);
		Engine.getTextures().remove(fillUi);
	}

	public UiBlock[] getGuis() {
		return uis;
	}

	public UiBlock getBackgroundUi() {
		return backgroundUi;
	}

	public UiBlock getFillUi() {
		return fillUi;
	}

	public float getCurrentFill() {
		return currentFill;
	}

	@Override
	public void updateSelf() {
		
	}
		
}
