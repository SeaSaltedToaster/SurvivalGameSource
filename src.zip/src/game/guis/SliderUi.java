package game.guis;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.core.UiComponent;
import client.init.Textures;
import client.math.Vector2f;
import client.util.input.Mouse;

public class SliderUi extends UiComponent {

	public float max, increment;
	private float toggleRelationToSlider;
	
	public Vector2f normalPos;
	
	public UiBlock slider = new UiBlock(Textures.Inventory, new Vector2f(0,0.5f), new Vector2f(0.2f,0.04f));
	public UiBlock toggle = new UiBlock(Textures.Inventory, new Vector2f(0,0.5f), new Vector2f(0.02f,0.08f));
	
	public SliderUi(float max, Vector2f position) {
		this.slider.setPosition(position);
		this.toggle.setPosition(position);
		
		this.normalPos = position;
		
		this.increment = slider.getScale().x / max;
		this.max = max;
	}
	
	@Override
	public void updateSelf() {
		if(isOverY() && isOverX() && Engine.getCamera().getMouseButtonCallback().isLeftButtonDown())
			toggle.setPosition(new Vector2f((float)Mouse.getMouseCoordsX(), toggle.getPosition().y));
	}
	
	public boolean isOverX() {
		return (Mouse.getMouseCoordsX() < slider.getPosition().x + slider.getScale().x && Mouse.getMouseCoordsX() > slider.getPosition().x-(slider.getScale().x));
	}
	
	public boolean isOverY() {
		return (Mouse.getMouseCoordsY() > slider.getPosition().y - toggle.getScale().y && Mouse.getMouseCoordsY() < slider.getPosition().y + toggle.getScale().y);
	}
	
	public float getToggleRelation() {
		toggleRelationToSlider = toggle.getPosition().x - normalPos.x;
		return toggleRelationToSlider;
	}
	
	public float getCount() {
		return (getToggleRelation() /increment + max) / 2;
	}
	
	public void setPosition(Vector2f position) {
		slider.setPosition(position);
		toggle.setPosition(new Vector2f(position.x+getToggleRelation(), position.y));
	}
	
	public void setSliderCount(int count) {
		toggle.setPosition(new Vector2f(getFrontPosition().add(new Vector2f(getAddition(count)*2,0)).x,slider.getPosition().y));
	}
	
	public float getAddition(int add) {
		return (increment * add);
	}
	
	public Vector2f getFrontPosition() {
		return new Vector2f(slider.getPosition().x-(slider.getScale().x),slider.getPosition().y);
	}
	
	public void show() {
		slider.show();
		toggle.show();
	}
	
	public void hide() {
		slider.hide();
		toggle.hide();
	}
	
}
