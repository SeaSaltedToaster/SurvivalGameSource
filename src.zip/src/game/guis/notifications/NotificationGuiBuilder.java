package game.guis.notifications;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.transitions.SlideDriver;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Window;

public class NotificationGuiBuilder {

	public static SlideDriver appear = new SlideDriver(-1.1f, -0.9f, 100);
	public static UiBlock current;
	public static GUIText title;
	public static GUIText description;
	
	public static void generate(Notification notification) {
		UiBlock block = new UiBlock(Textures.Inventory, new Vector2f(0.85f,-1.1f), new Vector2f(0.15f,0.1f));
		current = block;
		GUIText name = new GUIText(notification.getTitle(), 1f, Fonts.ARIAL, new Vector2f(0.85f, -1.1f), 1f, false);
		title = name;
		GUIText desc = new GUIText(notification.getDescription(), 0.75f, Fonts.ARIAL, new Vector2f(0.85f, -1.1f), 10f, false);
		description = desc;
//		TextMaster.loadText(name);
//		TextMaster.loadText(desc);
		Engine.getTextures().add(block);
	}
	
	public static void updateCurrent() {
		if(current == null)
			return;
		description.setPositionOld(new Vector2f(0.855f*2,(appear.update(Window.getDelta())*2)-0.05f));
		title.setPositionOld(new Vector2f(0.855f*2,appear.update(Window.getDelta())*2));
		current.setPosition(new Vector2f(0.85f,appear.update(Window.getDelta())));
	}
	
}
