package game.guis.notifications;

public class Notifier {

	public static void send(String title, String desc) {
		NotificationGuiBuilder.generate(new Notification(title, desc));
	}
	
}
