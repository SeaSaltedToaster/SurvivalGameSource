package game.guis.notifications;

public class Notification {

	protected final String title;
	protected final String description;
	
	public Notification(String title, String description) {
		this.title = title;
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}
	
}
