package game.guis;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.resources.UiResources;
import client.math.Vector2f;
import client.util.input.Mouse;
import game.main.Main;
import game.main.states.Game;

public class DeathMenu {

//	public static GUIText menuText = new GUIText("You Died", 2.5f, Fonts.ARIAL, new Vector2f(0, 0.25f), 1f, true);
	
	public static UiButton menu = new UiButton(Engine.getLoader(), "gray", new Vector2f(0,0), new Vector2f(0.15f,0.1f)) {
		@Override
		public void onClick() {
			DeathMenu.hide();
			Main.loadNewGameState(new Game());
		}
	};
	
	private static boolean isOpen;
	
	public static void update() {
		if(isOpen)
			menu.checkHover();
	}
	
	public static void show() {
		isOpen = true;
		Mouse.setMouseVisible(true);
		Game.getTextures().add(UiResources.DEATH);
		Game.getTextures().add(menu.getGuiTexture());
	}
	
	public static void hide() {
		isOpen = false;
		Game.getTextures().remove(UiResources.DEATH);
		Game.getTextures().remove(menu.getGuiTexture());
	}
	
}
