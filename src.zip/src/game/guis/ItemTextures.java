package game.guis;

import client.Engine;
import client.texture.Texture;

public class ItemTextures {
	
	public static Texture BACKPACK = new Texture(Engine.getLoader().loadTexture("items/Backpack/icon"));
	public static Texture VIKING_PANTS = new Texture(Engine.getLoader().loadTexture("items/Viking Pants/icon"));
	public static Texture CANDLE = new Texture(Engine.getLoader().loadTexture("items/Candle/icon"));
	public static Texture VIKING_SWORD = new Texture(Engine.getLoader().loadTexture("items/Viking Sword/icon"));
	public static Texture IRON_PICKAXE = new Texture(Engine.getLoader().loadTexture("items/Iron Pickaxe/icon"));
	public static Texture STONE_PICKAXE = new Texture(Engine.getLoader().loadTexture("items/Stone Pickaxe/icon"));
	public static Texture CARROT = new Texture(Engine.getLoader().loadTexture("items/Carrot/icon"));
	
}
