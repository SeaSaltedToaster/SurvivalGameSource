package game.guis.items;

public class BinocularsUI {

}
