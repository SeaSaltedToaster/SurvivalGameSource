package game.guis.buttons;

import java.util.List;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.math.Vector2f;

public class TextButton extends UiButton {

	private GUIText text;
	
	public TextButton(String text, String texture, Vector2f position, Vector2f scale) {
		super(Engine.getLoader(), texture, position, scale);
		
		this.text = new GUIText(text, 1f, Fonts.ARIAL, new Vector2f(position.x, position.y-1f), 1f, true);
	}

	@Override
	public void updateSelf() {
		this.text.setPosition(new Vector2f(getGuiTexture().getPosition().x, getGuiTexture().getPosition().y-1f + (getScale().y/2*this.text.getFontSize())));
	}
	
	@Override
	public void hide(List<UiBlock> guiTextures) {
		guiTextures.remove(this.getGuiTexture());
		this.getText().remove();
	}
	
	public void setTextSize(float size) {
		this.getText().setFontSize(size);
	}

	public GUIText getText() {
		return text;
	}

	public void setText(GUIText text) {
		this.text = text;
	}
	
}
