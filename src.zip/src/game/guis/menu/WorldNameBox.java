package game.guis.menu;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;
import game.main.Main;

public class WorldNameBox extends UiButton {

	private GUIText modeText = new GUIText("New World", 1.5f, Fonts.ARIAL, new Vector2f(-0.15f, 0.23f), 1f, true);
	private String typed = "New World";
	
	public boolean visible = false;
	
	public WorldNameBox(Vector2f position) {
		super(Engine.getLoader(), "gray", position, new Vector2f(0.255555553f,0.075f));
		modeText.setColour(1, 1, 1);
		TextMaster.removeText(modeText);
	}
	
	@Override
	public void whileHover() {
		typed = Main.getCamera().getKeyCallback().getCurrent();
	}
	
	@Override
	public void stopHover() {
		Main.getCamera().getKeyCallback().end();
	}
	
	@Override
	public void startHover() {
		Main.getCamera().getKeyCallback().start();
	}
	
	public void update() {
		if(visible) {
			modeText.setTextString(typed);
		} else {
			modeText.setTextString("");
		}
	}

	public GUIText getModeText() {
		return modeText;
	}
	
}
