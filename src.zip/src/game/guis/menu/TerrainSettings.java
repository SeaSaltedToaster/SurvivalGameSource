package game.guis.menu;

public enum TerrainSettings {

	Default("Default",1),
	Flat("Flat",2),
	Smooth("Smooth",3),
	Floating("Floating",4),
	Island("Island",5);
	
	String name;
	int id;
	
	TerrainSettings(String name, int id) {
		this.id = id; 
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public static TerrainSettings getMode(int id) {
		for(TerrainSettings mode : TerrainSettings.values()) {
			if(mode.getId() == id) {
				return mode;
			}
		}
		return null;
	}
	
}
