package game.guis.menu;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;
import game.gamemodes.Gamemode;

public class TerrainSwitcher extends UiButton {

	public TerrainSettings mode = TerrainSettings.Flat;
	private GUIText modeText = new GUIText("Terrain: Default", 1.5f, Fonts.ARIAL, new Vector2f(0.15f, 0.475f), 1f, true);
	
	public boolean visible = false;
	
	public TerrainSwitcher(Vector2f position) {
		super(Engine.getLoader(), "gray", position, new Vector2f(0.255555553f,0.075f));
		modeText.setColour(1, 1, 1);
		TextMaster.removeText(modeText);
	}
	
	@Override
	public void onClick() {
		if(currentDelay >= clickDelay) {
			if(mode.getId() == Gamemode.values().length) {
				mode = TerrainSettings.getMode(1);
			} else if(mode.getId() < Gamemode.values().length) { 
				mode = TerrainSettings.getMode(mode.getId()+1); 
			}
			currentDelay = 0;
		}
		currentDelay++;
	} int clickDelay = 50; int currentDelay = 0;
	
	public void update() {
		if(visible) {
			modeText.setTextString("World Type: "+mode.getName());
		}
	}

	public GUIText getModeText() {
		return modeText;
	}

	public TerrainSettings getMode() {
		return mode;
	}
	
}
