package game.guis.menu;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;
import game.gamemodes.Gamemode;

public class GamemodeSwitcher extends UiButton { 
	
	private Gamemode mode = Gamemode.Survival;
	private GUIText modeText = new GUIText("", 1.5f, Fonts.ARIAL, new Vector2f(0.15f, 0.23f), 1f, true);
	
	public boolean visible = false;
	
	public GamemodeSwitcher(Vector2f position) {
		super(Engine.getLoader(), "gray", position, new Vector2f(0.255555553f,0.075f));
		modeText.setColour(1, 1, 1);
		TextMaster.removeText(modeText);
	}
	
	@Override
	public void onClick() {
		if(currentDelay >= clickDelay) {
			if(mode.getId() == Gamemode.values().length) {
				mode = Gamemode.getMode(1);
			} else if(mode.getId() < Gamemode.values().length) { 
				mode = Gamemode.getMode(mode.getId()+1); 
			}
			currentDelay = 0;
		}
		currentDelay++;
	} int clickDelay = 50; int currentDelay = 0;
	
	public void update() {
		if(visible) {
			modeText.setTextString("Gamemode: "+mode.getName());
		}
	}

	public GUIText getModeText() {
		return modeText;
	}

	public Gamemode getMode() {
		return mode;
	}
	
}
