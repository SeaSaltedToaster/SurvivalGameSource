package game.guis.menu;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;

public class MultiplayerSwitcher extends UiButton {

	private boolean on = true;
	private GUIText modeText = new GUIText("Multiplayer: Off", 1.5f, Fonts.ARIAL, new Vector2f(-0.15f, 0.475f), 1f, true);
	
	public boolean visible = false;
	
	public MultiplayerSwitcher(Vector2f position) {
		super(Engine.getLoader(), "gray", position, new Vector2f(0.255555553f,0.075f));
		modeText.setColour(1, 1, 1);
		TextMaster.removeText(modeText);
	}
	
	@Override
	public void onClick() {
		if(currentDelay >= clickDelay) {
			if(on) {
				on = false;
			} else if(!on) { 
				on = true;
			}
			currentDelay = 0;
		}
		currentDelay++;
	} int clickDelay = 50; int currentDelay = 0;
	
	public void update() {
		if(visible && on) {
			modeText.setTextString("Multiplayer: On");
		} else if(visible && !on) {
			modeText.setTextString("Multiplayer: Off");
		} 
	}

	public GUIText getModeText() {
		return modeText;
	}

	public boolean isOn() {
		return on;
	}
	
}
