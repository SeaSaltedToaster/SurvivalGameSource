package game.mods;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import client.engine.Logger;
import client.util.DirectoryBuilder;
import game.main.Main;

public class ModLoader {

	public static void loadMod(File jarPath) throws MalformedURLException, ClassNotFoundException {
		JarFile jarFile = null;
		try {
			jarFile = new JarFile(jarPath);
		} catch (IOException e1) {
			Logger.log("Failed to load Mod", ModLoader.class);
			e1.printStackTrace();
		}
		Enumeration<JarEntry> e = jarFile.entries();

		Logger.log("Loading mod: "+jarPath.getAbsoluteFile().getName().replace(".jar", ""), ModLoader.class);
		
		URL[] urls = { new URL("jar:file:" + jarPath+"!/") };
		URLClassLoader cl = URLClassLoader.newInstance(urls);

		while (e.hasMoreElements()) {
		    JarEntry je = e.nextElement();
		    if(je.isDirectory() || !je.getName().endsWith(".class")){
		        continue;
		    }
		    // -6 because of .class
		    String className = je.getName().substring(0,je.getName().length()-6);
		    className = className.replace('/', '.');
		    Class<?> c = cl.loadClass(className);
		    if(c.getSuperclass() == ToastarioMod.class) {
		    	loadModMain(c);
		    }
		}
	}
	
	public static void prepareMods() {
		for(File file : DirectoryBuilder.mods.listFiles()) {
			if(file != null) {
				try {
					loadMod(file);
				} catch (MalformedURLException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private static void loadModMain(Class<?> c) {
		try {
			ToastarioMod mod = (ToastarioMod) c.newInstance();
			mod.init();
			Main.getMods().add(mod);
			Logger.log("Loaded "+mod.getName()+" "+mod.getModVersion(), ModLoader.class);
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
}
