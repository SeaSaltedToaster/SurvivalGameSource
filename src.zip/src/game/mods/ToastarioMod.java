package game.mods;

public abstract class ToastarioMod {
	
	public abstract String getName();
	
	public abstract String getModVersion();
	
	public abstract String getClientVersion();
	
	public abstract void init();
	
	public abstract void update();
	
	public abstract void deInit();
	
}
