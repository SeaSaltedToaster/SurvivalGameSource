package game.mods.API;

import game.items.Item;
import game.items.Items;

public class API {

	public boolean registerItem(Item item) {
		Items.gameItems.add(item);
		return true;
	}
	
}
