package game.loader;

import client.Engine;
import client.entities.Entity;
import client.math.Vector3f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;

public class EntityLoader {

	public static Entity loadEntity(String name) {
		RawModel model = getEntityModel(name);
		ModelTexture texture = getEntityTexture(name);
		
		TexturedModel finished = new TexturedModel(model, texture);
		Entity entity = new Entity(finished,new Vector3f(0,0,0),0,0,0,1);
		
		return entity;
	}
	
	public static RawModel getEntityModel(String name) {
		String fileLoc = "Entities/"+name+"/model";
		RawModel model = OBJLoader.loadObjModel(fileLoc, Engine.getLoader());
		return model;
	}
	
	public static ModelTexture getEntityTexture(String name) {
		String fileLoc = "Entities/"+name+"/texture";
		ModelTexture texture = new ModelTexture(Engine.getLoader().loadTexture(fileLoc));
		return texture;
	}
	
}
