package game.loader;

import client.Engine;
import client.init.EntityResources;
import client.texture.Texture;
import game.items.Item;

public class ItemLoader {

	/*
	 * TEMPORARY FOR UNUSED ITEMS
	 */
	
	public static Item loadItem(String name) {
		Texture texture = getItemIcon(name);
		return new Item(99, texture, 0, name) {

			@Override
			public void update() {
				
			}

			@Override
			public void onRightClick() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onLeftClick() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onWield() {
				// TODO Auto-generated method stub
				
			}
		
		};
	}
	
	public static Item loadItem(String name, int stack) {
		Texture texture = getItemIcon(name);
		Item item = new Item(stack, texture, 0, name, EntityResources.model) {

			@Override
			public void update() {
				
			}

			@Override
			public void onRightClick() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onLeftClick() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onWield() {
				// TODO Auto-generated method stub
				
			}
			
		};
		return item;
	}
	
	public static Texture getItemIcon(String name) {
		Texture tex = new Texture(Engine.getLoader().loadTexture("items/"+name+"/icon"));
		return tex;
	}
	
}
