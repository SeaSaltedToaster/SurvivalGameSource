package game;

import client.Engine;
import client.audio.management.AudioMaster;
import client.engine.Logger;
import client.guis.text.TextMaster;
import client.init.EntityResources;
import client.util.DirectoryBuilder;
import game.building.BuildingManager;
import game.guis.DebugMenu;
import game.inventory.container.ContainerDragManager;
import game.items.Items;
import game.items.crafting.Recipies;
import game.mods.ModLoader;
import game.worldOld.biomes.Biomes;

public class Game {
	
	public static int worldSeed = 0;
	
	public static void createGame() {
		Logger.log("Loading Saved Data..", Game.class);
		DebugMenu.init();
		Logger.log("Loading Audio..", Game.class);
		AudioMaster.init();
		Logger.log("Loading Resources..", Game.class);
		EntityResources.load();
		TextMaster.init(Engine.getLoader());
		Logger.log("Loading Items..", Game.class);
		Items.init();
		DirectoryBuilder.buildDirectory();
		Logger.log("Loading Mods..", Game.class);
		ModLoader.prepareMods();
		Logger.log("Loading Recipies..", Game.class);
		Recipies.init();
		Biomes.init();
		BuildingManager.init();
		ContainerDragManager.init();
	}
	
}
