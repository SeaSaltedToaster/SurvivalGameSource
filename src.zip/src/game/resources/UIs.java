package game.resources;

import client.Engine;
import client.init.EngineFiles;

public class UIs {

	public static int mainSelected = Engine.getLoader().loadTexture(EngineFiles.UIS_FOLDER+"MainSelected");
	public static int mainUnselected = Engine.getLoader().loadTexture(EngineFiles.UIS_FOLDER+"MainUnselected");
	
	
	public static int woodenPattern = Engine.getLoader().loadTexture(EngineFiles.UIS_FOLDER+"WoodPattern");
	public static int background_1 = Engine.getLoader().loadTexture("UiBackground");
}
