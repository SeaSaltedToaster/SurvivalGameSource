package game.world.voxel;

import client.math.Vector3f;
import game.worldOld.chunk.block.Block;

public class TerrainVoxel {

	public Block blockType;
	public Vector3f position;
	
	public TerrainVoxel(Block blockType, Vector3f position) {
		this.blockType = blockType;
		this.position = position;
	}

	public Block getBlockType() {
		return blockType;
	}

	public Vector3f getPosition() {
		return position;
	}

	public void setBlockType(Block blockType) {
		this.blockType = blockType;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}
	
}
