package game.world;

public class GameWorld {

	//Data and Constant Class
	public static final float SURFACE_LEVEL = 60;
	
}
