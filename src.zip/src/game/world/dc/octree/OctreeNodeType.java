package game.world.dc.octree;

public enum OctreeNodeType {
    Node_None,
    Node_Internal,
    Node_Psuedo,
    Node_Leaf
}
