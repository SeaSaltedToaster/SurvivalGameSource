package game.world.dc.octree;

import client.math.Vector3f;
import client.math.Vector4f;
import game.world.dc.qef.QEFData;

public class OctreeDrawInfo {
    public int index;
    public int corners;
    public Vector4f position;
    public Vector3f averageNormal;
    public QEFData qef;
}