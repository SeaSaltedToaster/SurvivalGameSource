package game.world.dc.octree;

public class OctreeData {

	private OctreeNode[][][] octree;
	
	public OctreeData() {
		octree = new OctreeNode[64][64][64];
	}

	public OctreeNode[][][] getOctree() {
		return octree;
	}

	public void setOctree(OctreeNode[][][] octree) {
		this.octree = octree;
	}
	
}
