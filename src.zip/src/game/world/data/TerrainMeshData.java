package game.world.data;

import java.util.ArrayList;
import java.util.List;

import client.collision.CollisionWorld;
import client.collision.mesh.CollisionMeshFactory;
import client.collision.mesh.CustomCollisionMesh;
import client.math.Vector3f;
import client.render.model.RawModel;
import client.render.standard.Vertex;
import client.render.standard.tools.MeshBuilder;
import client.render.standard.tools.Triangulator;
import game.GameObjects;
import game.world.chunk.TerrainPosition;
import game.world.dc.DualContouring;
import game.world.dc.octree.OctreeData;
import game.world.dc.octree.OctreeNode;

public class TerrainMeshData {

	public RawModel model;
	
	private OctreeNode root;
	
	public List<Vertex> vertices;
	private List<Integer> indcies;
	
	private OctreeData octree;
	
	private CustomCollisionMesh collisionObject;
    
    public TerrainMeshData(TerrainPosition pos) {
    	octree = new OctreeData();
    	root = GameObjects.dc.BuildOctree(new Vector3f(0,0,0), 32, GameObjects.THRESHOLDS[0], octree);
    	vertices = new ArrayList<Vertex>();
    	indcies = new ArrayList<Integer>();
    	
    }
    
    public void loadOctree() {
    	DualContouring.GenerateMeshFromOctree(root, vertices, indcies);
    }
    
    public RawModel loadBasicFlatTestMesh() {
    	model = MeshBuilder.createTerrainModel(vertices, Triangulator.triangulateIndices(indcies));
    	return model;
    }
	
}
