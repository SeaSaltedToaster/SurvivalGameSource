package game.world.data;

import game.world.voxel.TerrainVoxel;

public class TerrainData {

	public TerrainVoxel[][][] voxelData;
	
}
