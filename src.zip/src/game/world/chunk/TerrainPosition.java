package game.world.chunk;

import client.math.Vector3f;

public class TerrainPosition {

	private Vector3f position;
	
	private float xIndex,zIndex;
	
	public TerrainPosition(Vector3f position, float xIndex, float zIndex) {
		super();
		this.position = position;
		this.xIndex = xIndex;
		this.zIndex = zIndex;
	}

	public Vector3f getPosition() {
		return position;
	}

	public float getxIndex() {
		return xIndex;
	}

	public float getzIndex() {
		return zIndex;
	}
	
}
