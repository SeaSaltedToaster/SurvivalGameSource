package game.world.chunk;

import client.entities.Entity;
import client.init.Textures;
import client.math.Vector3f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.texture.ModelTexture;
import client.thread.GlRequestProcessor;
import game.main.states.Game;
import game.world.data.TerrainData;
import game.world.data.TerrainMeshData;
import game.world.loading.TerrainChunkOctreeRequest;

public class TerrainChunk {

	public TerrainData data;
	public TerrainMeshData meshData;
	public TerrainPosition position;
	
	public RawModel mesh;
	private Entity chunkEntity;
	private boolean generate = false;
	
	public TerrainChunk(TerrainPosition position) {
		this.position = position;
		this.meshData = new TerrainMeshData(position);
		this.data = new TerrainData();
	}
	
	public void generateThreadedTerrain() {
		TerrainChunkOctreeRequest request = new TerrainChunkOctreeRequest();
		GlRequestProcessor.sendRequest(request);
	}
	
	public void generateTerrainChunk() {
		this.mesh = meshData.loadBasicFlatTestMesh();
		this.chunkEntity = new Entity(new TexturedModel(mesh, new ModelTexture(Textures.arrow)), position.getPosition(),0,0,0,1);
		
		Game.chunks.add(getChunkEntity());
	}
	
	public void update() {
		if(generate)
			generateTerrainChunk(); generate = false;
			
		if(chunkEntity != null)
			getChunkEntity().setPosition(position.getPosition());
		System.out.println(position.getPosition().toString());
		
	}
	
	public void onChunkDataRecieved() {
		generateTerrainChunk();
	}

	public Entity getChunkEntity() {
		return chunkEntity;
	}

	public TerrainPosition getPosition() {
		return position;
	}
	
}
