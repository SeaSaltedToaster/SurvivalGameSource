package game.world.loading;

import client.Engine;
import client.engine.Logger;
import client.math.Vector3f;
import client.thread.GlRequest;
import game.world.chunk.TerrainPosition;
import game.world.chunk.TerrainChunk;

public class TerrainChunkOctreeRequest extends GlRequest {
	
	private TerrainChunk chunk;
	
	@Override
	public void execute() {
		chunk = new TerrainChunk(new TerrainPosition(new Vector3f(0,0,0),0,0));
		chunk.meshData.loadOctree();
		chunk.onChunkDataRecieved();
	}

}
