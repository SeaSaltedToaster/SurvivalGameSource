package game.gamemodes;

public enum Gamemode {
	
	Survival("Survival",1),
	Creative("Creative",2),
	FlagCapture("Capture the Flag",3);
	
	String name;
	int id;
	
	Gamemode(String name, int id) {
		this.id = id; 
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public static Gamemode getMode(int id) {
		for(Gamemode mode : Gamemode.values()) {
			if(mode.getId() == id) {
				return mode;
			}
		}
		return null;
	}

}
