package game.structures.dungeon;

import java.util.Random;

import client.Engine;
import client.entities.Entity;
import client.init.Textures;
import client.math.Vector3f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import game.entities.EntityChest;
import game.entities.components.ComponentType;
import game.entities.components.ContainerComponent;
import game.items.ItemStack;
import game.items.Items;
import game.main.states.Game;

public class DungeonBaseGenerator {
	
	private static Integer[][] map; 
	
	private static int ex,ey;
	
	private static Random random = new Random();
	
	static int width = 50;
    static int height = 50;
    
    static int px,py,pz;
    
    static float scale = 5;
    
    private static boolean randSize = true; //Buggy
    
    static RawModel floor = OBJLoader.loadObjModel("structures/dungeon/test", Engine.getLoader());
    static RawModel wall = OBJLoader.loadObjModel("structures/dungeon/flatWall", Engine.getLoader());
    static RawModel doorWall = OBJLoader.loadObjModel("structures/dungeon/doorWall", Engine.getLoader());
    static RawModel door = OBJLoader.loadObjModel("structures/dungeon/door", Engine.getLoader());
    static RawModel chest = OBJLoader.loadObjModel("structures/dungeon/chest", Engine.getLoader());
    static RawModel anvil = OBJLoader.loadObjModel("structures/dungeon/anvil", Engine.getLoader());
    
	public static void gen(int rx,int rz) {
		
		py = (int) 1;
		px = rx;
		pz = rz;
		
		if(randSize) {
			width = Math.min(random.nextInt(50),25);
		    height = Math.min(random.nextInt(50),25);
		}
		
		map = new Integer[width][height];
        
        for(int x = 0; x < width; x++) {
       	 	for(int y = 0; y < height; y++) {
       	 		map[x][y] = 1;
       	 		if(random.nextInt(width) > (width/10)*9) {
       	 			map[x][y] = 0;
       	 		}
       	 	}
        }
        
        for(int y = 0; y < 10; y++) {
   	 		iterate();
   	 		reiterate();
   	 	}
//        generateSurfaceEntrance();
        createFloorMesh();
        genXWalls();
        genZWalls();
//        generateSurfaceEntranceMeshes();
	}
	
	private static void iterate() {
		for(int x = 0; x < width; x++) {
       	 	for(int y = 0; y < height; y++) {
       	 	
       	 		if(map[x][y] == 0) {
       	 			if(random.nextInt(100) > 75) {
       	 				if(x+1 < width && y+1 < height && x-1 > 0 && y-1 > 0) {
       	 					if(random.nextInt(100) > 75) {
       	 						map[x][y+1] = 0;
       	 					} 
       	 					if(random.nextInt(100) < 25) {
       	 						map[x+1][y] = 0;
       	 					}
       	 				}
       	 			}
       	 			
       	 		}
       	 		
       	 	}
        }
	}
	
	private static void reiterate() {
		for(int x = 0; x < width; x++) {
       	 	for(int y = 0; y < height; y++) {
       	 		if(x+1 < width && y+1 < height && x-1 > 0 && y-1 > 0)  {
       	 			if(map[x-1][y] == 1 && map[x+1][y] == 1 && map[x][y+1] == 1 && map[x][y-1] == 1) {
       	 				map[x][y] = 1;
       	 			}
       	 		} else {
       	 			map[x][y] = 1;
       	 		}
       	 		
       	 		//NEXT
       	 		if(x+2 < width && y+2 < height && x-2 > 0 && y-2 > 0)  {
       	 			if(map[x-2][y] == 0) {
       	 				map[x][y] = 1;
       	 			}
       	 			if(map[x+2][y] == 0) {
       	 				map[x][y] = 0;
       	 			}
       	 			if(map[x][y-2] == 0) {
       	 				map[x][y] = 1;
       	 			}
       	 			if(map[x][y+2] == 0) {
       	 				map[x][y] = 0;
       	 			}
       	 		}
       	 	}
        }
	}
	
	private static void createFloorMesh() {
		for(int x = 0; x < width; x++) {
       	 for(int y = 0; y < height; y++) {
       		 	if(map[x][y] == 0) {
       		 		//FLOOR
       		 		Entity floorMesh = new Entity(new TexturedModel(floor, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale+px,py,y*scale+pz), 0, 0, 0, scale/2);
       		 		Game.getEntities().add(floorMesh);
       		 		//ROOF (DEFAULT FLAT)
       		 		Entity roofMesh = new Entity(new TexturedModel(floor, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale+px,py+scale,y*scale+pz), 0, 0, 0, scale/2);
       		 		Game.getEntities().add(roofMesh);
       		 		if(x == ex && y == ey) {
       		 			roofMesh.getPosition().y = py + (scale * 3)-0.55f;
       		 		}
       		 		
       		 		//CHEST SPAWNING RATE
       		 		if(random.nextInt(100) > 95) {
       		 			//CHEST
           		 		generateChest(x*scale+px,y*scale+pz);
       		 		} else if(random.nextInt(100) > 97.5) {
       		 			//CHEST
           		 		Entity anvilMesh = new Entity(new TexturedModel(anvil, new ModelTexture(Textures.Inventory)), new Vector3f(x*scale+px,py+0.5f,y*scale+px), 0, random.nextInt(360), 0, (scale /7.5f));
           		 		Game.getEntities().add(anvilMesh);
       		 		}
       		 	}
            }
       }
	}
	
	private static void generateChest(float x, float z) {
		EntityChest chestMesh = new EntityChest(new Vector3f(x,py+1f,z));
		ContainerComponent container = (ContainerComponent) chestMesh.getComponent(ComponentType.Container);
		//RANDOM ITEMS
		if(random.nextInt(100) > 15) {
			container.getContainer().addItem(new ItemStack(Items.COPPER_BAR,random.nextInt(20)));
		} else if(random.nextInt(100) > 0) {
			container.getContainer().addItem(new ItemStack(Items.EMERALD,random.nextInt(18)));
		} else if(random.nextInt(100) > 10) {
			container.getContainer().addItem(new ItemStack(Items.ARROW,random.nextInt(26)));
		} else if(random.nextInt(100) > 20) {
			container.getContainer().addItem(new ItemStack(Items.HORNED_HELMET,1));
		}
		Game.getEntities().add(chestMesh);
	}
	
	private static void genXWalls() {
		for(int x = 0; x < width; x++) {
	       	 for(int y = 0; y < height; y++) {
	       		 	if(map[x][y] == 0) {
		//WALL (X-)
		if(map[x-1][y] == 1) {
			//NORMAL WALL
			Entity wallMesh = new Entity(new TexturedModel(wall, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale-(scale /2)+px,py,y*scale+pz), 0, 0, 0, scale/2);
			Game.getEntities().add(wallMesh);
		}
		//WALL (X+)
	 		if(map[x+1][y] == 1) {
	 			//NORMAL WALL
	 			Entity wallMesh = new Entity(new TexturedModel(wall, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale+(scale /2)+px,py,y*scale+pz), 0, 0, 0, scale/2);
	 			Game.getEntities().add(wallMesh);
	 		}
	       		 	}
	       	 }
		}
	}
	
	private static void genZWalls() {
		for(int x = 0; x < width; x++) {
	       	 for(int y = 0; y < height; y++) {
	       		 	if(map[x][y] == 0) {
		//WALL (X-)
		if(map[x][y-1] == 1) {
			//NORMAL WALL
			Entity wallMesh = new Entity(new TexturedModel(wall, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale+px,py,y*scale-(scale /2)+pz), 0, 90, 0, scale/2);
			Game.getEntities().add(wallMesh);
		}
		//WALL (X+)
	 		if(map[x][y+1] == 1) {
	 			//NORMAL WALL
	 			Entity wallMesh = new Entity(new TexturedModel(wall, new ModelTexture(Textures.stoneBricks)), new Vector3f(x*scale+px,py,y*scale+(scale /2)+pz), 0, 90, 0, scale/2);
	 			Game.getEntities().add(wallMesh);
	 		}
	       		 	}
	       	 }
		}
	}

}
