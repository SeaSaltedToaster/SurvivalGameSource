package game.structures.dungeon.rooms;

public class DungeonRoom {

}
