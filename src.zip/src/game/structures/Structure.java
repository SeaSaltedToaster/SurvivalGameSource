package game.structures;

public class Structure {

}
