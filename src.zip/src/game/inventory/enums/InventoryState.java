package game.inventory.enums;

public enum InventoryState {

	OPEN, CLOSED, NULL
	
}
