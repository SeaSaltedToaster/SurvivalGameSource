package game.inventory.enums;

public enum InventoryType {

	PLAYER, CHEST, 
	
}
