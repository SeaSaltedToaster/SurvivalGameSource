package game.inventory.crafting;

import client.Engine;
import client.entities.Player;
import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Loader;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;
import game.items.crafting.CraftingRecipie;

public class CraftingButton extends UiButton {

	protected CraftingRecipie recipie;
	
	private UiBlock block = new UiBlock(Textures.grassy, new Vector2f(0,0), new Vector2f(0.05f,0.075f));
	private GUIText amount = new GUIText("", 1f, Fonts.ARIAL, new Vector2f(0,10), 1f, true);
	
	private GUIText name = new GUIText("", 1f, Fonts.ARIAL, new Vector2f(0,10), 1f, true);
	
	public CraftingButton(Vector2f position, CraftingRecipie recipie) {
		super(Engine.getLoader(), "inventory", position, new Vector2f(0.15f, 0.075f));
		
		this.recipie = recipie;
		
		this.block.setTexture(recipie.getGive().getIcon().getID());
		this.block.setPosition(position.add(new Vector2f(-0.09f,0)));
	}
	
	@Override
	public void onClick() {
		for(ItemStack item : Player.player.getContained()) {
			if(item.getAmmount() >= recipie.getAmount() && item.getItem() == recipie.getRequired()) {
				item.remove(recipie.getAmount());
				Player.player.addItem(new ItemStack(recipie.getGive(),recipie.getGiveAmount()));
				return;
			}
		}
	}

	public CraftingRecipie getRecipie() {
		return recipie;
	}

	public UiBlock getBlock() {
		return block;
	}

	public GUIText getAmount() {
		return amount;
	}

	public GUIText getName() {
		return name;
	}
	
}
