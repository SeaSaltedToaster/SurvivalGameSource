package game.inventory.crafting;

import java.util.ArrayList;
import java.util.List;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.text.TextMaster;
import client.init.Textures;
import client.math.Vector2f;
import game.items.Items;
import game.items.crafting.Recipies;
import game.resources.UIs;

public class CraftingPanel {

	private static UiBlock background = new UiBlock(UIs.background_1, new Vector2f(0.75f,0f), new Vector2f(0.2f,0.75f));
	
	private static List<CraftingButton> crafts = new ArrayList<CraftingButton>();
	
	public static void init() {
		for(int i = 0; i < Recipies.recipies.size(); i++) {
			CraftingButton button = new CraftingButton(new Vector2f(0.75f,0.65f - (i*0.15f)), Recipies.recipies.get(i));
			crafts.add(button);
		}
	}
	
	public static void show() {
		background.show();
		for(CraftingButton button : crafts) {
			button.getGuiTexture().show();
			button.getBlock().show();
			TextMaster.loadText(button.getAmount());
			TextMaster.loadText(button.getName());
		}
	}
	
	public static void update() {
		for(CraftingButton button : crafts) {
			button.checkHover();
		}
	}
	
	public static void hide() {
		background.hide();
		for(CraftingButton button : crafts) {
			button.getGuiTexture().hide();
			button.getBlock().hide();
			TextMaster.removeText(button.getAmount());
			TextMaster.removeText(button.getName());
		}
	}
	
}
