package game.inventory;

import java.util.ArrayList;
import java.util.List;

import client.guis.core.UiBlock;
import client.guis.resources.UiResources;
import client.init.Textures;

public class InventoryArmor {
	
	public static UiBlock getBackground() {
		return UiResources.ARMOR;
	}
	
	public static List<InventorySlot> getSlots() {
		List<InventorySlot> slots = new ArrayList<InventorySlot>();
		for(int i =0; i < 4; i++) {
			float yOffset = 0.29f;
			float dy = (float) (0.43483610 - (yOffset * i));
			InventorySlot slot = new InventorySlot(-0.8f, dy, 29+i, null);
			if(i == 0) {
				slot.getButton().getGuiTexture().setTexture(Textures.helmet);
			} else if(i == 1) {
				slot.getButton().getGuiTexture().setTexture(Textures.chestplate);
			} else if(i == 2) {
				slot.getButton().getGuiTexture().setTexture(Textures.pants);
			} else if(i == 3) {
				slot.getButton().getGuiTexture().setTexture(Textures.boots);
			}
			slots.add(slot);
		}
		return slots;
	}


}
