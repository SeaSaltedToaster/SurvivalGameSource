package game.inventory.container;

import java.util.ArrayList;
import java.util.List;

public class ContainerManager {

	private static List<Container> createdContainers = new ArrayList<Container>();
	
	public static void add(Container container) {
		createdContainers.add(container);
	}
	
	public static void updateAll() {
		for(Container container : createdContainers) {
			container.update();
		}
		ContainerDragManager.update();
	}

}
