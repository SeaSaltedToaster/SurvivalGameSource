package game.inventory.container;

import client.Engine;
import client.math.Vector2f;
import client.render.Window;
import client.texture.Texture;
import client.util.input.Mouse;
import game.items.ItemStack;
import game.items.Items;
import game.main.Main;
import game.main.states.Game;

public class ContainerDragManager {
	
	private static ContainerSlot mouseSlot;
	
	public static void init() {
		mouseSlot = new ContainerSlot(new Texture(Engine.getLoader().loadTexture("black")),0,0,0.066f,0.1f,null,-1);
		mouseSlot.setItemInSlot(new ItemStack(Items.NULL,0));
		mouseSlot.setState(ContainerSlotState.FULL);
	}
	
	public static void update() {
		mouseSlot.getIcon().setPosition(new Vector2f((float)Mouse.getMouseCoordsX(),(float)-Mouse.getMouseCoordsY()));
		Game.getTextures().remove(mouseSlot.getIcon());
		Game.getTextures().add(mouseSlot.getIcon());
	}

	public static ContainerSlot getMouseSlot() {
		return mouseSlot;
	}

}
