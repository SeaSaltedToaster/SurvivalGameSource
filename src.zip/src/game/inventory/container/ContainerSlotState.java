package game.inventory.container;

public enum ContainerSlotState {

	FULL, EMPTY, PARTIAL
	
}
