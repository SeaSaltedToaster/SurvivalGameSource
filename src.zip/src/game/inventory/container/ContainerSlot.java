package game.inventory.container;

import java.util.Random;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.entities.Player;
import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.guis.transitions.SlideDriver;
import client.init.Textures;
import client.math.Vector2f;
import client.render.Loader;
import client.texture.Texture;
import client.util.input.Input;
import game.inventory.ContainerTooltip;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;
import game.main.Main;

public class ContainerSlot extends UiButton {
	
	private ItemStack storedItem;
	private UiBlock icon;
	private GUIText stackSize;
	
	private ContainerSlotState state;
	private Container container;
	
	private int id;
	private boolean active;
	
	public ContainerSlot(Texture texture, float x, float y, float dx, float dy, Container container, int id) {
		super(texture, new Vector2f(x,y), new Vector2f(dx,dy));
		this.storedItem = new ItemStack(Items.NULL,1);
		this.icon = new UiBlock(storedItem.getItem().getIcon().getID(), new Vector2f(x,y), new Vector2f(dx/1.25f,dy/1.1f));
		this.state = ContainerSlotState.PARTIAL;
		this.container = container;
		this.id = id;
		this.delay = 128;
		this.stackSize = new GUIText(storedItem.getAmmount()+"", 1f, Fonts.ARIAL, new Vector2f(0,10), 1f, true);
		this.getGuiTexture().setAlpha(0.75f);
	}
	
	public void update() { //Make less messy before it becomes a problem :P
		if(storedItem.getItem() == Items.NULL) {
			this.stackSize.setTextString("");
			this.state = ContainerSlotState.EMPTY;
		} else if(storedItem.getItem() != Items.NULL) {
			this.state = ContainerSlotState.PARTIAL;
			if(this.storedItem.getAmmount() > 1)
				this.stackSize.setTextString(storedItem.getAmmount()+"");
		}
		if(container.getItems().get(id) != null) {
			this.storedItem = container.getItems().get(id);
			this.icon.setTexture(container.getItems().get(id).getItem().getIcon().getID());
		}
		
		stackSize.setPositionOld(getPosition().subtract(new Vector2f(-0.025f,1.025f)));
	}
	
	public void updateText() {
		if(!Player.player.isActive()) {
			stackSize.remove();
		}	else if(storedItem.getAmmount() > 1){
			this.stackSize.setTextString(storedItem.getAmmount()+"");
		}
		
		if(storedItem.getAmmount() <= 0) {
			storedItem.remove();
		}
		
	}
	
	@Override
	public void onClick() {
		
		this.current = 0;
		switch(state) {
		case EMPTY:
			setItemInSlot(ContainerDragManager.getMouseSlot().getStoredItem());
			container.getContained().set(id, ContainerDragManager.getMouseSlot().getStoredItem());
			ContainerDragManager.getMouseSlot().removeItemFromSlot();
			return;
		case FULL:
			ContainerDragManager.getMouseSlot().setItemInSlot(storedItem);
			container.getContained().set(id, new ItemStack(Items.NULL));
			removeItemFromSlot();
			return;
		case PARTIAL:
			checkPartial();
			return;
		}
	}
	
	private void checkPartial() {
		if(ContainerDragManager.getMouseSlot().getStoredItem().getItem() == Items.NULL || ContainerDragManager.getMouseSlot().getStoredItem() == null) {
			ContainerDragManager.getMouseSlot().setItemInSlot(storedItem);
			container.getContained().set(id, new ItemStack(Items.NULL));
			removeItemFromSlot();
		} else if(ContainerDragManager.getMouseSlot().getStoredItem().getItem() == storedItem.getItem() && storedItem.getAmmount()+ContainerDragManager.getMouseSlot().getStoredItem().getAmmount() < storedItem.getItem().getStackSize()){
			storedItem.addToStack(ContainerDragManager.getMouseSlot().getStoredItem().getAmmount());
			ContainerDragManager.getMouseSlot().removeItemFromSlot();
		}
	}
	
	@Override
	public void whileHover() {
		ContainerTooltip.render(this.getPosition().x+0.1f, this.getPosition().y+0.09f, 0.01f, 0.05f, this.storedItem.getItem());
	}
	
	@Override
	public void startHover() {
		
	}
	
	@Override
	public void stopHover() {
		ContainerTooltip.disable();
	}
	
	public void setItemInSlot(ItemStack item) { 
		this.storedItem = item;
		this.storedItem.setAmmount(item.getAmmount());
		this.icon.setTexture(item.getItem().getIcon().getID());
		this.state = ContainerSlotState.PARTIAL;
		updateText();
	}
	
	public void removeItemFromSlot() {
		this.storedItem = new ItemStack(Items.NULL,0);
		this.icon.setTexture(Items.NULL.getIcon().getID());
		this.state = ContainerSlotState.PARTIAL;
		updateText();
	}

	public ItemStack getStoredItem() {
		return storedItem;
	}

	public UiBlock getIcon() {
		return icon;
	}

	public ContainerSlotState getState() {
		return state;
	}

	public void setState(ContainerSlotState state) {
		this.state = state;
	}

	public GUIText getStackSize() {
		return stackSize;
	}

	public Container getContainer() {
		return container;
	}

	public int getId() {
		return id;
	}

	public boolean isActive() {
		return active;
	}

}
