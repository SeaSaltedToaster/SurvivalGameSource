package game.inventory.container;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.guis.core.UiBlock;
import client.init.Textures;
import client.math.Vector2f;
import client.math.Vector3f;
import client.render.Window;
import client.texture.Texture;
import client.util.input.Input;
import client.util.input.Mouse;
import game.inventory.ContainerTooltip;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;
import game.main.Main;
import game.main.states.Game;
import game.resources.UIs;
import game.worldOld.biomes.trees.FoliageGenerator;

public class Container {
	
	private int rows, collumns;
	private float x, y;
	
	private float meta = 0;
	
	private float slotSize;
	private float itemSize;
	
	private String title;
	private boolean active;
	
	private boolean centered;
	
	private Texture background;
	private Texture slot;
	
	UiBlock backgroundUi;
	
	private HashMap<ContainerSlot, ItemStack> items = new HashMap<ContainerSlot, ItemStack>();
	
	private List<ItemStack> contained = new ArrayList<ItemStack>();
	
	public Container(int rows, int collumns, float slotSize, float x, float y, String title, boolean centered) {
		this.rows = rows;
		this.collumns = collumns;
		this.slotSize = slotSize;
		this.itemSize = slotSize % 90;
		this.title = title;
		this.x = x;
		this.y = y;
		this.background = new Texture(UIs.background_1);
		this.slot = new Texture(Engine.getLoader().loadTexture("slotnew2"));
		this.centered = centered;
		
		this.generateUI();
		
		ContainerManager.add(this);
	}

	public void update() {
		updateContainerSlots();
		if(Input.isKeyPressed(GLFW.GLFW_KEY_ESCAPE) && isActive()) {
			close();
		} 
	}
	
	public void addItem(ItemStack item) {
		for(ItemStack stack : contained) {
			if(item.getItem() == stack.getItem() && stack.getItem() != Items.NULL && stack.getAmmount()+item.getAmmount() < item.getItem().getStackSize()) { //Check?
				contained.get(contained.indexOf(stack)).addToStack(item.getAmmount());
				return;
			}
		}
		
		int slot = getOpenSlot();
		getSlot(slot).setItemInSlot(item);
		
		contained.set(slot, item);
	}
	
	public void open() {
		if(active)
			return;
		Game.getTextures().add(backgroundUi);
		Mouse.setMouseVisible(true);
		showContainerSlots();
		active = true;
	}
	
	public void close() {
		Game.getTextures().remove(backgroundUi);
		Mouse.setMouseVisible(false);
		hideContainerSlots();
		active = false;
	}
	
	private void generateUI() {
		float startX = x;
		float startY = y;
		
		float bx = x;
		if(centered)
			bx = 0;
		float by = y/1.3f;
		if(centered)
			by = y;
		
		backgroundUi = new UiBlock(background.getID(), new Vector2f(bx,by-0.05f), new Vector2f(slotSize/1.25f*rows,slotSize*1.35f*collumns));
		
		int slotId = 0;
		for(int y = 0; y < collumns; y++) {
			for(int x = 0; x < rows; x++) {
				ContainerSlot block = new ContainerSlot(new Texture(Textures.Inventory), startX+(x*(slotSize*1.5f)),startY+(y*(slotSize*2.5f)-0.35f), slotSize/1.6f,slotSize, this, slotId);
				items.put(block, new ItemStack(Items.NULL,1));
				contained.add(new ItemStack(Items.NULL,2));
				if(slotId < 24) {slotId+=1;}
			}
		}
	}
	
	private void updateContainerSlots() {
		for(ContainerSlot slot : items.keySet()) {
			if(active) {
				slot.checkHover();
				slot.update();
			}
			slot.updateText();
        } 
	}
	
	private void showContainerSlots() {
		Iterator<?> iterator = items.entrySet().iterator(); 
		while (iterator.hasNext()) { 
			Map.Entry element = (Map.Entry) iterator.next();
			ContainerSlot slot = (ContainerSlot) element.getKey();
			Game.getTextures().add(slot.getGuiTexture());
			Game.getTextures().add(slot.getIcon());
        } 
	}
	
	private void hideContainerSlots() {
		Iterator<?> iterator = items.entrySet().iterator(); 
		while (iterator.hasNext()) { 
			Map.Entry element = (Map.Entry) iterator.next();
			ContainerSlot slot = (ContainerSlot) element.getKey();
			Engine.getTextures().remove(slot.getGuiTexture());
			Engine.getTextures().remove(slot.getIcon());
        } 
	}
	
	private int getOpenSlot() {
		int current = 0;
		for(ItemStack slot : contained) {
			if(slot.getItem() == Items.NULL) {
				return current;
			}
			current++;
		}
		return 0;
	}
	
	public ContainerSlot getSlot(int meta) {
		for(ContainerSlot slot : items.keySet()) {
			if(slot.getId() == meta) {
				return slot;
			}
		}
		return null;
	}

	public int getRows() {
		return rows;
	}

	public int getCollumns() {
		return collumns;
	}

	public double getSlotSize() {
		return slotSize;
	}

	public double getItemSize() {
		return itemSize;
	}

	public String getTitle() {
		return title;
	}

	public boolean isActive() {
		return active;
	}

	public Texture getBackground() {
		return background;
	}

	public Texture getSlot() {
		return slot;
	}

	public HashMap<ContainerSlot, ItemStack> getItems() {
		return items;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getMeta() {
		return meta;
	}

	public boolean isCentered() {
		return centered;
	}

	public UiBlock getBackgroundUi() {
		return backgroundUi;
	}

	public List<ItemStack> getContained() {
		return contained;
	}  

}
