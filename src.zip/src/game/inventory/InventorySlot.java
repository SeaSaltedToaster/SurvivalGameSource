package game.inventory;

import client.Engine;
import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;
import game.items.ItemStack;
import game.items.Items;

public class InventorySlot {

	private float openDelay = 400;
	private int lastOpen = 0;
	public boolean clicked = false;
	
	UiButton button = new UiButton(Engine.getLoader(), "inventory", new Vector2f(0f,0f), new Vector2f(0.08333333f,0.1481f)) {
		@Override
		public void onClick() {
			if(lastOpen > openDelay) {
				if(container.isHoldingItem() && !isTaken) { //Dropping the item into this slot
					setItem(container.getCurrentItem());
					container.setCurrentItem(null);
					isTaken = true;
					container.setHoldingItem(false);
					lastOpen = 0;
					clicked = true;
					return;
					
				}
				if(!container.isHoldingItem() && isTaken) { //Picking up the item from this slot
					container.setCurrentItem(item);
					isTaken = false;
					container.setHoldingItem(true);
					lastOpen = 0;
					return;
				} 
				if(container.isHoldingItem() && isTaken) { //Swapping items between cursor and slot OR Adding item to stack
					if(!container.getCurrentItem().getItem().equals(item.getItem()))
						return; lastOpen = 0;
					if(item.isFull())
						return;
					item.addToStack(container.getCurrentItem().getAmmount());
					container.setHoldingItem(false);
					lastOpen = 0;
					return;
				} 
			}
			clicked = false;
		}

		@Override
		public void whileHover() {
			this.playHoverAnimation(0.0025f);
			if(isTaken && container.isOpen() && !container.isDragging()) {
				container.getTooltip().render(x + 0.1f, y + 0.1f, 0.01f, 0.05f, item.getItem());
				return;
			} 
			
		}

		@Override
		public void startHover() {
		}

		@Override
		public void stopHover() {
			if(isTaken) 
				container.getTooltip().disable();
		}
	};
	
	float x,y;
	float ID;
	boolean isTaken = false;

	Inventory container;
	
	ItemStack item = new ItemStack(Items.NULL);
	
	UiBlock itemIcon = new UiBlock(1, new Vector2f(button.getPosition().x-1f,button.getPosition().y), new Vector2f(button.getScale().x - 0.02f,0.1296296f));
	
	private GUIText stackSize = new GUIText(item.getAmmount()+"", 1.5f, Fonts.ARIAL, new Vector2f(0,10), 1f, true);
	
    public InventorySlot(float x, float y, float ID, Inventory inv) {
    	this.x = x;
    	this.y = y;
    	this.ID = ID;
    	this.itemIcon.setPosition(new Vector2f(x,y - 0.02f));
    	this.button.setPosition(new Vector2f(x,y));
    	this.button.delay = 700;
    	this.itemIcon.setTexture(item.getItem().getIcon().getID());
    	this.stackSize.setColour(1, 1, 1);
    	TextMaster.removeText(stackSize);
	}
    
    public InventorySlot(float x, float y, float ID, Inventory inv, float sizeX, float sizeY) {
    	this.x = x;
    	this.y = y;
    	this.ID = ID;
    	this.itemIcon.setPosition(new Vector2f(x,y-0.02f));
    	this.button.setPosition(new Vector2f(x,y));
    	this.button.delay = 700;
    	this.itemIcon.setTexture(item.getItem().getIcon().getID());
    	this.stackSize.setColour(1, 1, 1);
    	TextMaster.removeText(stackSize);
	}
    
    public void update() {
    	lastOpen+=1;
    	if(isTaken && container.isOpen() && item.getAmmount() > 1) {
    		stackSize.setPositionOld(new Vector2f(itemIcon.getPosition().x + 0.05f, itemIcon.getPosition().y - 1.1f));
    		TextMaster.removeText(stackSize);
    		stackSize.setTextString(item.getAmmount()+"");
    	} else if(!isTaken || !container.isOpen() || item.getAmmount() > 1) {
    		stackSize.setTextString("");
    	}
    	
    	if(!container.isOpen()) {
    		stackSize.setTextString("");
    	}
    	
    	if(!isTaken) {
    		item = new ItemStack(Items.NULL);
    	}
    	
    }
  
	public UiButton getButton() {
		return button;
	}

	public ItemStack getItem() {
		return item;
	}

	public UiBlock getItemIcon() {
		return itemIcon;
	}

	public void setItem(ItemStack item) {
		this.item = item;
		this.itemIcon.setTexture(item.getItem().getIcon().getID());
	}
	
	public void addItem() {
		this.item.addToStack();
	}

	public void setContainer(Inventory container) {
		this.container = container;
	}

	public void setItemIcon(UiBlock itemIcon) {
		this.itemIcon = itemIcon;
	}

	public float getID() {
		return ID;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}
	
}
