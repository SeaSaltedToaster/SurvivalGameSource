package game.inventory;

import client.Engine;
import client.guis.core.UiBlock;
import client.guis.text.Fonts;
import client.guis.text.GUIText;
import client.guis.text.TextMaster;
import client.math.Vector2f;
import client.util.input.Mouse;
import game.items.Item;
import game.items.Items;

public class ContainerTooltip {

	private static UiBlock tooltip = new UiBlock(Engine.getLoader().loadTexture("tooltip"), new Vector2f(1,1), new Vector2f(1,1));
	private static GUIText text = new GUIText("inventory.tooltiptext", 1f, Fonts.ARIAL, new Vector2f(0,0), 1f, true);
	
	public ContainerTooltip() {
		tooltip = new UiBlock(Engine.getLoader().loadTexture("tooltip"), new Vector2f(1,1), new Vector2f(1,1));
		text = new GUIText("inventory.tooltiptext", 1f, Fonts.ARIAL, new Vector2f(0,0), 1f, true);
		text.setColour(1, 1, 1);
		TextMaster.removeText(text);
	}
	
	public static void render(float x, float y, float sizeX, float sizeY, Item itemName) {
		
		float tooltipX = (float)Mouse.getMouseCoordsX() + 0.075f;
		float tooltipY = (float)-Mouse.getMouseCoordsY() + 0.05f;
		
		//Tooltip Ui stuff
		tooltip.setPosition(new Vector2f(tooltipX,tooltipY));
		tooltip.setScale(new Vector2f(sizeX * text.getTextLength(), sizeY));
		
		//Text stuff
		text.setPosition(new Vector2f(tooltipX/2,-tooltipY/2+0.475f));
		text.setTextString(itemName.getCustomName());
		
		//Rendering Mess
		if(itemName != Items.NULL) {
			if(!Engine.getTextures().contains(tooltip)) {
				Engine.getTextures().add(tooltip);
			}
			TextMaster.removeText(text);
			TextMaster.loadText(text);
		}
	}
	
	public static void disable() {
		Engine.getTextures().remove(tooltip);
		TextMaster.removeText(text);
	}
	
}
