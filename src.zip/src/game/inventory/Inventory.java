package game.inventory;

import java.util.ArrayList;
import java.util.List;
import org.lwjgl.glfw.GLFW;

import client.guis.button.UiButton;
import client.guis.core.UiBlock;
import client.guis.resources.UiResources;
import client.guis.text.GUIText;
import client.math.Vector2f;
import client.util.input.Input;
import client.util.input.Mouse;
import game.chat.CommandConsole;
import game.items.Item;
import game.items.ItemStack;
import game.items.Items;

public class Inventory {
	
	public UiBlock background = UiResources.INVENTORY;
	
	private ContainerTooltip tooltip;
	private InventoryHotbar hotbar;
	
	private int rows,columns;
	private int sizeX,sizeY;
	
	private String title;
	private GUIText titleText;
	
	private List<InventorySlot> slots;
	private List<UiButton> buttons;
	
	private List<UiBlock> guis;
	private List<ItemStack> items; 
	
	private boolean isOpen = false; //sync with hideAll method in UiComponent
	private float openDelay = 20; //Timer class
	private int lastOpen = 0; //Timer class
	private boolean hidGUIs = false; //hide all method in UiComponent
	private boolean isDragging = false;
	
	private boolean isHoldingItem = false; //Item manager class
	
	private ItemStack currentItem = null; //Item manager class
	private UiBlock currentItemUI = new UiBlock(1, new Vector2f(0f,0f), new Vector2f(0.08333333f,0.1481f)); //Item manager class
	
	CommandConsole console = new CommandConsole(); //temporary
	
	public Inventory(int rows, int columns, int slotSize, String title) {
		this.rows = rows;
		this.columns = columns;
		this.title = title;
		
		buttons = InventoryButtons.init(rows,columns,this);
		slots = InventoryButtons.initSlots(rows,columns,this);
		guis = new ArrayList<UiBlock>();
		items = new ArrayList<ItemStack>();
		
		tooltip = new ContainerTooltip();
		hotbar = new InventoryHotbar();
		
		for(int i = 0; i < 28; i++) {
			items.add(new ItemStack(Items.CARROT));
		}
	}
	
	public void stopTestThread() {
		console.stop();
	}
	
	public void update() {
		updateSlots();
		updateKeys();
		hotbar.update();
		lastOpen++;
	}
	
	public void updateSlots() {
		for(InventorySlot slot : slots) {
			
			if(!(slot.getID() >= items.size())) {
				items.set((int) slot.getID(), slot.getItem());
			}
			
			slot.update();
			slot.getButton().checkHover();
			slot.getItemIcon().setPosition(new Vector2f(slot.getX(),slot.getY()));
			
			//Drag and Drop UI 
			if(!slot.isTaken) {
				guis.remove(slot.getItemIcon());
			} else if(slot.isTaken && !guis.contains(slot.getItemIcon()) && isOpen) {
				guis.add(slot.getItemIcon());
			}
			
			if(isOpen ) {
				//Cursor Drag
				if(isHoldingItem && guis.contains(currentItemUI)) { //If the mouse is holding the items
					currentItemUI.setPosition(new Vector2f((float)Mouse.getMouseCoordsX(),(float) -Mouse.getMouseCoordsY())); isDragging = true;
				} else if(isHoldingItem && !guis.contains(currentItemUI)) { //Adding the UI to the mouse slot
					currentItemUI.setTexture(slot.getItemIcon().getTexture()); guis.add(currentItemUI);
					currentItemUI.setPosition(new Vector2f((float)Mouse.getMouseCoordsX(),(float) -Mouse.getMouseCoordsY())); isDragging = true;
				} else if(!isHoldingItem && guis.contains(currentItemUI)) { //If it gets clicked on
					guis.remove(currentItemUI); isDragging = false;
				}
			}
			if(isDragging || !isOpen)
				tooltip.disable();
		}
	}
	
	public void open() {
		guis.add(background);
		guis.add(UiResources.ARMOR);
		for(UiButton b : buttons) {
			b.show(guis);
		}
		for(InventorySlot slot : slots) {
			if(slot.isTaken) {
				guis.add(slot.getItemIcon());
			}
		}
		guis.removeAll(hotbar.getSlots());
		guis.removeAll(hotbar.getSlotUis());
		hidGUIs = true;
		isOpen = true;
	}
	
	public void hideGuis() {
		guis.remove(background);
		for(UiButton b : buttons) {
			b.hide(guis);
		}
		for(InventorySlot slot : slots) {
			guis.remove(slot.getItemIcon());
		}
		guis.addAll(hotbar.getSlots());
		guis.addAll(hotbar.getSlotUis());
		guis.remove(UiResources.ARMOR);
		tooltip.disable();
		isOpen = false;
		hidGUIs = true;
	}
	
	public void addItem(Item item) {
		if(item != Items.NULL) {
			for(InventorySlot slot : slots) {
				if(slot.getItem().getItem() == item && !slot.getItem().isFull()) {
					slot.getItem().addToStack();
					slot.isTaken = true;
					break;
				}
				if(!slot.isTaken || slot.getItem().getItem() == Items.NULL) {
					slot.setItem(new ItemStack(item));
					slot.isTaken = true;
					items.add(new ItemStack(item));
					break;
				}
			}
			
		}
	}
	
	public void addItemAt(Item item, int meta) {
		if(item != Items.NULL) {
			for(InventorySlot slot : slots) {
				if(!slot.isTaken || slot.getItem().getItem() == Items.NULL) {
					slot.setItem(new ItemStack(item));
					slot.isTaken = true;
					items.set(meta,new ItemStack(item));
					return;
				}
			}
			
		}
	}
	
	public void removeItem(Item item) {
		for(InventorySlot slot : slots) {
			if(slot.isTaken && slot.getItem().getItem() == item) {
				slot.getItem().remove();
				if(slot.getItem().getAmmount() == 0) {
					slot.setItem(new ItemStack(Items.NULL));
				}
				break;
			}
		}
	}
	
	private void updateKeys() {
		if(lastOpen >= openDelay) {
			if(Input.isKeyPressed(GLFW.GLFW_KEY_E)) {
				if(!isOpen) {
					open();
					Mouse.setMouseVisible(true);
				}
				lastOpen=0;
				return;
			}
			if(Input.isKeyPressed(GLFW.GLFW_KEY_ESCAPE)) {
				if(isOpen) {
					hideGuis();
				}
				lastOpen = 0;
				Mouse.setMouseVisible(false);
				return;
			}
			
		}
	}
	
	public List<UiBlock> getUis() {
		return guis;
	}

	public boolean isHoldingItem() {
		return isHoldingItem;
	}

	public void setHoldingItem(boolean isHoldingItem) {
		this.isHoldingItem = isHoldingItem;
	}

	public void setCurrentItem(ItemStack currentItem) {
		this.currentItem = currentItem;
	}

	public List<ItemStack> getItems() {
		return items;
	}

	public ItemStack getCurrentItem() {
		return currentItem;
	}

	public ContainerTooltip getTooltip() {
		return tooltip;
	}

	public boolean isOpen() {
		return isOpen;
	}

	public boolean isDragging() {
		return isDragging;
	}

	public List<InventorySlot> getSlots() {
		return slots;
	}

	public List<UiButton> getButtons() {
		return buttons;
	}


	public void setSlots(List<InventorySlot> slots) {
		this.slots = slots;
	}


	public void setButtons(List<UiButton> buttons) {
		this.buttons = buttons;
	}
	
}

class InventoryButtons {
	
	public static List<UiButton> init(int rows, int columns, Inventory container) {
		List<UiButton> genButtons = new ArrayList<UiButton>();
		for(int y = 0, id = 0; y < columns; y++, id++) {
			for(int x = 0; x < rows; x++) {
				float xOffset = 0.165f;
				float yOffset = 0.29f;
				float startX = container.background.getPosition().x - container.background.getScale().x + (xOffset / 1.35f);
				float startY = container.background.getPosition().y + container.background.getScale().y - (yOffset / 1.525f);
				float dx = (float) (startX + (xOffset * x));
				float dy = (float) (startY - (yOffset * y));
				InventorySlot slot = new InventorySlot(dx, dy, id, null);
				genButtons.add(slot.getButton());
			}
		}
		for(int i = 0; i < InventoryArmor.getSlots().size(); i++) {
			genButtons.add(InventoryArmor.getSlots().get(i).getButton());
		}
		return genButtons;
	}
	
	public static List<InventorySlot> initSlots(int rows, int columns, Inventory container) {
		List<InventorySlot> genSlots = new ArrayList<InventorySlot>();
		int id = 0;
		for(int y = 0; y < columns; y++) {
			for(int x = 0; x < rows; x++) {
				float xOffset = 0.165f;
				float yOffset = 0.29f;
				float dx = (float) (-0.5 + (xOffset * x));
				float dy = (float) (0.475 - (yOffset * y));
				InventorySlot slot = new InventorySlot(dx, dy, id, null);
				slot.setContainer(container);
				genSlots.add(slot);
				id++;
			}
		}
		for(int i = 0; i < InventoryArmor.getSlots().size(); i++) {
			InventorySlot slot = InventoryArmor.getSlots().get(i);
			slot.setContainer(container);
			genSlots.add(slot);
		}
		return genSlots;
	}
	
}
