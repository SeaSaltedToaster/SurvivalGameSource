package game.inventory;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.entities.Player;
import client.guis.core.UiBlock;
import client.math.Vector2f;
import game.items.ItemStack;
import game.items.Items;
import game.main.Main;

public class InventoryHotbar {
	
	private List<UiBlock> uis;
	private List<UiBlock> slots;
	
	private int texture;
	private int texture2;
	private int texture3;
	private Vector2f defaultSize = new Vector2f(0.04333333f,0.0781f);
	
	public static int selected = 4;
	public static int selectedItemIndex = selected;
	private ItemStack selectedItem;
	
	public static int scroll = 0;
	
	public InventoryHotbar() {
		this.slots = new ArrayList<UiBlock>();
		this.uis = new ArrayList<UiBlock>();
		
		texture = Engine.getLoader().loadTexture("items/null/icon");
		texture2 = Engine.getLoader().loadTexture("slotnew");
		texture3 = Engine.getLoader().loadTexture("slotnew2");
		for(int i = -3; i < 4; i++) {
			UiBlock block = new UiBlock(texture, new Vector2f(0.105f * i, -0.9f), new Vector2f(0.03666f,0.0696296f));
			UiBlock slotBG = new UiBlock(texture3, new Vector2f(0.105f * i, -0.9f), new Vector2f(0.04333333f,0.0781f));
			slotBG.setAlpha(0.5f);
			slots.add(block);
			uis.add(slotBG);
		}
	}
	
	public void update() {
		for(UiBlock block : slots) {
			int meta = slots.indexOf(block);
				if(block.getTexture() != Player.player.getContained().get(meta).getItem().getIcon().getID()) {
					block.setTexture(Player.player.getContained().get(meta).getItem().getIcon().getID());
				} else if(Player.player.getContained().get(meta).getItem() == Items.NULL && block.getTexture() != texture){
					block.setTexture(texture);
				}
		}
		
		for(UiBlock block : uis) {
			int i = uis.indexOf(block);
			block.setScale(defaultSize);
			if(i == selected) {
				block.setTexture(texture2);
				block.setAlpha(0.5f);
			} else if (i == 7 && selected != 7) {
				block.setTexture(texture3);
			} else {
				block.setTexture(texture3);
			}
		}
		selectedItemIndex = (selected);
		selectedItem = Player.player.getContained().get(selectedItemIndex);

		if(!Player.player.isActive())
			checkUses();
		
		if(Main.getCamera().getScrollValue() == 1 && time >= delay) {
			selected -= 1;
			if(selected >= 7) {;
				selected = 0;
			} else if(selected == -1) {;
				selected = 6;
			}
			time = 0;
		}
		if(scroll < 0 && time >= delay) {
			selected += 1;
			if(selected >= 7) {
				selected = 0;
			}else if(selected == -1) {;
				selected = 6;
			}
			time = 0;
		}
		time++;
	}
	int time = 0;
	int delay = 3;
	
	public void checkUses() {
		if(GLFW.glfwGetMouseButton(Main.getWindow().getWindowID(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == 1 && time > 20) {
			selectedItem.getItem().onLeftClick();
			time = 0;
		} else if(GLFW.glfwGetMouseButton(Main.getWindow().getWindowID(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == 1 && time > 20) {
			selectedItem.getItem().onRightClick();
			time = 0;
		}
	}

	public List<UiBlock> getSlots() {
		return uis;
	}
	
	public List<UiBlock> getSlotUis() {
		return slots;
	}
	
}
