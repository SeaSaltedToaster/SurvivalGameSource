package game.chat;

import client.Engine;
import client.guis.core.UiBlock;
import client.math.Vector2f;

public class ChatUIs {

	public static UiBlock INPUT = new UiBlock(Engine.getLoader().loadTexture("gradient"), new Vector2f(0,-0.5f), new Vector2f(1,1));
	
}
