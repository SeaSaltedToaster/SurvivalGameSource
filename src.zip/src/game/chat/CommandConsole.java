package game.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import client.entities.Player;
import game.items.ItemStack;
import game.items.Items;

public class CommandConsole extends Thread {
	
	public Thread cmdThread;
	public BufferedReader scanner;
	
	public boolean canContinue = true;

	@Override
	public void run() {
		while(canContinue) {
			check();
		}
	}
	
	public void check() {
		scanner = new BufferedReader(new InputStreamReader(System.in));
		String name = null;
		try {
			if(scanner.readLine() == null)
				return;
			name = scanner.readLine();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		if(name.startsWith("/give ")) {
			Player.player.addItem(new ItemStack(Items.getItemFromString(name.replace("/give ", ""))));
		}
	}
	
	public void endCommand() {
		canContinue = false;
	}

}
