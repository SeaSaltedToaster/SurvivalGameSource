package game.chat;

public class GameChat {
	
	public static boolean isOpen = false;
	
	public static void init() {
		
	}

}
