package game.ai;

public abstract class AIType {

	public enum AITypes {
		RANDOM_MOVE,
	}
	
	public abstract AITypes getAIType();
	
}
