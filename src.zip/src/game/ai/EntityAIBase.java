package game.ai;

import game.ai.AIType.AITypes;

public abstract class EntityAIBase {

	public abstract boolean shouldExecute();

    public boolean continueExecuting()
    {
        return this.shouldExecute();
    }

    public boolean isInterruptible()
    {
        return true;
    }

    public void startExecuting()
    {
    }

    public void resetTask()
    {
    }

    public void updateTask()
    {
    }
	
    public abstract AITypes getAIType();
    
}
