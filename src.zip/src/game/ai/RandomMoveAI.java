package game.ai;

import client.entities.Entity;
import client.math.MathUtils;
import client.math.Vector3f;
import game.ai.AIType.AITypes;

public class RandomMoveAI extends EntityAIBase {
	
	protected double xPosition;
    protected double yPosition;
    protected double zPosition;
    protected final double speed = 1;
    protected int executionChance;
    
    protected boolean moving;
    
    protected Vector3f nextPos;
    protected Vector3f originalPos;
    protected Entity entity;
    
    public RandomMoveAI(Entity entity) {
    	this.entity = entity;
    }
	
	public Vector3f getNextMovePosition(Vector3f currentPos, int radius) {
		originalPos = currentPos;
		Vector3f nextPos = new Vector3f(0,currentPos.y,0);
		nextPos.x = getRandomNumber(-radius,radius) + currentPos.x;
		nextPos.z = getRandomNumber(-radius,radius) + currentPos.z;
		this.moving = true;
		this.nextPos = nextPos;
		return nextPos;
	}
	
	public void start() {
		Vector3f target = getNextMovePosition(entity.getPosition(), 25);
		setNextPos(target);
		entity.setRy(MathUtils.calculateVectorRotationY(target.toVector2f()));
	}
	
	public void moveToTarget() {
		Vector3f move = nextPos.subtract(originalPos).divide(1000);
		entity.increasePosition(move.x, move.y, move.z);
	}
	
	public boolean reachedTarget() {
		Vector3f move = nextPos.subtract(entity.getPosition());
		return (move.lengthSquared() < 3f);
	}
	
	public float getRandomNumber(float min, float max) {
	    return (float) ((Math.random() * (max - min)) + min);
	}

	@Override
	public boolean shouldExecute() {
		
		return false;
	}

	@Override
	public AITypes getAIType() {
		return AITypes.RANDOM_MOVE;
	}

	public boolean isMoving() {
		return moving;
	}

	public void setMoving(boolean moving) {
		this.moving = moving;
	}

	public Vector3f getNextPos() {
		return nextPos;
	}

	public void setNextPos(Vector3f nextPos) {
		this.originalPos = entity.getPosition();
		this.nextPos = nextPos;
	}

}
