package game.save.loading;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import game.save.SaveFile;
import game.save.SaveManager;

public class SaveLoader {
	
	public static BufferedReader reader;
	
	public static void loadGame(SaveFile file) {
		File location = new File(file.getLocation()+"/level.toastario");
		setReaderFile(location);
		
		SaveManager.currentFile = file;
	}
	
	private static void setReaderFile(File file) {
		try {
			reader = new BufferedReader(new FileReader(file.toString()));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static SaveFile loadLocation(String location) {
		File playerSaveFile = new File(location);
		String saveName = playerSaveFile.getName();
		
		int saveSize = (int) playerSaveFile.length();
		boolean modded = checkMods(playerSaveFile);
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy ");
		
		FileTime time = getFileTime(playerSaveFile);
		
		String lastTime = df.format(time.toMillis());
		
		return new SaveFile(playerSaveFile, saveName, saveSize, lastTime, modded);
	}
	
	private static boolean checkMods(File file) {
		File modded = new File(file+"/mods.toastario");
		return modded.exists();
	}
	
	public static FileTime getFileTime(File file) {
		FileTime time = null;
		try {
			time = Files.getLastModifiedTime(file.toPath());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return time;
	}

}
