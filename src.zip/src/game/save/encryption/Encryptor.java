package game.save.encryption;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Encryptor {
    
    protected static byte[] input;  
    
    protected static KeyPairGenerator keyPairGen;
    protected static KeyPair pair; 
    protected static Cipher cipher;
    
    public void init() {
		try {
			keyPairGen = KeyPairGenerator.getInstance("RSA");
			keyPairGen.initialize(2048);
			
			pair = keyPairGen.generateKeyPair();  
			
	    	cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    	cipher.init(Cipher.ENCRYPT_MODE, pair.getPublic());
	    	
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
			e.printStackTrace();
		}
    }

    public static String encrypt(String text) {
    	input = text.getBytes();
    	cipher.update(input);
    	
    	byte[] cipherText = getEncryptedBytes();
		String encryptedString = getStringFromBytes(cipherText);
		
		return encryptedString;
    }
    
    private static String getStringFromBytes(byte[] cipherText) {
    	String enc = null;
		try {
			enc = new String(cipherText, "UTF8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		return enc;
    }
    
    private static byte[] getEncryptedBytes() {
    	byte[] cipherText = null;
		try {
			cipherText = cipher.doFinal();
		} catch (IllegalBlockSizeException | BadPaddingException e) {
			e.printStackTrace();
		}
		return cipherText;
    }
    
}
