package game.save;

import java.io.File;
import java.nio.file.attribute.FileTime;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SaveFile {
	
	public File location;
	public int size;
	public String name;
	
	public String lastPlayed;
	public boolean modded;
	
	public SaveFile(File location, String name, int size, String lastPlayed, boolean modded) {
		this.location = location;
		this.name = name;
		this.size = size;
		this.lastPlayed = lastPlayed;
		this.modded = modded;
	}
	
	public File getLocation() {
		return location;
	}
	public void setLocation(File location) {
		this.location = location;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getLastPlayed() {
		return lastPlayed;
	}
	public void setLastPlayed(String lastPlayed) {
		this.lastPlayed = lastPlayed;
	}
	public boolean isModded() {
		return modded;
	}
	public void setModded(boolean modded) {
		this.modded = modded;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String timeToString(FileTime fileTime) {
	    DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy - hh:mm:ss");
	    String string = dateFormat.format(fileTime.toMillis());
	    return string.substring(0, string.length() -3);
	}

}
