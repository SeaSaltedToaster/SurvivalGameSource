package game.save;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import client.entities.Player;
import client.util.DirectoryBuilder;
import client.util.FileUtils;
import game.main.Main;
import game.mods.ToastarioMod;
import game.save.encryption.Encryptor;
import game.worldOld.chunk.Chunk;

public class SaveManager {
	
	public static SaveFile currentFile;
	public static String worldName = "World";
	
	public static String gameMode = "Survival";
	public static String terrainType = "Flat";
	public static String multiplayer = "on";
	
	protected static FileWriter writer = null;
	
	public static void init() {
		createBasicFiles();
		createSaveFile();
	}
	
	private static void createSaveFile() {
		if(currentFile != null)
			return;
		
		String path = DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName;
		
		currentFile = new SaveFile(new File(path), worldName, 0, null, false);
	}
	
	public static File[] getAllSaves() {
		String path = DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/";
		File file = new File(path);
		return file.listFiles();
	}
	
	private static void createBasicFiles() {
		File world = new File(new String(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName));
		world.mkdir();
		File chunks = new File(new String(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/chunks"));
		chunks.mkdir();
		File players = new File(new String(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/playerData"));
		players.mkdir();
		File data = new File(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/level.toastario");
		FileUtils.createFile(data);
	}
	
	public static void saveInventory() {
		File data = new File(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/playerData/inventory.toastario");
		FileUtils.createFile(data);
		
		for(int i = 0; i < Player.getPlayer().getContained().size(); i++) {
//			ItemStack item = Player.getPlayer().getContained().get(i);
//			writeToFile(data, "item:"+item.getItem().getName()+",slot:"+Game.getInventory().getItems().indexOf(item)+",count:"+item.getAmmount()+";");
		}
	}
	
	public static void saveWorldData() {
		File data = new File(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/level.toastario");
		FileUtils.createFile(data);
		
		writeToFile(data, "levelname:"+currentFile.getName()+";gamemode:"+gameMode+";terrainType:"+terrainType+";multiplayer:"+multiplayer+";"+"modded:"+currentFile.isModded());
		
		if(currentFile.isModded()) {
			File data2 = new File(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/mods.toastario");
			FileUtils.createFile(data2);
			
			for(ToastarioMod mod : Main.getMods()) {
				writeToFile(data2, mod.getName()+",");
			}
		}
	}
	
	public static void saveChunk(Chunk chunk) {
		String filet = new String(DirectoryBuilder.getWindowsCurrentUserAppDataPath()+"/Toastario/saves/"+worldName+"/chunks/"+chunk.getPosition().getxIndex()+"-"+chunk.getPosition().getzIndex()+".chunk");
		File file = new File(filet);
		
		try {
			writer = new FileWriter(filet);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String text = new String(chunk.getPosition().getPosition().toString());
		try {
			writer.write(Encryptor.encrypt(text));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void end() {
		try {
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void setWriterFile(File file) {
		try {
			writer = new FileWriter(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void writeToFile(File file, String string) {
		setWriterFile(file);
		
		try {
			writer.write(string);
			writer.flush();
		    writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
