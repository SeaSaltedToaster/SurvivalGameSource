package game.worldOld.chunk.mesh;

import java.util.ArrayList;
import java.util.List;

import client.entities.Entity;
import client.math.Vector2f;
import client.math.Vector3f;
import client.texture.Texture;
import client.util.ArrayUtils;

public class ChunkMeshData {
	
	List<Vector3f> vertices = new ArrayList<Vector3f>(512);
    List<Integer> triangles = new ArrayList<Integer>(512);
    List<Vector3f> normal = new ArrayList<Vector3f>(512);
    List<Vector3f> textures = new ArrayList<Vector3f>(512);
    Entity entity;
    
    Vector3f[] pos = null;
    float[] positions = null;
    int[] indices = null;
    Vector3f[] norm = null;
    float[] normals = null;
    Vector2f[] tex = null;
    float[] texs = null;
    
    Texture biometex;
    
    public void convertData() {
    	pos = vertices.toArray(new Vector3f[vertices.size()*3]);
        positions = ArrayUtils.toFloatArray(pos);
        indices = ArrayUtils.toIntArray(triangles);
        norm = normal.toArray(new Vector3f[normal.size()+1]);
        normals = ArrayUtils.toFloatArray(norm);
        tex = textures.toArray(new Vector2f[textures.size()*2+1]);
        texs = ArrayUtils.toFloatArray(tex);
    }
    
	public ChunkMeshData() {
		super();
	}

	public List<Vector3f> getVertices() {
		return vertices;
	}

	public List<Integer> getTriangles() {
		return triangles;
	}

	public List<Vector3f> getNormal() {
		return normal;
	}

	public List<Vector3f> getTextures() {
		return textures;
	}

	public Entity getEntity() {
		return entity;
	}

	public Texture getBiometex() {
		return biometex;
	}

	public void setBiometex(Texture biometex) {
		this.biometex = biometex;
	}
	
}
