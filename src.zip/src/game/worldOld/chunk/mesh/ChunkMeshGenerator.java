package game.worldOld.chunk.mesh;

import client.math.Vector3f;
import game.worldOld.chunk.ChunkVoxel;
import game.worldOld.chunk.data.ChunkData;
import game.worldOld.chunk.data.MarchingTables;

public class ChunkMeshGenerator {
	
	static int lod = 2;
	
	public static void generate(ChunkMeshData meshData, ChunkData data) {
		for (int x = 0; x < ChunkData.SIZE_X; x++) {
            for (int z = 0; z < ChunkData.SIZE_Z; z++) {
                for (int y = 0; y < ChunkData.height; y++) {
                	
                    float[] cube = new float[8];
                    ChunkVoxel voxel = null;
                    
                    voxel = new ChunkVoxel(cube, data.getBiome().getSurface());
                    
                    for (int i = 0; i < 8; i++) {
                        Vector3f corner = new Vector3f(x, y, z);
                        corner = corner.add(CornerTable[i]);
                        
                        cube[i] = data.terrainMap[(int) corner.x][(int) corner.y][(int) corner.z];
                    }
                    
                    MarchCube(new Vector3f(x, y, z), voxel, meshData);
                }
            }
        }
	}
	
	public static void MarchCube (Vector3f position, ChunkVoxel voxel, ChunkMeshData data) {
		
        int configIndex = GetCubeConfiguration(voxel.getCube());

        if (configIndex == 0 || configIndex == 255)
            return;

        int edgeIndex = 0;
        for(int i = 0; i < 5; i+=lod) {
            for(int p = 0; p < 3; p++) {

                int indice = triangulation[configIndex][edgeIndex];

                if (indice == -1)
                    return;

                Vector3f vert1 = position.add(EdgeTable[indice][0]);
                Vector3f vert2 = position.add(EdgeTable[indice][1]);

                Vector3f vertPosition = (vert1.add(vert2)).divide(2);

                data.getVertices().add(vertPosition);
                data.getTextures().add(new Vector3f(voxel.getBlock().getColor().x,voxel.getBlock().getColor().y,voxel.getBlock().getColor().z));
                data.getNormal().add(new Vector3f(0,1,0));
                data.getTriangles().add(data.getVertices().size()-1);
                edgeIndex++;
                //Unoptimized Area stop
            }
        }
    }

//    private static boolean isEmpty(float[] cubes) {
//    	boolean isEmpty = false;
//    	for(int i = 0; i < cubes.length; i++) {
//    		if(cubes[i] == 1) {
//    			isEmpty = true;
//    		} else {
//    			isEmpty = false;
//    			break;
//    		}
//    	}
//		return isEmpty;
//	}

	static int GetCubeConfiguration (float[] cube) {

        int configurationIndex = 0;
        for (int i = 0; i < 8; i++) {

            if (cube[i] > ChunkData.terrainSurface)
                configurationIndex |= 1 << i;

        }
        
        return configurationIndex;

    }

    static Vector3f[][] EdgeTable = MarchingTables.EdgeTable;
    
		static int triangulation[][] = MarchingTables.triangulation;

		static int cornerIndexAFromEdge[] = MarchingTables.cornerIndexAFromEdge;

		static int cornerIndexBFromEdge[] = {
		    1,
		    2,
		    3,
		    0,
		    5,
		    6,
		    7,
		    4,
		    4,
		    5,
		    6,
		    7
		};
		
		static Vector3f[] CornerTable = new Vector3f[] {

		        new Vector3f(0, 0, 0),
		        new Vector3f(1, 0, 0),
		        new Vector3f(1, 1, 0),
		        new Vector3f(0, 1, 0),
		        new Vector3f(0, 0, 1),
		        new Vector3f(1, 0, 1),
		        new Vector3f(1, 1, 1),
		        new Vector3f(0, 1, 1)

		    };

}
