package game.worldOld.chunk.mesh;

import client.Engine;
import client.entities.Entity;
import client.math.Vector3f;
import client.render.model.RawModel;
import client.render.model.TexturedModel;
import client.texture.ModelTexture;
import client.util.ArrayUtils;
import game.world.chunk.TerrainPosition;

public class ChunkMeshBuilder {
	
	public void generate(ChunkMeshData data, TerrainPosition position) {
		RawModel model = convertData(data);
		ModelTexture texture = new ModelTexture(data.getBiometex().getID());
        TexturedModel finished = new TexturedModel(model, texture);
        data.entity = new Entity(finished,new Vector3f(position.getPosition().x,0,position.getPosition().z),0,0,0,0.5f);
	}
	
	public void generateAfterConversion(ChunkMeshData data, TerrainPosition position) {
		RawModel model = create(data);
		ModelTexture texture = new ModelTexture(data.getBiometex().getID());
        TexturedModel finished = new TexturedModel(model, texture);
        data.entity = new Entity(finished,new Vector3f(position.getPosition().x,0,position.getPosition().z),0,0,0,0.5f);
	}
	
	float[] positions;
	int[] indices;
	float[] normals;
	float[] texs;
	
	public void convert(ChunkMeshData data) {
		Vector3f[] pos = data.vertices.toArray(new Vector3f[0]);
        positions = ArrayUtils.toFloatArray(pos);
        indices = ArrayUtils.toIntArray(data.triangles);
        Vector3f[] norm = data.normal.toArray(new Vector3f[0]);
        normals = ArrayUtils.toFloatArray(norm);
        Vector3f[] tex = data.textures.toArray(new Vector3f[0]);
        texs = ArrayUtils.toFloatArray(tex);
	}
	
	public RawModel create(ChunkMeshData data) {
		return Engine.getLoader().loadTerrainToVAO(positions, texs, normals, indices);
	}
	
	public RawModel convertData(ChunkMeshData data) {
		Vector3f[] pos = data.vertices.toArray(new Vector3f[0]);
        float[] positions = ArrayUtils.toFloatArray(pos);
        int[] indices = ArrayUtils.toIntArray(data.triangles);
        Vector3f[] norm = data.normal.toArray(new Vector3f[0]);
        float[] normals = ArrayUtils.toFloatArray(norm);
        Vector3f[] tex = data.textures.toArray(new Vector3f[0]);
        float[] texs = ArrayUtils.toFloatArray(tex);
		return Engine.getLoader().loadTerrainToVAO(positions, texs, normals, indices);
	}

}
