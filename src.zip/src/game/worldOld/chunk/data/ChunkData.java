package game.worldOld.chunk.data;

import game.worldOld.biomes.Biome;

public class ChunkData {

	public static float terrainSurface = 0.9f; //Lowest level
    public static int SIZE_X = 64; //32
    public static int SIZE_Z = 64; //32
    public static int height = 32;
    public float[][][] terrainMap;
    public Biome biome;
    
	public ChunkData() {
		
	}

	public static float getTerrainSurface() {
		return terrainSurface;
	}

	public static int getSIZE_X() {
		return SIZE_X;
	}

	public static int getSIZE_Z() {
		return SIZE_Z;
	}

	public static int getHeight() {
		return height;
	}

	public float[][][] getTerrainMap() {
		return terrainMap;
	}

	public Biome getBiome() {
		return biome;
	}

	public void setBiome(Biome biome) {
		this.biome = biome;
	}
	
}
