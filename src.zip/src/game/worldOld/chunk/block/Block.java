package game.worldOld.chunk.block;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class Block {

	protected Vector3f position;
	protected float[] cube;
	protected Voxel voxel;
	
	public Block(Vector3f position, float[] cube, Voxel voxel) {
		this.position = position;
		this.cube = cube;
		this.voxel = voxel;
	}

	public Vector3f getPosition() {
		return position;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public float[] getCube() {
		return cube;
	}

	public void setCube(float[] cube) {
		this.cube = cube;
	}

	public Voxel getVoxel() {
		return voxel;
	}

	public void setVoxel(Voxel voxel) {
		this.voxel = voxel;
	}
	
}
