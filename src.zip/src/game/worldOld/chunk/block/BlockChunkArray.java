package game.worldOld.chunk.block;

public class BlockChunkArray {

	private static Block[][][] blockChunkArray = new Block[66][66][66];

	public static Block[][][] getBlockChunkArray() {
		return blockChunkArray;
	} 
	
}
