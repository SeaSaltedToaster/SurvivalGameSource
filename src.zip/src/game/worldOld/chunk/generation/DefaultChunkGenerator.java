package game.worldOld.chunk.generation;

import client.init.EntityResources;
import client.render.model.TexturedModel;
import game.Game;
import game.worldOld.OpenSimplexNoise;
import game.worldOld.chunk.Chunk;
import game.worldOld.chunk.data.ChunkData;

public class DefaultChunkGenerator extends ChunkGenerator {

	OpenSimplexNoise noise;
	
	TexturedModel model = EntityResources.model;
	
	public static float SURFACE_LEVEL = 10;
	
	@Override
	public void generate(Chunk chunk) {
		noise = new OpenSimplexNoise(Game.worldSeed);
		this.blockMap = new float[ChunkData.SIZE_X+1][ChunkData.height+1][ChunkData.SIZE_Z+1];
		for (int x = 0; x < ChunkData.SIZE_X + 1; x++) {
            for (int z = 0; z < ChunkData.SIZE_Z + 1; z++) {
                for (int y = 0; y < ChunkData.height + 1; y++) {

                	float thisHeight = (float) ((float) (SURFACE_LEVEL+(noise.eval((x + (chunk.getPosition().getxIndex() * 32)), ((z + (chunk.getPosition().getzIndex() * 32)))))));
                	float point = 0;
                    
                    if (y <= thisHeight - ChunkData.terrainSurface)
                        point = 0f;
                    else if (y > thisHeight + ChunkData.terrainSurface)
                        point = 1f;
                    else if (y > thisHeight)
                        point = (float)y - thisHeight;
                    else
                        point = thisHeight - (float)y;
                    
                    this.blockMap[x][y][z] = point;
                }
            }
        }
	}

}
