package game.worldOld.chunk.generation;

import game.worldOld.chunk.Chunk;
import game.worldOld.chunk.data.ChunkData;

public class FlatChunkGenerator extends ChunkGenerator {

	@Override
	public void generate(Chunk chunk) {
		this.blockMap = new float[ChunkData.SIZE_X+1][ChunkData.height+1][ChunkData.SIZE_Z+1];
		for (int x = 0; x < ChunkData.SIZE_X + 1; x++) {
            for (int z = 0; z < ChunkData.SIZE_Z + 1; z++) {
                for (int y = 0; y < ChunkData.height+1; y++) {
                	
                	float thisHeight = 0;
                	float point = 0;
                	
                	if (y <= thisHeight - ChunkData.terrainSurface)
                        point = 0f;
                     if (y > thisHeight + ChunkData.terrainSurface)
                        point = 1f;
                    else if (y > thisHeight)
                        point = (float)y - thisHeight;
                    else
                        point = thisHeight - (float)y;
                     
                    this.blockMap[x][y][z] = point;
                }
            }
        }
	}

}
