package game.worldOld.chunk.generation;

import game.worldOld.chunk.Chunk;

public abstract class ChunkGenerator {
	
	protected float[][][] blockMap;
	
	public ChunkGenerator() {
//		blockMap = new float[ChunkData.SIZE_X+1][ChunkData.height+1][ChunkData.SIZE_Z+1]; //LAG!
	}
	
	public abstract void generate(Chunk base);

	public float[][][] getBlockMap() {
		return blockMap;
	}

	public void setBlockMap(float[][][] blockMap) {
		this.blockMap = blockMap;
	}

}
