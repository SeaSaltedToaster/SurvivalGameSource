package game.worldOld.chunk.thread;

import client.thread.GlRequest;
import game.worldOld.chunk.Chunk;

public class ChunkLoadRequest extends GlRequest {

	private Chunk chunk;
	
	public ChunkLoadRequest(Chunk chunk) {
		this.chunk = chunk;
	}
	
	@Override
	public void execute() {
		chunk.createData();
		chunk.generateVoxels();
		chunk.generateMesh();
		chunk.prepare();
	}

}
