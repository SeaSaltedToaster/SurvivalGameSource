package game.worldOld.chunk.thread;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

import game.worldOld.chunk.Chunk;

public class ChunkThread extends Thread {
	
	public List<Chunk> chunks = new ArrayList<Chunk>();
	private volatile boolean isRunning = true;

	public ChunkThread() {
		this.start();
	}

	@Override
	public void run() {
		while(!this.isInterrupted() && isRunning) {
			Iterator<Chunk> iterator = chunks.iterator();
			while(iterator.hasNext()) {
				try {
					Chunk chunk = iterator.next();
					chunk.createData();
					chunk.generateVoxels(); // 90% Optimized
					chunk.generateMesh(); // 15% Optimized (Line 61-65 in ChunkMeshGenerator)
					chunk.prepare(); // 75% Optimized
					iterator.remove();
				} catch(ConcurrentModificationException ex){
					break;
				}
				break;
			}
		}
	}
	
	public void kill() {
	       isRunning = false;
	}

	public List<Chunk> getChunks() {
		return chunks;
	}

}
