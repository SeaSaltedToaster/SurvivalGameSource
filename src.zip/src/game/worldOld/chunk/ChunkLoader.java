package game.worldOld.chunk;

import java.util.ArrayList;
import java.util.List;

import client.Engine;
import client.constants.Settings;
import client.engine.Logger;
import client.math.Vector2;
import client.math.Vector2f;
import client.math.Vector3f;
import game.main.states.Game;
import game.save.SaveManager;
import game.world.chunk.TerrainPosition;
import game.world.chunk.TerrainChunk;
import game.worldOld.chunk.data.ChunkData;
import game.worldOld.chunk.generation.ChunkGenerator;
import game.worldOld.chunk.generation.DefaultChunkGenerator;
import game.worldOld.chunk.generation.FlatChunkGenerator;

public class ChunkLoader {

	public int viewDistance = (int) (Settings.CHUNK_DISTANCE * 64);
	public Vector2f position;
	
	private int chunkSize;
	private int chunkVisibleInView;
	
	public static ChunkGenerator generator;
	
	public boolean shouldReturn = false;
	
	List<TerrainChunk> terrainChunkMap = new ArrayList<TerrainChunk>();
	List<TerrainChunk> chunksVisible = new ArrayList<TerrainChunk>();
	
	public ChunkLoader() {
		chunkSize = ChunkData.SIZE_X;
		chunkVisibleInView = (int) viewDistance / chunkSize;
		if(SaveManager.terrainType.trim() == "Default") {
    		generator = new DefaultChunkGenerator();
    	} else if(SaveManager.terrainType.trim() == "Flat") {
    		generator = new FlatChunkGenerator();
    	} else {
    		generator = new FlatChunkGenerator();
    	}
	}
	
	public ChunkLoader(Vector3f pos) {
		chunkSize = ChunkData.SIZE_X;
		chunkVisibleInView = (int) viewDistance / chunkSize;
		if(SaveManager.terrainType == "Default") {
    		generator = new DefaultChunkGenerator();
    	} else if(SaveManager.terrainType == "Flat") {
    		generator = new FlatChunkGenerator();
    	} else {
    		generator = new DefaultChunkGenerator();
    	}
		
		terrainChunkMap.clear();
		
		updateChunksOnLoad(pos);
	}
	
	public void updateChunks(Vector3f position) {
		int currentChunkCoordX = (int) position.x / chunkSize;
		int currentChunkCoordZ = (int) position.z / chunkSize;
		
		for(TerrainChunk chunk : terrainChunkMap) {
			chunk.update();
		}

		if(terrainChunkMap.size() >= chunkVisibleInView) {
			return;
		}
		
		for(int yOffset = -chunkVisibleInView; yOffset <= chunkVisibleInView; yOffset++) {
			for(int xOffset = -chunkVisibleInView; xOffset <= chunkVisibleInView; xOffset++) {
				Vector2 viewedChunkCoord = new Vector2(currentChunkCoordX+xOffset, currentChunkCoordZ+yOffset);
				TerrainPosition cposition = new TerrainPosition(new Vector3f(viewedChunkCoord.x*(ChunkData.SIZE_X),0,viewedChunkCoord.y*(ChunkData.SIZE_Z)), viewedChunkCoord.x,viewedChunkCoord.y);
				TerrainChunk chunk = new TerrainChunk(cposition);	
				chunksVisible.add(chunk);
				
				boolean exists = false;
				for(TerrainChunk chunke : terrainChunkMap) {
					if(chunke.getPosition().getxIndex() == chunk.getPosition().getxIndex() && chunke.getPosition().getzIndex() == chunk.getPosition().getzIndex()) {
						exists = true;
						break;
					}
					exists = false;
				}
				if(!exists) {
					chunk.generateThreadedTerrain();
					terrainChunkMap.add(chunk);
					return;
				}
			}
		}
		
//		checkForRange();
	}
	
	private void checkForRange() {
		for(TerrainChunk chunk : terrainChunkMap) {
			Vector2f chunkPos = Vector3f.toVector2f(chunk.getPosition().getPosition());
			Vector2f camPos = Vector3f.toVector2f(Engine.getCamera().getPosition());
			Vector2f distance = camPos.subtract(chunkPos);
			if(distance.lengthSquared() > viewDistance*32) {
//				chunk.unload();
			} else {
//				chunk.load();
			}
		}
	}
	
	public void updateChunksOnLoad(Vector3f position) {
		int currentChunkCoordX = (int) position.x / chunkSize;
		int currentChunkCoordZ = (int) position.z / chunkSize;
		
		for(int yOffset = -chunkVisibleInView; yOffset <= chunkVisibleInView; yOffset++) {
			for(int xOffset = -chunkVisibleInView; xOffset <= chunkVisibleInView; xOffset++) {
				Vector2 viewedChunkCoord = new Vector2(currentChunkCoordX+xOffset, currentChunkCoordZ+yOffset);
				TerrainPosition cposition = new TerrainPosition(new Vector3f(viewedChunkCoord.x*(ChunkData.SIZE_X),0,viewedChunkCoord.y*(ChunkData.SIZE_Z)), viewedChunkCoord.x,viewedChunkCoord.y);
				TerrainChunk chunk = new TerrainChunk(cposition);	
				chunksVisible.add(chunk);
				
				chunk.generateThreadedTerrain();
				terrainChunkMap.add(chunk);
				
				Logger.log(terrainChunkMap.size() + " : "+chunkVisibleInView);
				if(terrainChunkMap.size() >= chunkVisibleInView) {
					return;
				}
			}
		}
	}
	
	public TerrainChunk getCurrentChunk(Vector3f position) {
		int x = (int) position.x; int z = (int) position.z; 
		for(TerrainChunk chunk : terrainChunkMap) {
			if(chunk.getPosition().getxIndex() == x/(ChunkData.SIZE_X/2)+1 && chunk.getPosition().getzIndex() == z/(ChunkData.SIZE_X/2)+1) {
//				System.out.println(chunk.getPosition().getxIndex() + " : "+chunk.getPosition().getzIndex());
				return chunk;
			}
		}
		return null;
	}
	
	public void SaveAll() {
		for(TerrainChunk chunk : terrainChunkMap) {
//			SaveManager.saveChunk(chunk);
		}
	}

	public List<TerrainChunk> getTerrainChunkMap() {
		return terrainChunkMap;
	}
	
}
