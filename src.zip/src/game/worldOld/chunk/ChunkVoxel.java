package game.worldOld.chunk;

import game.worldOld.Voxel;

public class ChunkVoxel {

	public float[] cube;
	public Voxel block;
	
	public ChunkVoxel(float[] cube, Voxel block) {
		this.cube = cube;
		this.block = block;
	}

	public float[] getCube() {
		return cube;
	}

	public void setCube(float[] cube) {
		this.cube = cube;
	}

	public Voxel getBlock() {
		return block;
	}

	public void setBlock(Voxel block) {
		this.block = block;
	}
	
}
