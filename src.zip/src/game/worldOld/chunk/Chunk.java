package game.worldOld.chunk;


import java.util.ArrayList;
import java.util.List;

import client.entities.Entity;
import client.init.Textures;
import client.texture.Texture;
import client.thread.GlRequestProcessor;
import game.main.states.Game;
import game.world.chunk.TerrainPosition;
import game.worldOld.biomes.Biome;
import game.worldOld.biomes.Biomes;
import game.worldOld.chunk.data.ChunkData;
import game.worldOld.chunk.generation.ChunkGenerator;
import game.worldOld.chunk.mesh.ChunkMeshBuilder;
import game.worldOld.chunk.mesh.ChunkMeshData;
import game.worldOld.chunk.mesh.ChunkMeshGenerator;
import game.worldOld.chunk.thread.ChunkLoadRequest;

public class Chunk {
    
    //???
    public boolean isLoaded = true;
    public boolean generated = false;
    public boolean canBeLoaded = false;
    public boolean created = false;
    
    //Generation
    protected ChunkGenerator generator;
    protected TerrainPosition position;
    
    //Data
    protected ChunkData data;
    protected ChunkMeshData meshData;
    
    //Mesh
    protected ChunkMeshBuilder builder;
    
    public Biome biome;
    
    public List<Entity> entities = new ArrayList<Entity>();
    
    public Chunk(TerrainPosition position) {
    	this.position = position;
    	Start();
    }
    
    public void Start() { 
    	//Initializing
    	builder = new ChunkMeshBuilder();
    	generator = ChunkLoader.generator;
    }
    
    public void createData() {
    	data = new ChunkData();
    	meshData = new ChunkMeshData();
    	
    	getBiome();
    	
    	meshData.setBiometex(new Texture(Textures.ground));
    }
    
    private void getBiome() {
//    	data.setBiome(Biomes.getRandom());
    	data.setBiome(Biomes.plains);
    }
    
    public void generate() {
    	ChunkLoadRequest request = new ChunkLoadRequest(this);
    	GlRequestProcessor.sendRequest(request);
    	
//    	Game.cthread.getChunks().add(this);
    }
    
    public void generateVoxels() {
    	//Height Generation
        generator.generate(this);
        data.terrainMap = generator.getBlockMap();
    }
    
    public void generateMesh() {
    	ChunkMeshGenerator.generate(meshData, data);
    }
    
    public void prepare() {
    	builder.convert(meshData);
    	this.canBeLoaded = true;
    }
    
    public void generateEntity() {
    	//Create Chunk Entity
        builder.generateAfterConversion(getMeshData(), getPosition());
        
        //Entity
        Game.chunks.add(meshData.getEntity());
        
//        FoliageGenerator.generate(position.getPosition().x, position.getPosition().z, data.getBiome(), this);
          
        this.canBeLoaded = false;
        this.generated = true;
    }
    
    public void unload() {
    	if(this.generated && this.isLoaded) {
    		Game.chunks.remove(meshData.getEntity());
    		Game.getEntities().removeAll(entities);
    		Game.getCl().getTerrainChunkMap().remove(this);
    		this.isLoaded = false;
    	}
    }
    
    public void load() {
    	if(!this.isLoaded && this.generated) {
    		this.isLoaded = true;
    		Game.chunks.add(meshData.getEntity());
    		Game.getEntities().addAll(entities);
    	}
    }
    
    public void update() {
    	//Testing
    	if(this.canBeLoaded && !created) {
    		this.generateEntity();
    		Game.getCl().shouldReturn = true;
    		this.created = true;
    	}
    }

	public TerrainPosition getPosition() {
		return position;
	}

	public boolean isLoaded() {
		return isLoaded;
	}

	public void setLoaded(boolean isLoaded) {
		this.isLoaded = isLoaded;
	}

	public ChunkData getData() {
		return data;
	}

	public ChunkMeshData getMeshData() {
		return meshData;
	}
		
}