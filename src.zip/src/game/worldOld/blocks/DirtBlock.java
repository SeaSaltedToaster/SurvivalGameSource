package game.worldOld.blocks;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class DirtBlock extends Voxel {

	public DirtBlock() {
		super(new Vector3f((float) Math.min(Math.random(),0.9f),0.44f,0f));
		//super(new Vector3f(0.85f,0.44f,0));
	}
	
//	public SandBlock() {
//		super(new Vector3f(0.85f,(float) Math.max(Math.random(),0.85f),0.1f));
//	}

}
