package game.worldOld.blocks;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class SandBlock extends Voxel {

	public SandBlock() {
		super(new Vector3f(0.7373784675504619f,0.6249732133506963f,0.2562839795754654f));
	}
	
}
