package game.worldOld.blocks;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class StoneBlock extends Voxel {

	public StoneBlock() {
		super(new Vector3f(0.25f,0.25f,0.25f));
	}

}
