package game.worldOld.blocks;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class SnowBlock extends Voxel {

	public SnowBlock() {
		super(new Vector3f(2,2,2));
	}

}
