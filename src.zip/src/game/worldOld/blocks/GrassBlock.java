package game.worldOld.blocks;

import client.math.Vector3f;
import game.worldOld.Voxel;

public class GrassBlock extends Voxel {

	public GrassBlock() {
		super(new Vector3f(0f,1f,0f));
	}

}
