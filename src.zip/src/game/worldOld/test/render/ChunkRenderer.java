package game.worldOld.test.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import client.Engine;
import client.constants.Constants;
import client.entities.Entity;
import client.entities.Light;
import client.math.MathUtils;
import client.render.model.RawModel;
import client.util.ProjectionMatrixUtils;
import client.util.gl.OpenGL;

public class ChunkRenderer {
	
	private ChunkShader shader;

	public ChunkRenderer() {
		shader = new ChunkShader();
		shader.start();
		shader.loadProjectionMatrix(ProjectionMatrixUtils.getProjectionMatrix());
		shader.stop();
	}
	
	public void renderEntities(Entity entity, Light light) {
		beginRendering(light);
		prepareTexturedModel(entity.getTm().getModel());
		prepareInstance(entity);
		GL11.glDrawElements(GL11.GL_TRIANGLES, entity.getTm().getModel().getVertexCount(), GL11.GL_UNSIGNED_INT, 0);
		unbindTexturedModel();	
		finishRendering();
	}
	
	private void beginRendering(Light light) {
		shader.start();
		shader.loadViewMatrix(Engine.getCamera());
		shader.loadLight(light);
		shader.loadFog(Constants.FOG_DENSITY, Constants.FOG_GRADIENT);
	}
	
	private void finishRendering() {
		shader.stop();
	}
	
	private void prepareTexturedModel(RawModel model) {
		GL30.glBindVertexArray(model.getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL20.glEnableVertexAttribArray(1);
		GL20.glEnableVertexAttribArray(2);
		OpenGL.enableCull();
	}
	
	private void unbindTexturedModel() {
		GL20.glDisableVertexAttribArray(0);
		GL20.glDisableVertexAttribArray(1);
		GL20.glDisableVertexAttribArray(2);
		GL30.glBindVertexArray(0);
		OpenGL.disableCull();
	}
	
	private void prepareInstance(Entity entity) {
		shader.loadTransformationMatrix(MathUtils.createTransformationMatrix(entity.getPosition(), 0, 0, 0, entity.getScale()));
	}

}
