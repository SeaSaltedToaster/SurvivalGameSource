package game.worldOld;

public enum VoxelTypes {

	FULL, PARTIAL, EMPTY,
	
}
