package game.worldOld.biomes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.worldOld.biomes.list.BiomePlains;
import game.worldOld.biomes.list.BiomeSnowy;
import game.worldOld.blocks.SandBlock;

public class Biomes {

	public static List<Biome> biomes = new ArrayList<Biome>();
	public static Random random = new Random();
	
	public static Biome plains = new BiomePlains();
	public static Biome desert = new Biome(new SandBlock());
	public static Biome snow = new BiomeSnowy();
	
	public static void init() {
		biomes.add(plains);
		biomes.add(desert);
		biomes.add(snow);
	}
	
	public static Biome getRandom() {
		return biomes.get(random.nextInt(biomes.size()));
	}
	
}
