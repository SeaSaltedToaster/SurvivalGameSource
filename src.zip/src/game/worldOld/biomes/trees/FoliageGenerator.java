package game.worldOld.biomes.trees;

import java.util.Random;

import client.Engine;
import client.math.Vector3f;
import game.Game;
import game.entities.EntityGrass;
import game.entities.EntityRock;
import game.entities.EntityTree;
import game.worldOld.biomes.Biome;
import game.worldOld.chunk.Chunk;

public class FoliageGenerator {

	public static Random random = new Random(Game.worldSeed);
	
	private static boolean isXNeg;
	private static boolean isZNeg;
	
	private float[][] terrainSurfaceMap = new float[64][64];

	public static void generate(float f, float g, Biome biome, Chunk chunk) {
		biome.generateObjects(f,g, chunk);
	}
	
}
