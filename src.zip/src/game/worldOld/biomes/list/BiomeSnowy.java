package game.worldOld.biomes.list;

import java.util.Random;

import client.Engine;
import client.math.Vector3f;
import game.entities.EntityGrass;
import game.entities.EntityRock;
import game.entities.EntitySnowGrass;
import game.entities.EntityTree;
import game.entities.SpawnPosition;
import game.entities.animals.EntityPig;
import game.worldOld.biomes.Biome;
import game.worldOld.biomes.trees.FoliageGenerator;
import game.worldOld.blocks.GrassBlock;
import game.worldOld.blocks.SnowBlock;
import game.worldOld.chunk.Chunk;

public class BiomeSnowy extends Biome {

private Random random = FoliageGenerator.random;
	
	public BiomeSnowy() {
		super(new SnowBlock());
	}
	
	@Override
	public void generateObjects(float f, float g, Chunk chunk) {
//		for(int i = 0; i < 1; i++) {
//			EntityTree tree = new EntityTree(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
//			Engine.getEntities().add(tree);
//		}
//		FIR TREE? SPRUCE TREE?
		
		for(int i = 0; i < 16; i++) {
			EntitySnowGrass grass = new EntitySnowGrass(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
			Engine.getEntities().add(grass);
			chunk.entities.add(grass);
		}
		
		for(int i = 0; i < 1; i++) {
			EntityRock rock = new EntityRock(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
			if(random.nextInt(100) > 97.5f) {
				Engine.getEntities().add(rock);
				chunk.entities.add(rock);
			}
		}
	}
	
}
