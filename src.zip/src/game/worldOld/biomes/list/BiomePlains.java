package game.worldOld.biomes.list;

import java.util.Random;

import client.Engine;
import client.math.Vector3f;
import game.entities.EntityGrass;
import game.entities.EntityRock;
import game.entities.EntityTree;
import game.entities.SpawnPosition;
import game.entities.animals.EntityPig;
import game.worldOld.Voxel;
import game.worldOld.biomes.Biome;
import game.worldOld.biomes.trees.FoliageGenerator;
import game.worldOld.blocks.GrassBlock;
import game.worldOld.chunk.Chunk;

public class BiomePlains extends Biome {

	private Random random = FoliageGenerator.random;
	
	public BiomePlains() {
		super(new GrassBlock());
	}
	
	@Override
	public void generateObjects(float f, float g, Chunk chunk) {
		for(int i = 0; i < 1; i++) {
			EntityTree tree = new EntityTree(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
			Engine.getEntities().add(tree);
			chunk.entities.add(tree);
		}
		
		for(int i = 0; i < 16; i++) {
			EntityGrass grass = new EntityGrass(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
			Engine.getEntities().add(grass);
			chunk.entities.add(grass);
		}
		
		for(int i = 0; i < 1; i++) {
			EntityRock rock = new EntityRock(new Vector3f(f+random.nextInt(16),0,g+random.nextInt(16)));
			if(random.nextInt(100) > 90)  {
				Engine.getEntities().add(rock);
				chunk.entities.add(rock);
			}
		}
		
		if(Math.random() < 0.1f) {
        	EntityPig pig = new EntityPig(new SpawnPosition(f+random.nextInt(16),0,g+random.nextInt(16)));
        	Engine.getEntities().add(pig);
        	chunk.entities.add(pig);
        }
	}

}
