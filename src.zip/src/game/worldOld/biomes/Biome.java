package game.worldOld.biomes;

import game.worldOld.Voxel;
import game.worldOld.chunk.Chunk;

public class Biome {
	
	public Voxel surfaceBlock;

	public Biome(Voxel surfaceBlock) {
		this.surfaceBlock = surfaceBlock;
	}
	
	public void generateObjects(float f, float g, Chunk chunk) {
		
	}
	
	public void generateMobs(float f, float g) {
		
	}
	
	public Voxel getSurface() {
		return surfaceBlock;
	}

}
