package game.worldOld;

import client.math.Vector3f;

public class Voxel {
	
	private int Texture;
	
	private Vector3f color;
	
	public Voxel(Vector3f color) {
		this.color = color;
	}

	public int getTexture() {
		return Texture;
	}

	public Vector3f getColor() {
		return color;
	}

	public void setColor(Vector3f color) {
		this.color = color;
	}
	
}
