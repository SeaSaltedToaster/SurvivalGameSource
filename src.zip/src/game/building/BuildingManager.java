package game.building;

import org.lwjgl.glfw.GLFW;

import client.Engine;
import client.entities.Entity;
import client.init.Textures;
import client.math.Vector3f;
import client.render.model.TexturedModel;
import client.render.obj.OBJLoader;
import client.texture.ModelTexture;
import game.main.Main;
import game.main.states.Game;

public class BuildingManager {

	public static Entity build;
	
	private static boolean isBuilding;
	
	public static void init() {
		build = new Entity(new TexturedModel(OBJLoader.loadObjModel("structures/dungeon/test", Engine.getLoader()),new ModelTexture(Textures.black)), new Vector3f(0,0,0),0,0,0,1);
		Game.getEntities().add(build);
	}
	
	public static void update() {
		
		
		if(isBuilding) {
			Vector3f position = Game.getPicker().getCurrentIntRay(Main.getCamera().getPosition(), 5);
			build.setPosition(position);
		
			if(GLFW.glfwGetMouseButton(Main.getWindow().getWindowID(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) {
				Entity instantiate = new Entity(build.getTm(),build.getPosition(),0,0,0,1);
				Game.getEntities().add(instantiate);
				setBuilding(false);
			}
		}
	}

	public static boolean isBuilding() {
		return isBuilding;
	}

	public static void setBuilding(boolean isBuilding) {
		BuildingManager.isBuilding = isBuilding;
	}
	
}

