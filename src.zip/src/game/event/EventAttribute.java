package game.event;

public class EventAttribute {

	public String name;
	public Object data;
	
	public EventAttribute(String name, Object object) {
		this.name = name;
		this.data = object;
	}

	public String getName() {
		return name;
	}

	public Object getData() {
		return data;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
