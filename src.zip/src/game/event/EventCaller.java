package game.event;

public class EventCaller {

}
