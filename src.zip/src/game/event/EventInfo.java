package game.event;

import java.util.ArrayList;
import java.util.List;

public class EventInfo {

	List<EventAttribute> attributes = new ArrayList<EventAttribute>();
	
	public void addAttribute(String name, Object object) {
		attributes.add(new EventAttribute(name, object));
	}
	
}
