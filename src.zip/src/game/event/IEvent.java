package game.event;

public interface IEvent {
	
	public void invoke();

}
